var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// team-inbox/src/index.js
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var React = __toESM(require("react"), 1);

// team-inbox/src/lib/keywords.js
var ASSIGNED_PREFIX = "$assigned:";
var DONE = "$done";
var ID_RE = /^[a-z0-9][a-z0-9_.-]{0,100}$/i;
function isAssigneeId(id) {
  return typeof id === "string" && ID_RE.test(id);
}
function assignedKeyword(id) {
  if (!isAssigneeId(id)) throw new Error(`Not an id that fits in a keyword: ${id}`);
  return ASSIGNED_PREFIX + id.toLowerCase();
}
function keywordList(keywords) {
  if (Array.isArray(keywords)) return keywords.filter((k) => typeof k === "string").map((k) => k.toLowerCase());
  if (keywords && typeof keywords === "object") {
    return Object.keys(keywords).filter((k) => keywords[k]).map((k) => k.toLowerCase());
  }
  return [];
}
function assigneesOf(keywords) {
  return keywordList(keywords).filter((k) => k.startsWith(ASSIGNED_PREFIX)).map((k) => k.slice(ASSIGNED_PREFIX.length)).filter(isAssigneeId);
}
function isDone(keywords) {
  return keywordList(keywords).includes(DONE);
}
function assignChanges(keywords, id) {
  const wanted = assignedKeyword(id);
  const changes = {};
  for (const other of assigneesOf(keywords)) {
    const kw = ASSIGNED_PREFIX + other;
    if (kw !== wanted) changes[kw] = false;
  }
  if (!keywordList(keywords).includes(wanted)) changes[wanted] = true;
  return changes;
}
function unassignChanges(keywords) {
  const changes = {};
  for (const id of assigneesOf(keywords)) changes[ASSIGNED_PREFIX + id] = false;
  return changes;
}
function doneChanges(keywords) {
  return isDone(keywords) ? {} : { [DONE]: true };
}
function reopenChanges(keywords) {
  return isDone(keywords) ? { [DONE]: false } : {};
}
function recentAssignees(seen, { exclude = [], limit = 8 } = {}) {
  const skip = new Set(exclude.map((id) => String(id).toLowerCase()));
  return [...seen.entries()].filter(([id]) => !skip.has(id)).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, limit).map(([id]) => id);
}

// team-inbox/src/lib/names.js
var MAX_SHARED_BYTES = 3584;
var SHARED_VERSION = 1;
var jsonBytes = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
function clean(value, max) {
  return typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, max) : "";
}
function person(entry) {
  if (!entry || typeof entry !== "object") return null;
  const name = clean(entry.name ?? entry.n, 80);
  const email = clean(entry.email ?? entry.e, 254).toLowerCase();
  if (!name && !email) return null;
  return { name: name || email, email };
}
function readShared(value) {
  const out = {};
  const people = value && typeof value === "object" && value.people && typeof value.people === "object" ? value.people : {};
  for (const [id, entry] of Object.entries(people)) {
    const p = person(entry);
    if (p && /^[a-z0-9][a-z0-9_.-]{0,100}$/i.test(id)) out[id.toLowerCase()] = p;
  }
  return out;
}
function writeShared(people) {
  const entries = Object.entries(people).map(([id, p]) => [id, { n: p.name, e: p.email }]);
  let value = { v: SHARED_VERSION, people: Object.fromEntries(entries) };
  while (entries.length > 0 && jsonBytes(value) >= MAX_SHARED_BYTES) {
    entries.shift();
    value = { v: SHARED_VERSION, people: Object.fromEntries(entries) };
  }
  return value;
}
function mergeShared(shared, additions) {
  let changed = false;
  const next = { ...shared };
  for (const [id, entry] of Object.entries(additions)) {
    const p = person(entry);
    if (!p) continue;
    const key = id.toLowerCase();
    const before = next[key];
    if (before && before.name === p.name && before.email === p.email) continue;
    delete next[key];
    next[key] = p;
    changed = true;
  }
  return changed ? next : null;
}
function shortName(p) {
  if (!p) return "";
  const name = (p.name || "").trim();
  if (name && !name.includes("@")) return name.split(/\s+/)[0];
  const address = (p.email || name).split("@")[0];
  return address;
}
function findByEmail(people, address) {
  const wanted = String(address ?? "").trim().toLowerCase();
  if (!wanted) return null;
  for (const [id, p] of Object.entries(people)) {
    if (p.email === wanted) return { id, ...p };
  }
  return null;
}
function looksLikeAddress(text) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(text ?? "").trim());
}

// team-inbox/src/lib/wiring.js
var SURFACES = ["message-row-actions", "reader-actions"];
var ACTION = {
  assignMe: "assign-me",
  assignTo: "assign-to",
  unassign: "unassign",
  done: "done",
  reopen: "reopen"
};
var FILTER = { mine: "mine", open: "open" };
var BADGE = { assignee: "team-inbox-assignee", done: "team-inbox-done" };
var GROUP = ["group"];
var PEOPLE_KEY = "people";
var LOOKUP_DELAY_MS = 1500;
var LOOKUP_BATCH = 20;
var LOOKUP_MIN_GAP_MS = 1e4;
var GROUP_RETRY_MS = [3e3, 15e3];
function hostSupports(api) {
  return typeof api?.user?.getSelf === "function" && typeof api?.user?.getMailAccounts === "function" && typeof api?.ui?.setListFilters === "function" && typeof api?.email?.updateKeywords === "function";
}
function teamActions(t) {
  return [
    { id: ACTION.assignMe, label: t("action.assign_me"), icon: "user-check", order: 50, accounts: GROUP },
    { id: ACTION.assignTo, label: t("action.assign_to"), icon: "user-plus", order: 51, accounts: GROUP },
    { id: ACTION.unassign, label: t("action.unassign"), icon: "user-x", order: 52, accounts: GROUP, hasKeyword: `${ASSIGNED_PREFIX}*` },
    { id: ACTION.done, label: t("action.done"), icon: "circle-check", order: 53, accounts: GROUP, notKeyword: DONE },
    { id: ACTION.reopen, label: t("action.reopen"), icon: "arrow-back-up", order: 53, accounts: GROUP, hasKeyword: DONE }
  ];
}
function teamFilters(t, selfId) {
  return [
    { id: FILTER.mine, label: t("filter.mine"), icon: "user", hasKeyword: assignedKeyword(selfId), accounts: GROUP, order: 1 },
    { id: FILTER.open, label: t("filter.open"), icon: "circle-dashed", notKeyword: DONE, accounts: GROUP, order: 2 }
  ];
}
function createWiring(initialApi) {
  let api = initialApi;
  let self = null;
  let people = {};
  let shared = {};
  let readOnly = /* @__PURE__ */ new Set();
  const seen = /* @__PURE__ */ new Map();
  const unknown = /* @__PURE__ */ new Set();
  const asked = /* @__PURE__ */ new Set();
  let lookupTimer = null;
  let lastLookup = 0;
  let directoryAllowed = true;
  let groupRetries = 0;
  let dialogOpen = false;
  let started = null;
  let localeHooked = false;
  const t = (key, vars) => api.i18n.t(key, vars);
  function selfPerson() {
    return { name: self.name, email: self.email };
  }
  function nameOf(id) {
    if (self && id === self.accountId) return selfPerson();
    return people[id] ?? null;
  }
  async function saveLocal() {
    try {
      await api.storage.set(PEOPLE_KEY, people);
    } catch {
    }
  }
  function learn(additions) {
    let changed = false;
    for (const [id, entry] of Object.entries(additions)) {
      const p = person(entry);
      if (!p || !isAssigneeId(id)) continue;
      const key = id.toLowerCase();
      const before = people[key];
      if (before && before.name === p.name && before.email === p.email) continue;
      people[key] = p;
      changed = true;
    }
    return changed;
  }
  let lastRefresh = 0;
  function refreshBadges() {
    const wait = Math.max(0, lastRefresh + 1100 - Date.now());
    lastRefresh = Date.now() + wait;
    if (wait === 0) void api.ui.refreshRowBadges?.();
    else setTimeout(() => {
      void api.ui.refreshRowBadges?.();
    }, wait);
  }
  async function publish() {
    if (!self) return;
    const actions = teamActions(t);
    for (const surface of SURFACES) await api.ui.setActions(surface, actions);
    await api.ui.setListFilters(teamFilters(t, self.accountId));
  }
  async function share(accountId, additions) {
    if (!(accountId in shared) || shared[accountId] === null || readOnly.has(accountId)) return;
    try {
      const data = await api.accountData.get(accountId);
      if (!data?.supported) return;
      const current = readShared(data.value);
      if (learn(current)) await saveLocal();
      const next = mergeShared(current, additions);
      shared[accountId] = next ?? current;
      if (next) await api.accountData.set(accountId, writeShared(next));
    } catch (err) {
      api.log.warn("could not update the names in the team mailbox", err);
    }
  }
  async function loadGroups() {
    if (!self) return false;
    let accounts;
    try {
      accounts = await api.user.getMailAccounts();
    } catch {
      return false;
    }
    const groups = accounts.filter((a) => a.kind === "group");
    if (groups.length === 0 && accounts.some((a) => a.kind === "shared") && groupRetries < GROUP_RETRY_MS.length) {
      setTimeout(() => {
        void loadGroups().then((learned2) => {
          if (learned2) refreshBadges();
        });
      }, GROUP_RETRY_MS[groupRetries++]);
    }
    let learned = false;
    for (const account of groups) {
      if (account.accountId in shared) continue;
      shared[account.accountId] = null;
      if (account.isReadOnly) readOnly.add(account.accountId);
      let data;
      try {
        data = await api.accountData?.get?.(account.accountId);
      } catch {
        data = null;
      }
      if (!data?.supported) continue;
      const map = readShared(data.value);
      shared[account.accountId] = map;
      if (learn(map)) learned = true;
      if (!map[self.accountId]) await share(account.accountId, { [self.accountId]: selfPerson() });
    }
    if (learned) await saveLocal();
    return learned;
  }
  function scheduleLookup() {
    if (!directoryAllowed || lookupTimer || unknown.size === 0 || typeof api.user?.findPeople !== "function") return;
    const wait = Math.max(LOOKUP_DELAY_MS, lastLookup + LOOKUP_MIN_GAP_MS - Date.now());
    lookupTimer = setTimeout(() => {
      lookupTimer = null;
      void lookup();
    }, wait);
  }
  async function lookup() {
    const ids = [...unknown].slice(0, LOOKUP_BATCH);
    for (const id of ids) {
      unknown.delete(id);
      asked.add(id);
    }
    if (ids.length === 0) return;
    lastLookup = Date.now();
    let result;
    try {
      result = await api.user.findPeople({ ids });
    } catch (err) {
      if (/permission/i.test(String(err?.message ?? err))) directoryAllowed = false;
      return;
    }
    const found = {};
    for (const p of result?.people ?? []) {
      if (p.type !== "group" && ids.includes(p.id)) found[p.id] = { name: p.name, email: p.email };
    }
    if (learn(found)) {
      await saveLocal();
      refreshBadges();
    }
    scheduleLookup();
  }
  function noteUnknown(id) {
    if (asked.has(id) || unknown.has(id) || nameOf(id)) return;
    unknown.add(id);
    scheduleLookup();
  }
  async function start() {
    if (!hostSupports(api)) {
      api.log.info("team-inbox needs Bulwark 1.19 or later");
      return;
    }
    self = await api.user.getSelf();
    people = {};
    shared = {};
    readOnly = /* @__PURE__ */ new Set();
    seen.clear();
    unknown.clear();
    asked.clear();
    groupRetries = 0;
    const cached = await api.storage.get(PEOPLE_KEY);
    if (cached && typeof cached === "object") learn(cached);
    await publish();
    refreshBadges();
    void loadGroups().then((learned) => {
      if (learned) refreshBadges();
    });
  }
  function ensureStarted() {
    started ?? (started = start().catch((err) => {
      api.log.error("team-inbox failed to start", err);
    }));
    return started;
  }
  async function keywordsOf(emailId, accountId) {
    const view = await api.email.get(emailId, accountId);
    if (!view) throw new Error("The message is gone");
    return view.keywords ?? [];
  }
  async function change(emailId, accountId, changes, success) {
    if (Object.keys(changes).length === 0) return true;
    const ok = await api.email.updateKeywords(emailId, changes, accountId);
    if (ok === false) return false;
    if (success) api.toast.success(success);
    return true;
  }
  function choicesFor(accountId) {
    const out = [];
    const add = (id, kind) => {
      if (!id || out.some((c) => c.id === id)) return;
      const p = nameOf(id);
      out.push({ id, kind, name: p?.name || t("choice.unknown"), email: p?.email || "", ...p ? {} : { note: t("choice.unknown_id", { id }) } });
    };
    add(self.accountId, "me");
    for (const id of recentAssignees(new Map([...seen].map(([id2, emails]) => [id2, emails.size])), { exclude: [self.accountId] })) add(id, "recent");
    for (const id of Object.keys(shared[accountId] ?? {})) add(id, "member");
    return out;
  }
  async function resolveAddress(address, accountId) {
    const known = findByEmail({ ...people, [self.accountId]: selfPerson() }, address);
    if (known) return known;
    let result;
    try {
      result = await api.user.findPeople({ text: address, ...accountId ? { accountId } : {} });
    } catch {
      result = null;
    }
    const match = result?.people?.find((p) => p.email === address.toLowerCase() && p.type !== "group");
    if (match) return { id: match.id, name: match.name, email: match.email };
    throw new Error(result && !result.complete ? t("error.no_directory", { address }) : t("error.not_found", { address }));
  }
  async function assignTo(emailId, accountId) {
    if (dialogOpen) return;
    dialogOpen = true;
    let picked;
    try {
      picked = await api.ui.openDialog({
        title: t("dialog.title"),
        slot: "plugin-dialog",
        extraProps: { choices: choicesFor(accountId), accountId },
        width: 440
      });
    } finally {
      dialogOpen = false;
    }
    if (!picked || typeof picked !== "object") return;
    let target;
    if (typeof picked.address === "string") {
      if (!looksLikeAddress(picked.address)) return;
      target = await resolveAddress(picked.address.trim().toLowerCase(), accountId);
    } else if (isAssigneeId(picked.id)) {
      target = { id: picked.id.toLowerCase(), name: picked.name, email: picked.email };
    } else {
      return;
    }
    const p = person(target);
    if (p && target.id !== self.accountId) {
      if (learn({ [target.id]: p })) await saveLocal();
      if (accountId) await share(accountId, { [target.id]: p });
    }
    const keywords = await keywordsOf(emailId, accountId);
    const success = target.id === self.accountId ? t("toast.assigned_me") : t("toast.assigned", { name: p?.name || target.id });
    await change(emailId, accountId, assignChanges(keywords, target.id), success);
  }
  async function run(actionId, emailId, accountId) {
    await ensureStarted();
    if (!self) return;
    switch (actionId) {
      case ACTION.assignMe: {
        const keywords = await keywordsOf(emailId, accountId);
        const changes = assignChanges(keywords, self.accountId);
        if (Object.keys(changes).length === 0) api.toast.info(t("toast.already_mine"));
        else await change(emailId, accountId, changes, t("toast.assigned_me"));
        if (accountId) await share(accountId, { [self.accountId]: selfPerson() });
        return;
      }
      case ACTION.assignTo:
        await assignTo(emailId, accountId);
        return;
      case ACTION.unassign: {
        const keywords = await keywordsOf(emailId, accountId);
        await change(emailId, accountId, unassignChanges(keywords), t("toast.unassigned"));
        return;
      }
      case ACTION.done: {
        const keywords = await keywordsOf(emailId, accountId);
        await change(emailId, accountId, doneChanges(keywords), t("toast.done"));
        return;
      }
      case ACTION.reopen: {
        const keywords = await keywordsOf(emailId, accountId);
        await change(emailId, accountId, reopenChanges(keywords), t("toast.reopened"));
        return;
      }
      default:
    }
  }
  function badgeFor(ids) {
    const mine = ids[0] === self.accountId;
    const names = ids.map((id) => id === self.accountId ? t("badge.you") : nameOf(id)?.name ?? null);
    const first = mine ? t("badge.me") : nameOf(ids[0]) ? shortName(nameOf(ids[0])) : t("badge.assigned");
    const label = ids.length > 1 ? t("badge.more", { name: first, count: ids.length - 1 }) : first;
    let title;
    if (ids.length > 1) {
      title = t("badge.assigned_many", { names: names.map((n) => n ?? t("choice.unknown")).join(", ") });
    } else if (mine) {
      title = t("badge.assigned_me_title");
    } else {
      const p = nameOf(ids[0]);
      title = p ? t("badge.assigned_to", { name: p.email ? `${p.name} <${p.email}>` : p.name }) : t("badge.assigned_unknown");
    }
    return { key: BADGE.assignee, icon: "user", label, title };
  }
  const hooks = {
    onAction({ surface, actionId, context } = {}) {
      if (!SURFACES.includes(surface) || typeof context?.emailId !== "string") return void 0;
      const accountId = typeof context.accountId === "string" ? context.accountId : void 0;
      return run(actionId, context.emailId, accountId).catch((err) => {
        api.log.error("team-inbox action failed", err);
        api.toast.error(err instanceof Error && err.message && !/^The message is gone$/.test(err.message) ? err.message : t("error.failed"));
      });
    },
    onEmailListItemRender(badges, { email } = {}) {
      if (!self) return void 0;
      const keywords = keywordList(email?.keywords);
      const out = Array.isArray(badges) ? [...badges] : [];
      const before = out.length;
      const ids = assigneesOf(keywords).sort((a, b) => Number(b === self.accountId) - Number(a === self.accountId));
      if (ids.length > 0) {
        for (const id of ids) {
          if (email?.id) {
            const messages = seen.get(id) ?? /* @__PURE__ */ new Set();
            messages.add(email.id);
            seen.set(id, messages);
          }
          noteUnknown(id);
        }
        out.push(badgeFor(ids));
      }
      if (keywords.includes(DONE)) {
        out.push({ key: BADGE.done, icon: "check", label: t("badge.done"), title: t("badge.done_title"), color: "var(--color-success)" });
      }
      return out.length === before ? void 0 : out;
    },
    onMailboxChange() {
      void ensureStarted().then(loadGroups).then((learned) => {
        if (learned) refreshBadges();
      });
    },
    onAccountSwitch() {
      started = null;
      void ensureStarted();
    }
  };
  return {
    hooks,
    async activate(next) {
      if (next) api = next;
      started = null;
      await ensureStarted();
      if (!localeHooked) {
        localeHooked = true;
        api.i18n.onLocaleChange?.(() => {
          void publish();
        });
      }
    },
    /** For tests. */
    get self() {
      return self;
    },
    get people() {
      return people;
    },
    choicesFor
  };
}

// team-inbox/src/ui/assign-dialog.js
var import_ui = require("@plugin-host/ui");
var SEARCH_DELAY_MS = 400;
var MIN_SEARCH = 3;
function makeAssignDialog(React2, api) {
  const { createElement: h, useEffect, useState } = React2;
  const t = (key, vars) => api.i18n.t(key, vars);
  return function AssignDialog2(props) {
    const choices = Array.isArray(props.choices) ? props.choices : [];
    const [text, setText] = useState("");
    const [found, setFound] = useState([]);
    const [directoryOff, setDirectoryOff] = useState(false);
    const query = text.trim().toLowerCase();
    useEffect(() => {
      if (query.length < MIN_SEARCH || typeof api.user?.findPeople !== "function") {
        setFound([]);
        return void 0;
      }
      let live = true;
      const timer = setTimeout(() => {
        api.user.findPeople({ text: query, ...props.accountId ? { accountId: props.accountId } : {} }).then((result) => {
          if (!live) return;
          setDirectoryOff(result?.complete === false);
          setFound((result?.people ?? []).filter((p) => p.type !== "group"));
        }).catch(() => {
          if (live) setFound([]);
        });
      }, SEARCH_DELAY_MS);
      return () => {
        live = false;
        clearTimeout(timer);
      };
    }, [query, props.accountId]);
    const close = (value) => props.onResult?.(value);
    const listed = choices.filter((c) => !query || c.name.toLowerCase().includes(query) || c.email.includes(query));
    for (const p of found) {
      if (!listed.some((c) => c.id === p.id)) listed.push({ id: p.id, name: p.name, email: p.email, kind: "directory" });
    }
    const typed = looksLikeAddress(query) && !listed.some((c) => c.email === query) ? query : null;
    const subtitle = (c) => c.kind === "me" ? t("dialog.you") : c.email || c.note || void 0;
    return h(
      import_ui.Stack,
      { gap: 3 },
      h(
        import_ui.Field,
        { label: t("dialog.search"), hint: directoryOff ? t("dialog.no_directory") : void 0 },
        h(import_ui.Input, {
          value: text,
          autoFocus: true,
          placeholder: t("dialog.placeholder"),
          onChange: (e) => setText(e.target.value),
          onKeyDown: (e) => {
            if (e.key !== "Enter") return;
            if (typed) close({ address: typed });
            else if (listed.length === 1) close(listed[0]);
          }
        })
      ),
      listed.length > 0 ? h(
        import_ui.List,
        { label: t("dialog.people") },
        ...listed.map((c) => h(import_ui.ListRow, {
          key: c.id,
          icon: h(import_ui.Icon, { name: c.kind === "me" ? "user-check" : "user" }),
          title: c.name,
          subtitle: subtitle(c),
          onClick: () => close({ id: c.id, name: c.name, email: c.email })
        }))
      ) : h(import_ui.Text, { tone: "muted" }, t("dialog.empty")),
      h(import_ui.DialogButtons, {
        buttons: [
          { id: "cancel", label: t("dialog.cancel"), variant: "secondary" },
          { id: "assign", label: typed ? t("dialog.assign_address", { address: typed }) : t("dialog.assign"), variant: "primary", disabled: !typed }
        ],
        onClick: (id) => close(id === "assign" && typed ? { address: typed } : null)
      })
    );
  };
}

// team-inbox/src/index.js
var hostApi = require("@plugin-host");
var wiring = createWiring(hostApi);
var AssignDialog = makeAssignDialog(React, hostApi);
var index_default = {
  activate: (api) => wiring.activate(api),
  hooks: wiring.hooks,
  slots: {
    "plugin-dialog": {
      component: (props) => React.createElement(AssignDialog, props)
    }
  }
};
