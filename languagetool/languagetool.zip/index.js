var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// languagetool/src/index.js
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);

// languagetool/src/lib/languages.js
var LT_LANGUAGES = [
  "ar",
  "ast-ES",
  "be-BY",
  "br-FR",
  "ca-ES",
  "ca-ES-valencia",
  "crh-UA",
  "da-DK",
  "de",
  "de-AT",
  "de-CH",
  "de-DE",
  "el-GR",
  "en",
  "en-AU",
  "en-CA",
  "en-GB",
  "en-NZ",
  "en-US",
  "en-ZA",
  "eo",
  "es",
  "es-AR",
  "fa",
  "fr",
  "fr-BE",
  "fr-CA",
  "fr-CH",
  "ga-IE",
  "gl-ES",
  "it",
  "ja-JP",
  "km-KH",
  "nb",
  "nl",
  "nl-BE",
  "no",
  "pl-PL",
  "pt",
  "pt-AO",
  "pt-BR",
  "pt-MZ",
  "pt-PT",
  "ro-RO",
  "ru-RU",
  "sk-SK",
  "sl-SI",
  "sv",
  "ta-IN",
  "tl-PH",
  "uk-UA",
  "zh-CN"
];
var KNOWN = new Set(LT_LANGUAGES);
var VARIANT_DEFAULTS = { en: "en-US", de: "de-DE", pt: "pt-PT", ca: "ca-ES" };
var VARIANTS = {
  en: ["en-US", "en-GB", "en-AU", "en-CA", "en-NZ", "en-ZA"],
  de: ["de-DE", "de-AT", "de-CH"],
  pt: ["pt-PT", "pt-BR", "pt-AO", "pt-MZ"],
  ca: ["ca-ES", "ca-ES-valencia"]
};
var PICKER_LANGUAGES = [...new Set(LT_LANGUAGES.map((code) => VARIANTS[baseOf(code)] ? baseOf(code) : code))];
function baseOf(code) {
  return String(code).split("-")[0].toLowerCase();
}
function normalizeTag(tag) {
  if (typeof tag !== "string") return "";
  const parts = tag.trim().replace(/_/g, "-").split("-").filter(Boolean);
  if (!parts.length || !/^[A-Za-z]{2,3}$/.test(parts[0])) return "";
  return parts.map((p, i) => {
    if (i === 0) return p.toLowerCase();
    if (/^[A-Za-z]{2}$/.test(p)) return p.toUpperCase();
    return p.toLowerCase();
  }).join("-");
}
function cleanVariants(value) {
  const list2 = Array.isArray(value) ? value : String(value ?? "").split(",");
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const raw of list2) {
    const code = normalizeTag(raw);
    const base = baseOf(code);
    if (!code.includes("-") || !KNOWN.has(code) || seen.has(base)) continue;
    seen.add(base);
    out.push(code);
  }
  return out;
}
function toLtCode(tag, variants = []) {
  const code = normalizeTag(tag);
  if (!code) return null;
  const base = baseOf(code);
  const preferred = variants.find((v) => baseOf(v) === base);
  if (VARIANT_DEFAULTS[base]) {
    if (code !== base && KNOWN.has(code)) return code;
    return preferred ?? VARIANT_DEFAULTS[base];
  }
  if (KNOWN.has(code)) return code;
  if (code === "zh-TW" || code === "zh-HK" || code.startsWith("zh-Hant") || base === "nn") return null;
  if (KNOWN.has(base)) return base;
  const only = LT_LANGUAGES.filter((c) => baseOf(c) === base);
  return only.length ? only[0] : null;
}
function autoVariants(variants = []) {
  const out = cleanVariants(variants);
  for (const [base, fallback] of Object.entries(VARIANT_DEFAULTS)) {
    if (base === "ca") continue;
    if (!out.some((v) => baseOf(v) === base)) out.push(fallback);
  }
  return out;
}
function resolveLanguage({ writing = "auto", admin = {}, prefs = {}, userMayChange = true } = {}) {
  const variants = cleanVariants(userMayChange && cleanVariants(prefs.variants).length ? prefs.variants : admin.variants);
  const adminLanguage = normalizeTag(admin.language) || "auto";
  const userLanguage = userMayChange && prefs.language && prefs.language !== "follow" ? normalizeTag(prefs.language) : "";
  let wanted;
  if (!userMayChange && adminLanguage !== "auto") wanted = adminLanguage;
  else if (userLanguage) wanted = userLanguage;
  else if (writing && writing !== "auto") wanted = writing;
  else wanted = adminLanguage;
  if (wanted === "auto") return { language: "auto", preferredVariants: autoVariants(variants) };
  const code = toLtCode(wanted, variants);
  return code ? { language: code } : { unsupported: wanted };
}
function cleanMotherTongue(value) {
  if (!value) return "";
  return toLtCode(value) ?? "";
}

// languagetool/src/lib/config.js
var PUBLIC_ORIGIN = "https://api.languagetool.org";
var CREDENTIALS = {
  /** The admin's server, no token (a self-hosted LanguageTool needs none). */
  server: "server",
  /** The admin's server with the access token as a bearer header. */
  serverToken: "server-token",
  /** api.languagetool.org; never gets the token. */
  public: "public"
};
function list(value) {
  const items = Array.isArray(value) ? value : String(value ?? "").split(/[,;\n]/);
  const out = [];
  for (const raw of items) {
    const item = String(raw ?? "").trim();
    if (item && !out.includes(item)) out.push(item);
  }
  return out;
}
var bool = (value, fallback) => value === true || value === "true" ? true : value === false || value === "false" ? false : fallback;
function normalizeServerUrl(value) {
  if (typeof value !== "string" || !value.trim()) return null;
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (url.username || url.password || url.search || url.hash) return null;
  const path = url.pathname.replace(/\/+$/, "").replace(/\/v2(\/check)?$/i, "").replace(/\/+$/, "");
  return `${url.origin}${path}`;
}
function hostOf(value) {
  try {
    return new URL(value).host;
  } catch {
    return "";
  }
}
function readAdmin(config = {}) {
  const language = normalizeTag(config.defaultLanguage);
  return {
    serverUrl: normalizeServerUrl(config.serverUrl),
    allowPublic: bool(config.allowPublicApi, false),
    level: config.level === "picky" ? "picky" : "default",
    language: language && language !== "auto" && toLtCode(language) ? language : "auto",
    variants: cleanVariants(config.preferredVariants),
    disabledRules: list(config.disabledRules),
    disabledCategories: list(config.disabledCategories).map((c) => c.toUpperCase()),
    words: list(String(config.wordList ?? "").split("\n")),
    userMayChange: bool(config.userMayChange, true)
  };
}
function endpointFor(admin, { tokenSet = false, noThirdPartyTraffic = false } = {}) {
  if (admin.serverUrl) {
    return {
      credentialId: tokenSet ? CREDENTIALS.serverToken : CREDENTIALS.server,
      base: admin.serverUrl,
      host: hostOf(admin.serverUrl),
      isPublic: false
    };
  }
  if (!admin.allowPublic) return { off: "not_set_up" };
  if (noThirdPartyTraffic) return { off: "third_party" };
  return { credentialId: CREDENTIALS.public, base: PUBLIC_ORIGIN, host: hostOf(PUBLIC_ORIGIN), isPublic: true };
}
function readPrefs(raw) {
  const p = raw && typeof raw === "object" ? raw : {};
  const language = p.language && p.language !== "follow" ? normalizeTag(p.language) : "";
  return {
    language: language && toLtCode(language) ? language : "follow",
    variants: cleanVariants(p.variants),
    motherTongue: cleanMotherTongue(p.motherTongue),
    picky: typeof p.picky === "boolean" ? p.picky : null,
    warnBeforeSend: p.warnBeforeSend === true,
    disabledRules: Array.isArray(p.disabledRules) ? p.disabledRules.filter((r) => r && typeof r.id === "string" && r.id).map((r) => ({ id: r.id, label: typeof r.label === "string" ? r.label : "" })) : []
  };
}
function effectiveLevel(admin, prefs) {
  if (admin.userMayChange && typeof prefs.picky === "boolean") return prefs.picky ? "picky" : "default";
  return admin.level;
}
function userDisabledRules(admin, prefs) {
  return admin.userMayChange ? prefs.disabledRules.map((r) => r.id) : [];
}

// languagetool/src/lib/cache.js
var MAX_ENTRIES = 1e3;
function hash(text2) {
  let h1 = 3735928559;
  let h2 = 1103547991;
  for (let i = 0; i < text2.length; i++) {
    const ch = text2.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
function settingsKey(s) {
  return JSON.stringify([
    s.base,
    s.language,
    s.preferredVariants ?? [],
    s.motherTongue ?? "",
    s.level,
    [...s.disabledRules ?? []].sort(),
    [...s.disabledCategories ?? []].sort()
  ]);
}
function createCache(max = MAX_ENTRIES) {
  const map = /* @__PURE__ */ new Map();
  const keyOf = (settings, text2) => `${settings}${hash(text2)}:${text2.length}`;
  return {
    get(settings, text2) {
      const key = keyOf(settings, text2);
      if (!map.has(key)) return void 0;
      const value = map.get(key);
      map.delete(key);
      map.set(key, value);
      return value;
    },
    set(settings, text2, matches) {
      const key = keyOf(settings, text2);
      map.delete(key);
      map.set(key, matches);
      while (map.size > max) map.delete(map.keys().next().value);
    },
    clear() {
      map.clear();
    },
    get size() {
      return map.size;
    }
  };
}

// languagetool/src/lib/matches.js
var MAX_REPLACEMENTS = 5;
var STYLE_TYPES = /* @__PURE__ */ new Set(["style", "register", "locale-violation", "inconsistency", "terminology", "locale-specific-content"]);
var GRAMMAR_TYPES = /* @__PURE__ */ new Set([
  "grammar",
  "typographical",
  "duplication",
  "whitespace",
  "characters",
  "numbers",
  "omission",
  "addition",
  "non-conformance",
  "formatting",
  "markup",
  "pattern-problem",
  "inconsistent-entities"
]);
var STYLE_CATEGORIES = /* @__PURE__ */ new Set(["STYLE", "REDUNDANCY", "PLAIN_ENGLISH", "REGIONALISMS", "GENDER_NEUTRALITY", "WIKIPEDIA", "COLLOQUIALISMS"]);
var GRAMMAR_CATEGORIES = /* @__PURE__ */ new Set([
  "GRAMMAR",
  "PUNCTUATION",
  "TYPOGRAPHY",
  "CASING",
  "CONFUSED_WORDS",
  "COMPOUNDING",
  "COLLOCATIONS",
  "SEMANTICS",
  "NONSTANDARD_PHRASES",
  "MISUSED_TERMS_EU_PUBLICATIONS",
  "AMERICAN_ENGLISH_STYLE",
  "BRITISH_ENGLISH"
]);
function kindOf(rule) {
  const issueType = String(rule?.issueType ?? "").toLowerCase();
  const category = String(rule?.category?.id ?? "").toUpperCase();
  if (issueType === "misspelling" || category === "TYPOS") return "spelling";
  if (STYLE_TYPES.has(issueType)) return "style";
  if (GRAMMAR_TYPES.has(issueType)) return "grammar";
  if (STYLE_CATEGORIES.has(category)) return "style";
  if (GRAMMAR_CATEGORIES.has(category)) return "grammar";
  return "other";
}
var text = (v) => typeof v === "string" ? v.trim() : "";
function normalizeMatch(m) {
  if (!m || typeof m !== "object") return null;
  const { offset, length } = m;
  if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 1) return null;
  const rule = m.rule && typeof m.rule === "object" ? m.rule : {};
  const message = text(m.message) || text(m.shortMessage) || text(rule.description);
  if (!message) return null;
  const replacements = [];
  for (const r of Array.isArray(m.replacements) ? m.replacements : []) {
    if (replacements.length >= MAX_REPLACEMENTS) break;
    const value = r && typeof r.value === "string" ? r.value : null;
    if (!value || /[\r\n]/.test(value) || replacements.includes(value)) continue;
    replacements.push(value);
  }
  const out = { offset, length, kind: kindOf(rule), message, replacements };
  const short = text(m.shortMessage);
  if (short && short !== message) out.shortMessage = short;
  if (text(rule.id)) out.ruleId = text(rule.id);
  if (text(rule.description)) out.ruleLabel = text(rule.description);
  if (text(rule.category?.id)) out.categoryId = text(rule.category.id).toUpperCase();
  return out;
}

// languagetool/src/lib/request.js
var OBJECT_CHAR = "￼";
var SEPARATOR = "\n\n";
var encoder = new TextEncoder();
var byteLength = (s) => encoder.encode(s).length;
var isHigh = (c) => c >= 55296 && c <= 56319;
function cutPoint(text2, maxBytes) {
  let end = Math.min(text2.length, maxBytes);
  while (end > 0 && byteLength(text2.slice(0, end)) > maxBytes) end = Math.floor(end * 0.9);
  if (end >= text2.length) return text2.length;
  const head = text2.slice(0, end);
  const min = Math.floor(end / 2);
  const line = head.lastIndexOf("\n");
  if (line >= min) return line + 1;
  let sentence = -1;
  for (const m of head.matchAll(/[.!?。！？]["'»”’)]*\s+/g)) sentence = m.index + m[0].length;
  if (sentence >= min) return sentence;
  const space = head.search(/\s\S*$/);
  if (space >= min) return space + 1;
  return isHigh(text2.charCodeAt(end - 1)) ? end - 1 : end;
}
function toUnits(segments, maxBytes) {
  const units = [];
  for (const seg of segments) {
    let rest = seg.text;
    let base = 0;
    while (rest.length) {
      const cut = byteLength(rest) <= maxBytes ? rest.length : Math.max(1, cutPoint(rest, maxBytes));
      units.push({ segmentId: seg.id, text: rest.slice(0, cut), base });
      base += cut;
      rest = rest.slice(cut);
    }
  }
  return units;
}
function toBatches(units, maxBytes) {
  const batches = [];
  let current = [];
  let size = 0;
  for (const unit of units) {
    const bytes = byteLength(unit.text);
    const extra = current.length ? SEPARATOR.length : 0;
    if (current.length && size + extra + bytes > maxBytes) {
      batches.push(current);
      current = [];
      size = 0;
    }
    size += (current.length ? SEPARATOR.length : 0) + bytes;
    current.push(unit);
  }
  if (current.length) batches.push(current);
  return batches;
}
function buildData(units, objectChar = OBJECT_CHAR) {
  const annotation = [];
  const layout = [];
  let at = 0;
  units.forEach((unit, i) => {
    if (i > 0) {
      annotation.push({ markup: SEPARATOR, interpretAs: SEPARATOR });
      at += SEPARATOR.length;
    }
    layout.push({ ...unit, start: at, end: at + unit.text.length });
    const parts = unit.text.split(objectChar);
    parts.forEach((part, j) => {
      if (j > 0) annotation.push({ markup: objectChar, interpretAs: " " });
      if (part) annotation.push({ text: part });
    });
    at += unit.text.length;
  });
  return { data: JSON.stringify({ annotation }), layout };
}
function buildForm({ data, language, preferredVariants, motherTongue, level, disabledRules, disabledCategories }) {
  const form = new URLSearchParams();
  form.set("data", data);
  form.set("language", language);
  if (language === "auto" && preferredVariants?.length) form.set("preferredVariants", preferredVariants.join(","));
  if (motherTongue) form.set("motherTongue", motherTongue);
  form.set("level", level === "picky" ? "picky" : "default");
  if (disabledRules?.length) form.set("disabledRules", disabledRules.join(","));
  if (disabledCategories?.length) form.set("disabledCategories", disabledCategories.join(","));
  form.set("enabledOnly", "false");
  return form.toString();
}
function mapMatches(matches, layout, segmentTexts, objectChar = OBJECT_CHAR) {
  const out = /* @__PURE__ */ new Map();
  for (const unit of layout) if (!out.has(unit.segmentId)) out.set(unit.segmentId, []);
  for (const raw of Array.isArray(matches) ? matches : []) {
    const m = normalizeMatch(raw);
    if (!m) continue;
    const unit = layout.find((u) => m.offset >= u.start && m.offset + m.length <= u.end);
    if (!unit) continue;
    const offset = unit.base + (m.offset - unit.start);
    const text2 = segmentTexts.get(unit.segmentId) ?? "";
    const covered = text2.slice(offset, offset + m.length);
    if (covered.length !== m.length || covered.includes(objectChar) || covered.includes("\n") || !covered.trim()) continue;
    out.get(unit.segmentId).push({ ...m, offset, text: covered });
  }
  return out;
}

// languagetool/src/lib/errors.js
var DEFAULT_PAUSE_MS = 6e4;
var MAX_PAUSE_MS = 10 * 6e4;
function retryAfterMs(value, now = Date.now(), fallback = DEFAULT_PAUSE_MS) {
  if (value === void 0 || value === null || value === "") return fallback;
  const s = String(value).trim();
  let ms;
  if (/^\d+(\.\d+)?$/.test(s)) ms = Number(s) * 1e3;
  else {
    const at = Date.parse(s);
    ms = Number.isNaN(at) ? NaN : at - now;
  }
  if (!Number.isFinite(ms) || ms <= 0) return fallback;
  return Math.min(Math.max(ms, 1e3), MAX_PAUSE_MS);
}
function header(headers, name) {
  if (!headers || typeof headers !== "object") return void 0;
  for (const [k, v] of Object.entries(headers)) if (k.toLowerCase() === name) return v;
  return void 0;
}
function bodyText(body) {
  if (typeof body === "string") return body;
  if (body && typeof body === "object") {
    try {
      return JSON.stringify(body);
    } catch {
      return "";
    }
  }
  return "";
}
var PROXY_ERRORS = {
  no_credential: "error.not_set_up",
  blocked_address: "error.blocked",
  timeout: "error.timeout",
  unreachable: "error.unreachable",
  wrong_origin: "error.wrong_url",
  redirect_off_origin: "error.wrong_url",
  too_many_redirects: "error.wrong_url",
  bad_url: "error.wrong_url",
  too_large: "error.too_long",
  disabled: "error.not_set_up",
  store_unavailable: "error.unreachable"
};
function classifyResponse(res, { now = Date.now() } = {}) {
  if (!res || typeof res !== "object") return { status: "unavailable", key: "error.network" };
  const code = Number(res.status) || 0;
  const text2 = bodyText(res.body);
  const proxyError = typeof res.proxyError === "string" ? res.proxyError : "";
  if (code === 429 || proxyError === "rate_limited") {
    return { status: "paused", key: "error.rate_limited", retryAfterMs: retryAfterMs(header(res.headers, "retry-after"), now) };
  }
  if (code === 403 && /no-third-party-traffic/.test(text2)) return { status: "unavailable", key: "error.third_party" };
  if (proxyError) return { status: "unavailable", key: PROXY_ERRORS[proxyError] ?? "error.unreachable" };
  if (code >= 200 && code < 300) return null;
  if (code === 400 || code === 413) {
    if (/language code|not a language|language.*not supported|unsupported language|no.*language.*(found|known)/i.test(text2)) {
      return { status: "unavailable", key: "error.language" };
    }
    if (code === 413 || /exceeds the limit|text is too long|too long/i.test(text2)) return { status: "unavailable", key: "error.too_long" };
    return { status: "unavailable", key: "error.request", vars: { status: code } };
  }
  if (code === 401 || code === 403) return { status: "unavailable", key: "error.auth" };
  if (code === 404 || code === 405) return { status: "unavailable", key: "error.wrong_url" };
  if (code === 502 || code === 503 || code === 504) return { status: "unavailable", key: "error.server", vars: { status: code } };
  return { status: "unavailable", key: "error.server", vars: { status: code || "?" } };
}
function parseCheckBody(body) {
  let json = body;
  if (typeof body === "string") {
    try {
      json = JSON.parse(body);
    } catch {
      return null;
    }
  }
  if (!json || typeof json !== "object" || !Array.isArray(json.matches)) return null;
  return json;
}

// languagetool/src/lib/words.js
var MAX_WORD_LENGTH = 100;
var MAX_DICTIONARY_WORDS = 5e3;
function cleanWord(value) {
  if (typeof value !== "string") return "";
  const word = value.replace(/[\r\n\t]+/g, " ").trim();
  return word.length > MAX_WORD_LENGTH ? "" : word;
}
var hasLetters = (s) => s.toLowerCase() !== s.toUpperCase();
function wordMatcher(...lists) {
  const exact = /* @__PURE__ */ new Set();
  const upper = /* @__PURE__ */ new Set();
  const lower = /* @__PURE__ */ new Set();
  const add = (word) => {
    if (!word) return;
    exact.add(word);
    upper.add(word.toUpperCase());
    if (word === word.toLowerCase() && hasLetters(word)) lower.add(word);
  };
  for (const items of lists) {
    for (const raw of items ?? []) {
      const word = cleanWord(raw);
      if (!word) continue;
      add(word);
      const parts = word.split(/\s+/);
      if (parts.length > 1) {
        for (const part of parts) if (hasLetters(part)) add(part);
      }
    }
  }
  return {
    size: exact.size,
    has(text2) {
      if (typeof text2 !== "string" || !text2) return false;
      if (exact.has(text2)) return true;
      if (hasLetters(text2) && text2 === text2.toUpperCase() && upper.has(text2)) return true;
      return lower.has(text2.toLowerCase());
    }
  };
}
function addWord(words, word) {
  const clean = cleanWord(word);
  const current = Array.isArray(words) ? words.filter((w) => typeof w === "string") : [];
  if (!clean || current.includes(clean) || current.length >= MAX_DICTIONARY_WORDS) return current;
  return [...current, clean].sort((a, b) => a.localeCompare(b));
}
function removeWord(words, word) {
  return (Array.isArray(words) ? words : []).filter((w) => w !== word);
}

// languagetool/src/lib/checker.js
var PUBLIC_MAX_BYTES = 19e3;
var SERVER_MAX_BYTES = 1e5;
var PUBLIC_REQUESTS_PER_MINUTE = 20;
var PUBLIC_BYTES_PER_MINUTE = 75e3;
var CHECK_BUDGET_MS = 13e3;
function checkSettings({ admin, prefs, endpoint, writing }) {
  const lang = resolveLanguage({ writing, admin, prefs, userMayChange: admin.userMayChange });
  if (lang.unsupported) return { unsupported: lang.unsupported };
  return {
    credentialId: endpoint.credentialId,
    base: endpoint.base,
    isPublic: endpoint.isPublic,
    language: lang.language,
    preferredVariants: lang.preferredVariants ?? [],
    motherTongue: cleanMotherTongue(prefs.motherTongue),
    level: effectiveLevel(admin, prefs),
    disabledRules: admin.disabledRules,
    disabledCategories: admin.disabledCategories
  };
}
var ignoreKey = (ruleId, text2) => `${ruleId ?? ""}\0${text2}`;
function filterMatches(matches, { words, ignored, userRules = [], adminRules = [], adminCategories = [] }) {
  const rules = /* @__PURE__ */ new Set([...userRules, ...adminRules]);
  const categories = new Set(adminCategories.map((c) => c.toUpperCase()));
  return matches.filter((m) => {
    if (m.ruleId && rules.has(m.ruleId)) return false;
    if (m.categoryId && categories.has(m.categoryId)) return false;
    if (m.kind === "spelling" && words?.has(m.text)) return false;
    if (ignored?.has(ignoreKey(m.ruleId, m.text))) return false;
    return true;
  });
}
function toAnnotation(segmentId, m) {
  const a = { segmentId, offset: m.offset, length: m.length, kind: m.kind, message: m.message, replacements: m.replacements };
  if (m.shortMessage) a.shortMessage = m.shortMessage;
  if (m.ruleId) a.ruleId = m.ruleId;
  if (m.ruleLabel) a.ruleLabel = m.ruleLabel;
  return a;
}
function createBudget({ requests = PUBLIC_REQUESTS_PER_MINUTE, bytes = PUBLIC_BYTES_PER_MINUTE, windowMs = 6e4 } = {}) {
  const sent = [];
  const prune = (now) => {
    while (sent.length && now - sent[0].at >= windowMs) sent.shift();
  };
  return {
    /** 0 when `size` bytes may go now, else how long to wait. */
    wait(size, now) {
      prune(now);
      let used = sent.reduce((n, s) => n + s.size, 0);
      if (sent.length < requests && used + size <= bytes) return 0;
      let count = sent.length;
      for (const s of sent) {
        count--;
        used -= s.size;
        if (count < requests && used + size <= bytes) return Math.max(1e3, s.at + windowMs - now);
      }
      return windowMs;
    },
    record(size, now) {
      sent.push({ at: now, size });
    }
  };
}
function withTimeout(promise, ms, controller) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => {
        controller?.abort();
        reject(Object.assign(new Error("timeout"), { timeout: true }));
      }, ms);
    })
  ]).finally(() => clearTimeout(timer));
}
async function runCheck(request, ctx) {
  const { api, admin, prefs, endpoint, cache, budget, now = () => Date.now() } = ctx;
  const t = ctx.t ?? ((key2) => key2);
  const fail = (status, key2, vars, retry) => ({
    status,
    message: t(key2, vars),
    ...retry ? { retryAfterMs: retry } : {}
  });
  if (!endpoint || endpoint.off) return fail("unavailable", endpoint?.off === "third_party" ? "error.third_party" : "error.not_set_up");
  const segments = Array.isArray(request?.segments) ? request.segments.filter((s) => s && typeof s.id === "string" && typeof s.text === "string") : [];
  const objectChar = typeof request?.objectReplacement === "string" && request.objectReplacement ? request.objectReplacement : OBJECT_CHAR;
  const settings = checkSettings({ admin, prefs, endpoint, writing: request?.language });
  if (settings.unsupported) return fail("unavailable", "error.language");
  const key = settingsKey(settings);
  const found = /* @__PURE__ */ new Map();
  const missing = [];
  for (const seg of segments) {
    const hit = cache.get(key, seg.text);
    if (hit) found.set(seg.id, hit);
    else if (!missing.some((m) => m.text === seg.text)) missing.push(seg);
  }
  if (missing.length) {
    const maxBytes = settings.isPublic ? PUBLIC_MAX_BYTES : SERVER_MAX_BYTES;
    const texts = new Map(missing.map((s) => [s.id, s.text]));
    const batches = toBatches(toUnits(missing, maxBytes), maxBytes);
    const started = now();
    const results = new Map(missing.map((s) => [s.id, []]));
    const url = `${settings.base}/v2/check`;
    for (const batch of batches) {
      const { data, layout } = buildData(batch, objectChar);
      const size = byteLength(batch.map((u) => u.text).join("\n\n"));
      if (settings.isPublic && budget) {
        const wait = budget.wait(size, now());
        if (wait > 0) return fail("paused", "error.public_limit", void 0, wait);
      }
      const left = (ctx.checkBudgetMs ?? CHECK_BUDGET_MS) - (now() - started);
      if (left <= 500) return fail("unavailable", "error.timeout");
      const body = buildForm({ ...settings, data });
      const controller = typeof AbortController === "function" ? new AbortController() : null;
      let res;
      try {
        if (settings.isPublic && budget) budget.record(size, now());
        res = await withTimeout(api.proxy.fetch(settings.credentialId, url, {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
          body,
          responseType: "text",
          ...controller ? { signal: controller.signal } : {}
        }), left, controller);
      } catch (err) {
        return fail("unavailable", err?.timeout ? "error.timeout" : "error.network");
      }
      const problem = classifyResponse(res, { now: now() });
      if (problem) return fail(problem.status, problem.key, problem.vars, problem.retryAfterMs);
      const json = parseCheckBody(res.body);
      if (!json) return fail("unavailable", "error.wrong_url");
      for (const [id, list2] of mapMatches(json.matches, layout, texts, objectChar)) results.get(id).push(...list2);
    }
    for (const seg of missing) {
      const list2 = results.get(seg.id) ?? [];
      list2.sort((a, b) => a.offset - b.offset);
      cache.set(key, seg.text, list2);
    }
    for (const seg of segments) if (!found.has(seg.id)) found.set(seg.id, cache.get(key, seg.text) ?? []);
  }
  const words = ctx.words ?? wordMatcher(ctx.dictionary ?? [], admin.words);
  const filter = {
    words,
    ignored: ctx.ignored,
    userRules: userDisabledRules(admin, prefs),
    adminRules: admin.disabledRules,
    adminCategories: admin.disabledCategories
  };
  const annotations = [];
  for (const seg of segments) {
    for (const m of filterMatches(found.get(seg.id) ?? [], filter)) annotations.push(toAnnotation(seg.id, m));
  }
  return { status: "ok", annotations };
}

// languagetool/src/lib/prefs.js
var KEYS = { prefs: "prefs", dictionary: "dictionary", rev: "rev" };
var seq = 0;
var newRev = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}-${(seq++).toString(36)}`;
async function get(api, key) {
  try {
    return await api.storage.get(key);
  } catch {
    return null;
  }
}
async function loadRev(api) {
  return await get(api, KEYS.rev) ?? null;
}
async function loadAll(api) {
  const [prefs, dictionary, rev] = await Promise.all([get(api, KEYS.prefs), get(api, KEYS.dictionary), get(api, KEYS.rev)]);
  return {
    prefs: readPrefs(prefs),
    dictionary: Array.isArray(dictionary) ? dictionary.filter((w) => typeof w === "string") : [],
    rev: rev ?? null
  };
}
async function bump(api) {
  const rev = newRev();
  await api.storage.set(KEYS.rev, rev);
  return rev;
}
async function savePrefs(api, patch) {
  const current = readPrefs(await get(api, KEYS.prefs));
  await api.storage.set(KEYS.prefs, { ...current, ...patch });
  return bump(api);
}
async function addToDictionary(api, word) {
  const { dictionary } = await loadAll(api);
  const next = addWord(dictionary, word);
  if (next === dictionary || next.length === dictionary.length) return { added: false, rev: null };
  await api.storage.set(KEYS.dictionary, next);
  return { added: true, rev: await bump(api) };
}
async function removeFromDictionary(api, word) {
  const { dictionary } = await loadAll(api);
  await api.storage.set(KEYS.dictionary, removeWord(dictionary, word));
  return bump(api);
}
async function disableRule(api, rule) {
  const { prefs } = await loadAll(api);
  if (!rule?.id || prefs.disabledRules.some((r) => r.id === rule.id)) return { added: false, rev: null };
  const rev = await savePrefs(api, { disabledRules: [...prefs.disabledRules, { id: rule.id, label: rule.label ?? "" }] });
  return { added: true, rev };
}
async function enableRule(api, ruleId) {
  const { prefs } = await loadAll(api);
  return savePrefs(api, { disabledRules: prefs.disabledRules.filter((r) => r.id !== ruleId) });
}

// languagetool/src/lib/background.js
var CHECKER_ID = "languagetool";
var POLL_MS = 5e3;
var CONFIG_TTL_MS = 6e4;
var MAX_COMPOSERS = 50;
function createBackground(api, {
  pollMs = POLL_MS,
  configTtlMs = CONFIG_TTL_MS,
  now = () => Date.now(),
  setInterval: every = (fn, ms) => setInterval(fn, ms),
  clearInterval: stop = (id) => clearInterval(id)
} = {}) {
  const cache = createCache();
  const budget = createBudget();
  const ignores = /* @__PURE__ */ new Map();
  let handle = null;
  let timer = null;
  let admin = readAdmin({});
  let tokenSet = false;
  let configAt = -Infinity;
  let configSig = "";
  let prefsState = { prefs: null, dictionary: [], rev: void 0 };
  let words = wordMatcher([]);
  let warn = false;
  const t = (key, vars) => api.i18n?.t?.(key, vars) ?? key;
  const features = () => api.host?.features ?? {};
  const endpoint = () => endpointFor(admin, { tokenSet, noThirdPartyTraffic: features().noThirdPartyTraffic === true });
  async function refreshConfig(force = false) {
    if (!force && now() - configAt < configTtlMs) return false;
    configAt = now();
    const [raw, accounts] = await Promise.all([
      Promise.resolve().then(() => api.config.get()).catch(() => null),
      Promise.resolve().then(() => api.proxy.accounts()).catch(() => null)
    ]);
    if (raw && typeof raw === "object") admin = readAdmin(raw);
    if (Array.isArray(accounts)) tokenSet = accounts.some((a) => a?.credentialId === CREDENTIALS.serverToken && a.connected);
    const sig = JSON.stringify([admin, tokenSet]);
    const changed = configSig !== "" && sig !== configSig;
    configSig = sig;
    return changed;
  }
  async function refreshPrefs(force = false) {
    if (!force) {
      const rev = await loadRev(api);
      if (rev === prefsState.rev) return false;
    }
    const before = prefsState.rev;
    prefsState = await loadAll(api);
    words = wordMatcher(prefsState.dictionary, admin.words);
    await applyWarn();
    return before !== void 0 && prefsState.rev !== before;
  }
  async function applyWarn() {
    const want = prefsState.prefs?.warnBeforeSend === true;
    if (!handle || want === warn) return;
    try {
      await handle.update({ warnBeforeSend: want });
      warn = want;
    } catch (err) {
      api.log?.warn?.("Could not change the send warning", err?.message ?? err);
    }
  }
  function recheck() {
    if (handle) void Promise.resolve().then(() => handle.recheck()).catch(() => {
    });
  }
  async function sync() {
    const configChanged = await refreshConfig();
    if (configChanged) words = wordMatcher(prefsState.dictionary, admin.words);
    const prefsChanged = await refreshPrefs();
    if (configChanged || prefsChanged) recheck();
  }
  function ignoredFor(composerId) {
    let set = ignores.get(composerId);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      ignores.set(composerId, set);
      while (ignores.size > MAX_COMPOSERS) ignores.delete(ignores.keys().next().value);
    }
    return set;
  }
  async function check(request) {
    try {
      await sync();
    } catch {
    }
    return runCheck(request, {
      api,
      admin,
      prefs: prefsState.prefs,
      dictionary: prefsState.dictionary,
      words,
      endpoint: endpoint(),
      cache,
      budget,
      now,
      t,
      ignored: ignores.get(request?.composerId)
    });
  }
  async function onAction(event) {
    const a = event?.annotation;
    if (!a || typeof a.text !== "string" || !a.text) return;
    switch (event.action) {
      case "ignore":
        if (typeof event.composerId === "string") ignoredFor(event.composerId).add(ignoreKey(a.ruleId, a.text));
        return;
      case "dictionary": {
        const { added, rev } = await addToDictionary(api, a.text);
        if (!added) return;
        await refreshPrefs(true);
        prefsState.rev = rev ?? prefsState.rev;
        recheck();
        return;
      }
      case "disable-rule": {
        if (!admin.userMayChange || !a.ruleId) return;
        const { added, rev } = await disableRule(api, { id: a.ruleId, label: a.ruleLabel });
        if (!added) return;
        await refreshPrefs(true);
        prefsState.rev = rev ?? prefsState.rev;
        recheck();
        return;
      }
      default:
    }
  }
  async function activate() {
    await refreshConfig(true).catch(() => {
    });
    await refreshPrefs(true).catch(() => {
    });
    warn = prefsState.prefs?.warnBeforeSend === true;
    handle = await api.composer.registerChecker({
      id: CHECKER_ID,
      label: "LanguageTool",
      kinds: ["spelling", "grammar", "style", "other"],
      debounceMs: 800,
      languages: LT_LANGUAGES,
      warnBeforeSend: warn,
      check,
      onAction
    });
    api.host?.onFeaturesChange?.(() => recheck());
    timer = every(() => {
      void sync().catch(() => {
      });
    }, pollMs);
    return handle;
  }
  function dispose() {
    if (timer !== null) stop(timer);
    timer = null;
  }
  return { activate, check, onAction, sync, dispose, get handle() {
    return handle;
  }, get admin() {
    return admin;
  } };
}

// languagetool/src/ui/SettingsPanel.jsx
var import_react = require("react");
var import_ui = require("@plugin-host/ui");
var import_jsx_runtime = require("react/jsx-runtime");
var host = () => require("@plugin-host");
var useApi = (props) => props?.api ?? host();
function languageName(code, locale) {
  try {
    return new Intl.DisplayNames([locale || "en"], { type: "language" }).of(code) || code;
  } catch {
    return code;
  }
}
function variantFor(base, prefs, admin) {
  const own = admin.userMayChange ? prefs.variants.find((v) => baseOf(v) === base) : void 0;
  return own ?? admin.variants.find((v) => baseOf(v) === base) ?? VARIANT_DEFAULTS[base];
}
var VARIANT_LANGUAGES = ["en", "de", "pt"];
function SettingsPanel(props) {
  const api = useApi(props);
  const t = api.i18n.t;
  const locale = api.i18n.locale;
  const [state, setState] = (0, import_react.useState)(null);
  const [word, setWord] = (0, import_react.useState)("");
  const reload = (0, import_react.useCallback)(async () => {
    const [config, stored] = await Promise.all([
      Promise.resolve().then(() => api.config.get()).catch(() => ({})),
      loadAll(api)
    ]);
    setState({ admin: readAdmin(config ?? {}), ...stored });
  }, [api]);
  (0, import_react.useEffect)(() => {
    void reload();
  }, [reload]);
  if (!state) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Loading, { label: t("settings.loading") });
  const { admin, prefs, dictionary } = state;
  const locked = !admin.userMayChange;
  const endpoint = endpointFor(admin, { noThirdPartyTraffic: api.host?.features?.noThirdPartyTraffic === true });
  const save = async (patch) => {
    await savePrefs(api, patch);
    await reload();
  };
  const status = endpoint.off === "third_party" ? t("settings.status_third_party") : endpoint.off ? t("settings.status_not_set_up") : endpoint.isPublic ? t("settings.status_public", { host: endpoint.host }) : t("settings.status_server", { host: endpoint.host });
  const language = locked ? admin.language === "auto" ? "follow" : admin.language : prefs.language;
  const languageOptions = [
    { value: "follow", label: t("settings.language_follow") },
    ...PICKER_LANGUAGES.map((code) => ({ value: code, label: languageName(code, locale) })).sort((a, b) => a.label.localeCompare(b.label, locale))
  ];
  if (!languageOptions.some((o) => o.value === language)) languageOptions.push({ value: language, label: languageName(language, locale) });
  const languageBase = language === "follow" ? null : baseOf(normalizeTag(language));
  const variantRows = language === "follow" ? VARIANT_LANGUAGES : VARIANT_LANGUAGES.filter((b) => b === languageBase);
  const setVariant = (base, value) => {
    const current = VARIANT_LANGUAGES.map((b) => variantFor(b, prefs, admin)).filter((v) => baseOf(v) !== base);
    void save({ variants: [...current, value] });
  };
  const addWord2 = async () => {
    const clean = cleanWord(word);
    if (!clean) return;
    await addToDictionary(api, clean);
    setWord("");
    await reload();
  };
  const picky = effectiveLevel(admin, prefs) === "picky";
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 6, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Section, { title: t("settings.title"), description: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { "data-testid": "lt-status", children: status }), children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 2, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", size: "xs", children: t("settings.privacy") }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", size: "xs", children: t("settings.switch_hint") }),
        endpoint.isPublic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Text, { tone: "muted", size: "xs", children: [
          t("settings.public_credit"),
          " ",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Link, { href: "https://languagetool.org", children: "languagetool.org" })
        ] })
      ] }),
      locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Alert, { tone: "info", icon: "lock", children: t("settings.locked") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 0, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.SettingRow, { label: t("settings.language"), description: t("settings.language_hint"), htmlFor: "lt-language", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          import_ui.Select,
          {
            id: "lt-language",
            "aria-label": t("settings.language"),
            value: language,
            disabled: locked,
            options: languageOptions,
            onChange: (value) => void save({ language: value })
          }
        ) }),
        variantRows.map((base) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.SettingRow, { label: t("settings.variant", { language: languageName(base, locale) }), htmlFor: `lt-variant-${base}`, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          import_ui.Select,
          {
            id: `lt-variant-${base}`,
            "aria-label": t("settings.variant", { language: languageName(base, locale) }),
            value: variantFor(base, prefs, admin),
            disabled: locked,
            options: VARIANTS[base].map((code) => ({ value: code, label: languageName(code, locale) })),
            onChange: (value) => setVariant(base, value)
          }
        ) }, base)),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.SettingRow, { label: t("settings.mother_tongue"), description: t("settings.mother_tongue_hint"), htmlFor: "lt-mother-tongue", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          import_ui.Select,
          {
            id: "lt-mother-tongue",
            "aria-label": t("settings.mother_tongue"),
            value: prefs.motherTongue || "",
            options: [
              { value: "", label: t("settings.mother_tongue_none") },
              ...PICKER_LANGUAGES.map((code) => ({ value: code, label: languageName(code, locale) })).sort((a, b) => a.label.localeCompare(b.label, locale))
            ],
            onChange: (value) => void save({ motherTongue: value })
          }
        ) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.SettingRow, { label: t("settings.picky"), description: t("settings.picky_hint"), htmlFor: "lt-picky", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Switch, { id: "lt-picky", label: t("settings.picky"), checked: picky, disabled: locked, onChange: (on) => void save({ picky: on }) }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.SettingRow, { label: t("settings.warn"), description: t("settings.warn_hint"), htmlFor: "lt-warn", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Switch, { id: "lt-warn", label: t("settings.warn"), checked: prefs.warnBeforeSend, onChange: (on) => void save({ warnBeforeSend: on }) }) })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Section, { title: t("settings.dictionary"), description: t("settings.dictionary_hint"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 3, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Row, { wrap: false, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          import_ui.Input,
          {
            value: word,
            "aria-label": t("settings.dictionary_placeholder"),
            placeholder: t("settings.dictionary_placeholder"),
            maxLength: 100,
            onChange: (e) => setWord(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                void addWord2();
              }
            }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Button, { variant: "secondary", disabled: !cleanWord(word), onClick: () => void addWord2(), children: t("settings.dictionary_add") })
      ] }),
      dictionary.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Row, { children: dictionary.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_ui.Chip,
        {
          label: w,
          onRemove: () => void removeFromDictionary(api, w).then(reload),
          removeLabel: t("settings.dictionary_remove", { word: w })
        },
        w
      )) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", children: t("settings.dictionary_empty") }),
      admin.words.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", size: "xs", children: t("settings.dictionary_org", { count: admin.words.length }) })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Section, { title: t("settings.rules"), description: t("settings.rules_hint"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 3, children: [
      locked && prefs.disabledRules.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", size: "xs", children: t("settings.rules_locked") }),
      prefs.disabledRules.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Row, { children: prefs.disabledRules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_ui.Chip,
        {
          label: r.label || r.id,
          title: r.id,
          ...locked ? {} : {
            onRemove: () => void enableRule(api, r.id).then(reload),
            removeLabel: t("settings.rule_remove", { rule: r.label || r.id })
          }
        },
        r.id
      )) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", children: t("settings.rules_empty") }),
      admin.disabledRules.length + admin.disabledCategories.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", size: "xs", children: t("settings.rules_admin", { count: admin.disabledRules.length + admin.disabledCategories.length }) })
    ] }) })
  ] });
}

// languagetool/src/index.js
var background = null;
var index_default = {
  async activate(api) {
    background = createBackground(api);
    await background.activate();
  },
  slots: {
    "settings-section": { component: SettingsPanel }
  }
};
