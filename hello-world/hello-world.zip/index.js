// src/index.js
function activate(api) {
  api.log.info("Hello World plugin activated!");
  const count = (api.storage.get("activationCount") || 0) + 1;
  api.storage.set("activationCount", count);
  if (count === 1) {
    api.toast.success("Hello World plugin installed successfully!");
  }
  const appReady = api.hooks.onAppReady(() => {
    api.log.info("App is ready \u2014 Hello World is running");
  });
  const emailOpen = api.hooks.onEmailOpen((email) => {
    api.log.info(`Email opened: "${email.subject}" from ${email.from}`);
  });
  const newEmail = api.hooks.onNewEmailReceived((notification) => {
    api.log.info("New email received:", notification);
  });
  return {
    dispose: () => {
      appReady.dispose();
      emailOpen.dispose();
      newEmail.dispose();
      api.log.info("Hello World plugin deactivated");
    }
  };
}
function deactivate() {
}
export {
  activate,
  deactivate
};
