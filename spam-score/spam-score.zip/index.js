"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h } = require("react");
function getHeader(headers, name) {
  if (!headers) return void 0;
  const wanted = name.toLowerCase();
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === wanted) {
      const v = headers[key];
      return Array.isArray(v) ? v[0] : v;
    }
  }
  return void 0;
}
function toNumber(raw) {
  if (raw == null) return void 0;
  const m = String(raw).match(/-?\d+(?:\.\d+)?/);
  if (!m) return void 0;
  const n = parseFloat(m[0]);
  return Number.isFinite(n) ? n : void 0;
}
function parseSpam(headers) {
  if (!headers) return null;
  const status = getHeader(headers, "X-Spam-Status");
  const scoreH = getHeader(headers, "X-Spam-Score");
  const level = getHeader(headers, "X-Spam-Level");
  const flag = getHeader(headers, "X-Spam-Flag");
  const rspamdScore = getHeader(headers, "X-Rspamd-Score");
  const spamdResult = getHeader(headers, "X-Spamd-Result");
  const rspamdAction = getHeader(headers, "X-Rspamd-Action") || getHeader(headers, "X-Spam-Action");
  const llmH = getHeader(headers, "X-Spam-LLM");
  if (!status && scoreH == null && level == null && flag == null && rspamdScore == null && spamdResult == null && rspamdAction == null && !llmH) {
    return null;
  }
  let score;
  let required;
  if (status) {
    const sm = status.match(/score=\s*(-?\d+(?:\.\d+)?)/i);
    if (sm) score = parseFloat(sm[1]);
    const rm = status.match(/required=\s*(-?\d+(?:\.\d+)?)/i);
    if (rm) required = parseFloat(rm[1]);
  }
  if (score == null && scoreH != null) score = toNumber(scoreH);
  if (score == null && rspamdScore != null) score = toNumber(rspamdScore);
  if ((score == null || required == null) && spamdResult) {
    const br = spamdResult.match(/\[\s*(-?\d+(?:\.\d+)?)\s*\/\s*(-?\d+(?:\.\d+)?)\s*\]/);
    if (br) {
      if (score == null) score = parseFloat(br[1]);
      if (required == null) required = parseFloat(br[2]);
    }
  }
  let stars;
  if (level != null) {
    const s = String(level).replace(/[^*]/g, "");
    if (s.length > 0) stars = s.length;
  }
  if (stars == null && typeof score === "number" && score > 0) {
    stars = Math.min(15, Math.floor(score));
  }
  let llm = null;
  if (llmH) {
    const m = String(llmH).trim().match(/^(LEGITIMATE|SPAM|SUSPICIOUS)\s*(?:\((.+)\))?\s*$/i);
    if (m) llm = { verdict: m[1].toUpperCase(), explanation: (m[2] || "").trim() };
  }
  let verdict = "clean";
  const flagYes = /^(yes|true)/i.test(String(flag || "")) || /^\s*yes\b/i.test(String(status || ""));
  const actionBad = /reject|add header|rewrite subject|quarantine|spam/i.test(
    String(rspamdAction || "")
  );
  if (flagYes || actionBad) {
    verdict = "spam";
  } else if (typeof score === "number" && typeof required === "number") {
    if (score >= required) verdict = "spam";
    else if (score >= required * 0.6) verdict = "suspicious";
  }
  if (verdict === "clean" && llm) {
    if (llm.verdict === "SPAM") verdict = "spam";
    else if (llm.verdict === "SUSPICIOUS") verdict = "suspicious";
  }
  return {
    score,
    required,
    stars,
    verdict,
    action: rspamdAction ? String(rspamdAction).trim() : void 0,
    llm,
    // Keep the raw status line so we can show users the exact header we read.
    raw: status || spamdResult || (scoreH != null ? `X-Spam-Score: ${scoreH}` : void 0)
  };
}
var VERDICT_COLOR = {
  clean: "var(--color-success, #16a34a)",
  suspicious: "var(--color-warning, #f59e0b)",
  spam: "var(--color-destructive, #dc2626)"
};
var VERDICT_LABEL = { clean: "Clean", suspicious: "Suspicious", spam: "Spam" };
function Row(label, value, opts) {
  const mono = opts && opts.mono;
  return h(
    "div",
    {
      style: {
        display: "grid",
        gridTemplateColumns: "7rem 1fr",
        columnGap: "1rem",
        rowGap: 0,
        alignItems: "baseline"
      }
    },
    h(
      "dt",
      { style: { fontSize: "12px", color: "var(--color-muted-foreground)", paddingTop: "2px" } },
      label
    ),
    h(
      "dd",
      {
        style: {
          margin: 0,
          minWidth: 0,
          fontSize: mono ? "12px" : "14px",
          fontFamily: mono ? "var(--font-mono, ui-monospace, monospace)" : "inherit",
          color: "var(--color-foreground)",
          wordBreak: "break-word"
        }
      },
      value
    )
  );
}
function SpamSection(props) {
  const email = props && props.email;
  const spam = email ? parseSpam(email.headers) : null;
  if (!spam) return null;
  const color = VERDICT_COLOR[spam.verdict] || VERDICT_COLOR.clean;
  const rows = [];
  rows.push(
    Row(
      "Verdict",
      h(
        "span",
        {
          style: {
            display: "inline-flex",
            alignItems: "center",
            gap: "6px",
            padding: "2px 8px",
            borderRadius: "6px",
            border: `1px solid ${color}`,
            color,
            fontSize: "12px",
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: "0.04em"
          }
        },
        VERDICT_LABEL[spam.verdict] || spam.verdict
      )
    )
  );
  if (typeof spam.score === "number") {
    rows.push(
      Row(
        "Score",
        h(
          "span",
          null,
          h("span", { style: { fontWeight: 600, color } }, spam.score.toFixed(2)),
          typeof spam.required === "number" ? h(
            "span",
            { style: { color: "var(--color-muted-foreground)" } },
            ` / ${spam.required.toFixed(2)} threshold`
          ) : null
        )
      )
    );
  }
  if (typeof spam.stars === "number" && spam.stars > 0) {
    rows.push(Row("Level", "★".repeat(spam.stars)));
  }
  if (spam.action) {
    rows.push(Row("Action", spam.action));
  }
  if (spam.llm) {
    rows.push(
      Row(
        "AI verdict",
        h(
          "span",
          null,
          h("span", { style: { fontWeight: 600 } }, spam.llm.verdict),
          spam.llm.explanation ? h(
            "span",
            { style: { color: "var(--color-muted-foreground)" } },
            ` · ${spam.llm.explanation}`
          ) : null
        )
      )
    );
  }
  if (spam.raw) {
    rows.push(Row("Header", spam.raw, { mono: true }));
  }
  return h(
    "section",
    { style: { minWidth: 0, paddingTop: "4px" } },
    h(
      "div",
      {
        style: {
          fontSize: "10px",
          fontWeight: 600,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          color: "var(--color-muted-foreground)",
          marginBottom: "6px"
        }
      },
      "Spam Analysis"
    ),
    h("div", { style: { display: "flex", flexDirection: "column", gap: "6px" } }, ...rows)
  );
}
var settings = {};
function shouldShow(extraProps) {
  const email = extraProps && extraProps.email;
  if (!email) return false;
  const spam = parseSpam(email.headers);
  if (!spam) return false;
  if (settings.showWhenClean === false && spam.verdict === "clean") return false;
  const category = extraProps.category == null ? null : String(extraProps.category);
  const auth = email.auth;
  const authPresent = !!(auth && (auth.spf || auth.dkim || auth.dmarc || auth.iprev));
  const target = settings.placeUnderSecurity && authPresent ? "authentication_security" : null;
  return category === target;
}
var slots = {
  "email-details-section": {
    component: SpamSection,
    shouldShow,
    order: 60
  }
};
async function activate(api) {
  settings = api.plugin.settings || {};
  api.log.info("Spam Score plugin activated");
}
