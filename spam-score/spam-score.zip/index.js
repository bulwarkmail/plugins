var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// spam-score/src/index.js
var index_exports = {};
__export(index_exports, {
  SpamSection: () => SpamSection,
  activate: () => activate,
  slots: () => slots,
  spamRows: () => spamRows
});
module.exports = __toCommonJS(index_exports);
var import_react = require("react");
var import_ui = require("@plugin-host/ui");
function getHeader(headers, name) {
  if (!headers) return void 0;
  const wanted = name.toLowerCase();
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === wanted) {
      const v = headers[key];
      return Array.isArray(v) ? v[0] : v;
    }
  }
  return void 0;
}
function toNumber(raw) {
  if (raw == null) return void 0;
  const m = String(raw).match(/-?\d+(?:\.\d+)?/);
  if (!m) return void 0;
  const n = parseFloat(m[0]);
  return Number.isFinite(n) ? n : void 0;
}
function parseSpam(headers) {
  if (!headers) return null;
  const status = getHeader(headers, "X-Spam-Status");
  const scoreH = getHeader(headers, "X-Spam-Score");
  const level = getHeader(headers, "X-Spam-Level");
  const flag = getHeader(headers, "X-Spam-Flag");
  const rspamdScore = getHeader(headers, "X-Rspamd-Score");
  const spamdResult = getHeader(headers, "X-Spamd-Result");
  const rspamdAction = getHeader(headers, "X-Rspamd-Action") || getHeader(headers, "X-Spam-Action");
  const llmH = getHeader(headers, "X-Spam-LLM");
  if (!status && scoreH == null && level == null && flag == null && rspamdScore == null && spamdResult == null && rspamdAction == null && !llmH) {
    return null;
  }
  let score;
  let required;
  if (status) {
    const sm = status.match(/score=\s*(-?\d+(?:\.\d+)?)/i);
    if (sm) score = parseFloat(sm[1]);
    const rm = status.match(/required=\s*(-?\d+(?:\.\d+)?)/i);
    if (rm) required = parseFloat(rm[1]);
  }
  if (score == null && scoreH != null) score = toNumber(scoreH);
  if (score == null && rspamdScore != null) score = toNumber(rspamdScore);
  if ((score == null || required == null) && spamdResult) {
    const br = spamdResult.match(/\[\s*(-?\d+(?:\.\d+)?)\s*\/\s*(-?\d+(?:\.\d+)?)\s*\]/);
    if (br) {
      if (score == null) score = parseFloat(br[1]);
      if (required == null) required = parseFloat(br[2]);
    }
  }
  let stars;
  if (level != null) {
    const s = String(level).replace(/[^*]/g, "");
    if (s.length > 0) stars = s.length;
  }
  if (stars == null && typeof score === "number" && score > 0) {
    stars = Math.min(15, Math.floor(score));
  }
  let llm = null;
  if (llmH) {
    const m = String(llmH).trim().match(/^(LEGITIMATE|SPAM|SUSPICIOUS)\s*(?:\((.+)\))?\s*$/i);
    if (m) llm = { verdict: m[1].toUpperCase(), explanation: (m[2] || "").trim() };
  }
  let verdict = "clean";
  const flagYes = /^(yes|true)/i.test(String(flag || "")) || /^\s*yes\b/i.test(String(status || ""));
  const actionBad = /reject|add header|rewrite subject|quarantine|spam/i.test(
    String(rspamdAction || "")
  );
  if (flagYes || actionBad) {
    verdict = "spam";
  } else if (typeof score === "number" && typeof required === "number") {
    if (score >= required) verdict = "spam";
    else if (score >= required * 0.6) verdict = "suspicious";
  }
  if (verdict === "clean" && llm) {
    if (llm.verdict === "SPAM") verdict = "spam";
    else if (llm.verdict === "SUSPICIOUS") verdict = "suspicious";
  }
  return {
    score,
    required,
    stars,
    verdict,
    action: rspamdAction ? String(rspamdAction).trim() : void 0,
    llm,
    // Keep the raw status line so we can show users the exact header we read.
    raw: status || spamdResult || (scoreH != null ? `X-Spam-Score: ${scoreH}` : void 0)
  };
}
var VERDICT_TONE = { clean: "success", suspicious: "warning", spam: "danger" };
var VERDICT_LABEL = { clean: "Clean", suspicious: "Suspicious", spam: "Spam" };
var LABEL_COLUMN = { width: "7rem", flexShrink: 0 };
function Field(label, value) {
  return (0, import_react.createElement)(
    import_ui.Row,
    { key: label, gap: 4, wrap: false, align: "baseline" },
    (0, import_react.createElement)("div", { style: LABEL_COLUMN }, (0, import_react.createElement)(import_ui.Text, { size: "xs", tone: "muted" }, label)),
    (0, import_react.createElement)("div", { style: { minWidth: 0 } }, value)
  );
}
function spamRows(spam) {
  const rows = [];
  rows.push(["Verdict", (0, import_react.createElement)(import_ui.Badge, { tone: VERDICT_TONE[spam.verdict] || "neutral" }, VERDICT_LABEL[spam.verdict] || spam.verdict)]);
  if (typeof spam.score === "number") {
    const threshold = typeof spam.required === "number" ? ` / ${spam.required.toFixed(2)} threshold` : "";
    rows.push(["Score", (0, import_react.createElement)(import_ui.Text, null, `${spam.score.toFixed(2)}${threshold}`)]);
  }
  if (typeof spam.stars === "number" && spam.stars > 0) rows.push(["Level", (0, import_react.createElement)(import_ui.Text, null, "★".repeat(spam.stars))]);
  if (spam.action) rows.push(["Action", (0, import_react.createElement)(import_ui.Text, null, spam.action)]);
  if (spam.llm) {
    rows.push(["AI verdict", (0, import_react.createElement)(import_ui.Text, null, spam.llm.explanation ? `${spam.llm.verdict} · ${spam.llm.explanation}` : spam.llm.verdict)]);
  }
  if (spam.raw) rows.push(["Header", (0, import_react.createElement)(import_ui.Text, { size: "xs" }, spam.raw)]);
  return rows;
}
function SpamSection(props) {
  const email = props && props.email;
  const spam = email ? parseSpam(email.headers) : null;
  if (!spam) return null;
  return (0, import_react.createElement)(
    import_ui.Stack,
    { gap: 2 },
    (0, import_react.createElement)(import_ui.Text, { size: "xs", tone: "muted", weight: "semibold" }, "SPAM ANALYSIS"),
    (0, import_react.createElement)(import_ui.Stack, { gap: 1 }, ...spamRows(spam).map(([label, value]) => Field(label, value)))
  );
}
var settings = {};
function shouldShow(extraProps) {
  const email = extraProps && extraProps.email;
  if (!email) return false;
  const spam = parseSpam(email.headers);
  if (!spam) return false;
  if (settings.showWhenClean === false && spam.verdict === "clean") return false;
  const category = extraProps.category == null ? null : String(extraProps.category);
  const auth = email.auth;
  const authPresent = !!(auth && (auth.spf || auth.dkim || auth.dmarc || auth.iprev));
  const target = settings.placeUnderSecurity && authPresent ? "authentication_security" : null;
  return category === target;
}
var slots = {
  "email-details-section": {
    component: SpamSection,
    shouldShow,
    order: 60
  }
};
async function activate(api) {
  settings = api.plugin.settings || {};
  api.log.info("Spam Score plugin activated");
}
