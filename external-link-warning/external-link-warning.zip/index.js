var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// external-link-warning/src/index.js
var index_exports = {};
__export(index_exports, {
  CREDENTIALS: () => CREDENTIALS,
  activate: () => activate,
  decideFor: () => decideFor,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// external-link-warning/src/lib/domains.js
function normaliseDomain(raw) {
  let d = String(raw).trim().toLowerCase();
  if (!d) return "";
  d = d.replace(/^\*\./, "");
  d = d.replace(/^https?:\/\//, "");
  d = d.replace(/[/?#].*$/, "");
  d = d.replace(/:\d+$/, "");
  d = d.replace(/\.+$/, "");
  return d;
}
function parseDomains(input) {
  if (!input) return [];
  const list = Array.isArray(input) ? input.map(String) : String(input).split(/[\s,;]+/);
  return [...new Set(list.map(normaliseDomain).filter(Boolean))];
}
function hostnameFromHref(href) {
  try {
    const url = new URL(href);
    if (url.protocol !== "http:" && url.protocol !== "https:") return "";
    return url.hostname.toLowerCase().replace(/\.+$/, "");
  } catch {
    return "";
  }
}
function isTrusted(hostname, list) {
  if (!hostname) return false;
  for (const d of list) {
    if (!d) continue;
    if (hostname === d || hostname.endsWith("." + d)) return true;
  }
  return false;
}
function domainInText(text) {
  if (typeof text !== "string") return "";
  const trimmed = text.trim();
  if (!trimmed || trimmed.length > 200 || /\s/.test(trimmed)) return "";
  let candidate = trimmed;
  if (!/^https?:\/\//i.test(candidate)) {
    if (!/^[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}(?:[:/?#].*)?$/i.test(candidate)) return "";
    candidate = `http://${candidate}`;
  }
  const host = hostnameFromHref(candidate);
  return host.includes(".") ? host : "";
}
function linkTextMismatch(text, targetHost) {
  const named = domainInText(text);
  if (!named || !targetHost) return "";
  const strip = (h2) => h2.replace(/^www\./, "");
  const a = strip(named);
  const b = strip(targetHost);
  if (a === b || b.endsWith("." + a)) return "";
  return named;
}

// external-link-warning/src/lib/lookup.js
var LOOKUP_BUDGET_MS = 3e3;
var LOOKUP_MODES = ["off", "endpoint", "safebrowsing", "both"];
function plannedChecks(config2, features) {
  const mode = LOOKUP_MODES.includes(config2?.lookup) ? config2.lookup : "off";
  const endpoint2 = mode === "endpoint" || mode === "both";
  const google2 = (mode === "safebrowsing" || mode === "both") && features?.noThirdPartyTraffic !== true;
  return { endpoint: endpoint2, google: google2 };
}
function withDeadline(promise, ms, onTimeout) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_resolve, reject) => {
      timer = setTimeout(() => {
        try {
          onTimeout?.();
        } catch {
        }
        reject(new Error("timeout"));
      }, ms);
    })
  ]).finally(() => clearTimeout(timer));
}
async function runChecks({ href, host, config: config2, features, services: services2, budgetMs = LOOKUP_BUDGET_MS, log }) {
  const plan = plannedChecks(config2, features);
  if (!plan.endpoint && !plan.google) return { verdict: "off" };
  let ready2 = { endpoint: false, google: false };
  try {
    ready2 = await services2.ready();
  } catch (err) {
    log?.("Could not read which link checks are set up", err);
  }
  const controller = typeof AbortController === "function" ? new AbortController() : null;
  const signal = controller?.signal;
  const run = (name, start) => withDeadline(Promise.resolve().then(start), budgetMs, () => controller?.abort()).then((value) => ({ name, ok: true, value }), (error) => {
    log?.(`The ${name} link check failed`, error);
    return { name, ok: false, error };
  });
  const jobs = [];
  if (plan.endpoint) {
    jobs.push(run("endpoint", () => {
      if (!config2.endpointUrl || !ready2.endpoint) throw new Error("The link check service is not set up");
      return services2.endpoint.check(config2.endpointUrl, href, host, { signal });
    }));
  }
  if (plan.google) {
    jobs.push(run("google", () => {
      if (!ready2.google) throw new Error("Safe Browsing has no API key");
      return services2.google.check(href, { signal });
    }));
  }
  const results = await Promise.all(jobs);
  const endpoint2 = results.find((r) => r.name === "endpoint");
  const google2 = results.find((r) => r.name === "google");
  const out = {
    endpoint: endpoint2 ? endpoint2.ok ? endpoint2.value : { verdict: "failed" } : void 0,
    google: google2 ? google2.ok ? google2.value : { verdict: "failed" } : void 0
  };
  const verdicts = [out.endpoint?.verdict, out.google?.verdict].filter(Boolean);
  let verdict = "unknown";
  if (verdicts.includes("unsafe")) verdict = "unsafe";
  else if (verdicts.includes("failed")) verdict = "failed";
  else if (verdicts.includes("safe")) verdict = "safe";
  return { verdict, ...out };
}

// external-link-warning/src/lib/config.js
var DEFAULT_CONFIG = Object.freeze({
  trustedDomains: [],
  lookup: "off",
  endpointUrl: "",
  onFailure: "open",
  onUnsafe: "warn",
  skipTrusted: true
});
function cleanUrl(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  try {
    const url = new URL(value.trim());
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : "";
  } catch {
    return "";
  }
}
function readConfig(raw) {
  const c = raw && typeof raw === "object" ? raw : {};
  return {
    trustedDomains: parseDomains(c.trustedDomains),
    lookup: LOOKUP_MODES.includes(c.lookup) ? c.lookup : DEFAULT_CONFIG.lookup,
    endpointUrl: cleanUrl(c.endpointUrl),
    onFailure: c.onFailure === "closed" ? "closed" : "open",
    onUnsafe: c.onUnsafe === "block" ? "block" : "warn",
    skipTrusted: c.skipTrusted !== false && c.skipTrusted !== "false"
  };
}

// external-link-warning/src/lib/canonical.js
function toByteString(text) {
  let out = "";
  for (const ch of String(text)) {
    const code = ch.codePointAt(0);
    if (code < 256) {
      out += ch;
      continue;
    }
    for (const byte of new TextEncoder().encode(ch)) out += String.fromCharCode(byte);
  }
  return out;
}
function unescapeOnce(text) {
  return text.replace(/%([0-9a-fA-F]{2})/g, (_m, hex) => String.fromCharCode(parseInt(hex, 16)));
}
function unescapeFully(text) {
  let current = text;
  for (let i = 0; i < 1024; i++) {
    const next = unescapeOnce(current);
    if (next === current) return current;
    current = next;
  }
  return current;
}
function escape(text) {
  let out = "";
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code <= 32 || code >= 127 || code === 35 || code === 37) {
      out += "%" + code.toString(16).toUpperCase().padStart(2, "0");
    } else {
      out += text[i];
    }
  }
  return out;
}
function ipv4Part(part) {
  if (/^0[xX][0-9a-fA-F]*$/.test(part)) return part.length === 2 ? 0 : parseInt(part.slice(2), 16);
  if (/^0[0-7]*$/.test(part)) return part.length === 1 ? 0 : parseInt(part.slice(1), 8);
  if (/^[1-9][0-9]*$/.test(part)) return parseInt(part, 10);
  return null;
}
function normaliseIpv4(host) {
  const parts = host.split(".");
  if (parts.length < 1 || parts.length > 4 || parts.some((p) => p === "")) return null;
  const values = parts.map(ipv4Part);
  if (values.some((v) => v === null || !Number.isFinite(v))) return null;
  const last = values.pop();
  if (values.some((v) => v > 255)) return null;
  const restBytes = 4 - values.length;
  if (last >= 2 ** (8 * restBytes)) return null;
  const bytes = [...values];
  for (let i = restBytes - 1; i >= 0; i--) bytes.push(Math.floor(last / 2 ** (8 * i)) % 256);
  return bytes.join(".");
}
function normaliseIpv6(host) {
  const match = /^\[([0-9a-fA-F:.]+)\]$/.exec(host);
  if (!match) return null;
  let text = match[1].toLowerCase();
  const v4 = /(\d+\.\d+\.\d+\.\d+)$/.exec(text);
  if (v4) {
    const ip = normaliseIpv4(v4[1]);
    if (!ip) return null;
    const [a, b, c, d] = ip.split(".").map(Number);
    text = text.slice(0, -v4[1].length) + (a << 8 | b).toString(16) + ":" + (c << 8 | d).toString(16);
  }
  const halves = text.split("::");
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(":") : [];
  const tail = halves.length === 2 && halves[1] ? halves[1].split(":") : [];
  const missing = 8 - head.length - tail.length;
  if (halves.length === 1 ? head.length !== 8 : missing < 1) return null;
  const groups = [...head, ...Array(halves.length === 2 ? missing : 0).fill("0"), ...tail];
  if (groups.some((g) => !/^[0-9a-f]{1,4}$/.test(g))) return null;
  const values = groups.map((g) => parseInt(g, 16).toString(16));
  let bestStart = -1;
  let bestLength = 0;
  for (let i = 0; i < 8; ) {
    if (values[i] !== "0") {
      i++;
      continue;
    }
    let j = i;
    while (j < 8 && values[j] === "0") j++;
    if (j - i > bestLength && j - i >= 2) {
      bestStart = i;
      bestLength = j - i;
    }
    i = j;
  }
  if (bestStart < 0) return `[${values.join(":")}]`;
  const left = values.slice(0, bestStart).join(":");
  const right = values.slice(bestStart + bestLength).join(":");
  return `[${left}::${right}]`;
}
function canonicalHost(raw) {
  let host = unescapeFully(raw);
  host = host.replace(/^\.+|\.+$/g, "").replace(/\.{2,}/g, ".").toLowerCase();
  const v6 = normaliseIpv6(host);
  if (v6) return v6;
  const v4 = normaliseIpv4(host);
  if (v4) return v4;
  return host;
}
function canonicalPath(raw) {
  let path = unescapeFully(raw || "/");
  if (!path.startsWith("/")) path = "/" + path;
  path = path.replace(/\/{2,}/g, "/");
  const segments = path.split("/").slice(1);
  const stack = [];
  let trailingSlash = false;
  segments.forEach((segment, i) => {
    const last = i === segments.length - 1;
    if (segment === "." || segment === "..") {
      if (segment === "..") stack.pop();
      if (last) trailingSlash = true;
      return;
    }
    if (segment === "" && last) {
      trailingSlash = true;
      return;
    }
    stack.push(segment);
  });
  if (stack.length === 0) return "/";
  return "/" + stack.join("/") + (trailingSlash ? "/" : "");
}
function canonicalize(input) {
  let text = toByteString(input).replace(/[\t\r\n]/g, "").replace(/^[\x00-\x20]+|[\x00-\x20]+$/g, "");
  const hash = text.indexOf("#");
  if (hash >= 0) text = text.slice(0, hash);
  let scheme = "http";
  const schemeMatch = /^([a-zA-Z][a-zA-Z0-9+.-]*):\/\//.exec(text);
  if (schemeMatch) {
    scheme = schemeMatch[1].toLowerCase();
    text = text.slice(schemeMatch[0].length);
  }
  const authorityEnd = text.search(/[/?]/);
  let authority = authorityEnd < 0 ? text : text.slice(0, authorityEnd);
  let rest = authorityEnd < 0 ? "" : text.slice(authorityEnd);
  const at = authority.lastIndexOf("@");
  if (at >= 0) authority = authority.slice(at + 1);
  const portMatch = /:(\d*)$/.exec(authority);
  if (portMatch && !(authority.startsWith("[") && !authority.slice(0, portMatch.index).endsWith("]"))) {
    authority = authority.slice(0, portMatch.index);
  }
  const host = escape(canonicalHost(authority));
  if (!host) return null;
  let query = null;
  const q = rest.indexOf("?");
  if (q >= 0) {
    query = escape(unescapeFully(rest.slice(q + 1)));
    rest = rest.slice(0, q);
  }
  const path = escape(canonicalPath(rest));
  const url = `${scheme}://${host}${path}${query === null ? "" : `?${query}`}`;
  return { scheme, host, path, query, url };
}
function hostSuffixes(host) {
  const out = [host];
  if (normaliseIpv4(host) === host || host.startsWith("[")) return out;
  const parts = host.split(".");
  const start = Math.max(1, parts.length - 5);
  for (let i = start; i <= parts.length - 2 && out.length < 5; i++) {
    const suffix = parts.slice(i).join(".");
    if (!out.includes(suffix)) out.push(suffix);
  }
  return out;
}
function pathPrefixes(path, query) {
  const out = [];
  if (query !== null && query !== void 0) out.push(`${path}?${query}`);
  out.push(path);
  const segments = path.split("/").slice(1, -1);
  const prefixes = ["/"];
  let current = "/";
  for (const segment of segments) {
    if (prefixes.length >= 4) break;
    current += `${segment}/`;
    prefixes.push(current);
  }
  for (const prefix of prefixes) {
    if (out.length >= 6) break;
    if (!out.includes(prefix)) out.push(prefix);
  }
  return out;
}
function expressions(input) {
  const canonical = canonicalize(input);
  if (!canonical) return [];
  const out = [];
  for (const host of hostSuffixes(canonical.host)) {
    for (const path of pathPrefixes(canonical.path, canonical.query)) {
      const expression = `${host}${path}`;
      if (!out.includes(expression)) out.push(expression);
    }
  }
  return out.slice(0, 30);
}

// external-link-warning/src/lib/sha256.js
var K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotr = (x, n) => x >>> n | x << 32 - n;
function sha256(bytes) {
  const length = bytes.length;
  const padded = new Uint8Array(length + 9 + 63 >> 6 << 6);
  padded.set(bytes);
  padded[length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(padded.length - 8, Math.floor(length / 536870912), false);
  view.setUint32(padded.length - 4, length << 3 >>> 0, false);
  const h2 = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let offset = 0; offset < padded.length; offset += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
      const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
      w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h2;
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = e & f ^ ~e & g;
      const t1 = hh + S1 + ch + K[i] + w[i] >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = S0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h2[0] = h2[0] + a >>> 0;
    h2[1] = h2[1] + b >>> 0;
    h2[2] = h2[2] + c >>> 0;
    h2[3] = h2[3] + d >>> 0;
    h2[4] = h2[4] + e >>> 0;
    h2[5] = h2[5] + f >>> 0;
    h2[6] = h2[6] + g >>> 0;
    h2[7] = h2[7] + hh >>> 0;
  }
  const out = new Uint8Array(32);
  const outView = new DataView(out.buffer);
  for (let i = 0; i < 8; i++) outView.setUint32(i * 4, h2[i], false);
  return out;
}
function latin1Bytes(text) {
  const out = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) out[i] = text.charCodeAt(i) & 255;
  return out;
}
var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function toBase64(bytes) {
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const n = bytes[i] << 16 | (bytes[i + 1] ?? 0) << 8 | (bytes[i + 2] ?? 0);
    out += B64[n >> 18 & 63] + B64[n >> 12 & 63];
    out += i + 1 < bytes.length ? B64[n >> 6 & 63] : "=";
    out += i + 2 < bytes.length ? B64[n & 63] : "=";
  }
  return out;
}
function fromBase64(text) {
  if (typeof text !== "string") return null;
  const clean = text.replace(/-/g, "+").replace(/_/g, "/").replace(/=+$/, "");
  if (!/^[A-Za-z0-9+/]*$/.test(clean) || clean.length % 4 === 1) return null;
  const out = new Uint8Array(Math.floor(clean.length * 3 / 4));
  let bits = 0;
  let value = 0;
  let index = 0;
  for (const ch of clean) {
    value = value << 6 | B64.indexOf(ch);
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out[index++] = value >> bits & 255;
    }
  }
  return out;
}

// external-link-warning/src/lib/cache.js
function createCache({ now = Date.now, max = 5e3 } = {}) {
  const entries = /* @__PURE__ */ new Map();
  const prune = () => {
    const t = now();
    for (const [key, entry] of entries) if (entry.expires <= t) entries.delete(key);
    while (entries.size > max) entries.delete(entries.keys().next().value);
  };
  return {
    get(key) {
      const entry = entries.get(key);
      if (!entry) return void 0;
      if (entry.expires <= now()) {
        entries.delete(key);
        return void 0;
      }
      return entry.value;
    },
    set(key, value, ttlMs) {
      if (!(ttlMs > 0)) return;
      entries.delete(key);
      entries.set(key, { value, expires: now() + ttlMs });
      if (entries.size > max) prune();
    },
    clear() {
      entries.clear();
    },
    get size() {
      return entries.size;
    }
  };
}

// external-link-warning/src/lib/safebrowsing.js
var SAFE_BROWSING_ORIGIN = "https://safebrowsing.googleapis.com";
var ADVISORY_URL = "https://developers.google.com/safe-browsing/v4/advisory";
var THREAT_TYPES = ["SOCIAL_ENGINEERING", "MALWARE", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"];
var MAX_CACHE_MS = 24 * 60 * 60 * 1e3;
var DEFAULT_CACHE_MS = 5 * 60 * 1e3;
var LookupError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "LookupError";
  }
};
function parseDuration(value) {
  if (typeof value !== "string") return null;
  const match = /^(\d+(?:\.\d+)?)s$/.exec(value.trim());
  return match ? Math.round(Number(match[1]) * 1e3) : null;
}
function hashesFor(href) {
  return expressions(href).map((expression) => {
    const full = sha256(latin1Bytes(expression));
    return { expression, full: toBase64(full), prefix: toBase64(full.subarray(0, 4)) };
  });
}
function enforceableThreats(details) {
  if (!Array.isArray(details)) return [];
  const out = [];
  for (const detail of details) {
    if (!detail || !THREAT_TYPES.includes(detail.threatType)) continue;
    const attributes = Array.isArray(detail.attributes) ? detail.attributes : [];
    if (attributes.includes("CANARY") || attributes.includes("FRAME_ONLY")) continue;
    if (!out.includes(detail.threatType)) out.push(detail.threatType);
  }
  return out;
}
function createSafeBrowsing({ request, now = Date.now } = {}) {
  const listed = createCache({ now });
  const asked = createCache({ now });
  const verdictOf = (hashes) => {
    const threats = [];
    for (const { full } of hashes) {
      for (const threat of listed.get(full) ?? []) if (!threats.includes(threat)) threats.push(threat);
    }
    return { verdict: threats.length ? "unsafe" : "safe", threats };
  };
  async function check(href, { signal } = {}) {
    const hashes = hashesFor(href);
    if (hashes.length === 0) return { verdict: "safe", threats: [] };
    const prefixes = [...new Set(hashes.map((h2) => h2.prefix))].filter((p) => !asked.get(p));
    if (prefixes.length === 0) return verdictOf(hashes);
    const query = prefixes.map((p) => `hashPrefixes=${encodeURIComponent(p)}`).join("&");
    let res;
    try {
      res = await request(`${SAFE_BROWSING_ORIGIN}/v5/hashes:search?${query}&alt=json`, { signal });
    } catch (err) {
      throw new LookupError(`Safe Browsing request failed: ${err?.message ?? err}`);
    }
    if (!res || res.proxyError || !res.ok) {
      throw new LookupError(`Safe Browsing answered ${res?.proxyError ?? res?.status}`);
    }
    const body = res.body;
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new LookupError("Safe Browsing sent no JSON object");
    if (body.fullHashes !== void 0 && !Array.isArray(body.fullHashes)) throw new LookupError("Safe Browsing sent a bad answer");
    const ttl = Math.min(parseDuration(body.cacheDuration) ?? DEFAULT_CACHE_MS, MAX_CACHE_MS);
    const answer = /* @__PURE__ */ new Map();
    for (const entry of body.fullHashes ?? []) {
      const bytes = fromBase64(entry?.fullHash);
      if (!bytes || bytes.length !== 32) continue;
      const key = toBase64(bytes);
      answer.set(key, [.../* @__PURE__ */ new Set([...answer.get(key) ?? [], ...enforceableThreats(entry.fullHashDetails)])]);
    }
    for (const [key, threats2] of answer) listed.set(key, threats2, ttl);
    for (const prefix of prefixes) asked.set(prefix, true, ttl);
    const threats = [];
    for (const { full } of hashes) {
      for (const threat of answer.get(full) ?? listed.get(full) ?? []) if (!threats.includes(threat)) threats.push(threat);
    }
    return { verdict: threats.length ? "unsafe" : "safe", threats };
  }
  return { check, clear() {
    listed.clear();
    asked.clear();
  } };
}

// external-link-warning/src/lib/endpoint.js
var VERDICTS = ["safe", "unsafe", "unknown"];
var MAX_CACHE_SECONDS = 3600;
var MAX_REASON = 300;
function parseAnswer(body) {
  let value = body;
  if (typeof value === "string") {
    try {
      value = JSON.parse(value);
    } catch {
      throw new LookupError("The link check sent no JSON");
    }
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new LookupError("The link check sent no JSON object");
  if (!VERDICTS.includes(value.verdict)) throw new LookupError(`The link check sent an unknown verdict ${JSON.stringify(value.verdict)}`);
  const reason = typeof value.reason === "string" ? value.reason.trim().slice(0, MAX_REASON) : "";
  const seconds = Number(value.cacheSeconds);
  const cacheSeconds = Number.isFinite(seconds) && seconds > 0 ? Math.min(seconds, MAX_CACHE_SECONDS) : 0;
  return { verdict: value.verdict, ...reason ? { reason } : {}, cacheSeconds };
}
function createEndpoint({ request, now = Date.now } = {}) {
  const cache = createCache({ now });
  async function check(endpointUrl, href, host, { signal } = {}) {
    const key = toBase64(sha256(latin1Bytes(unescape(encodeURIComponent(`${endpointUrl}
${href}`)))));
    const cached = cache.get(key);
    if (cached) return cached;
    let res;
    try {
      res = await request(endpointUrl, {
        method: "POST",
        headers: { "content-type": "application/json", accept: "application/json" },
        body: JSON.stringify({ url: href, host }),
        responseType: "text",
        signal
      });
    } catch (err) {
      throw new LookupError(`The link check failed: ${err?.message ?? err}`);
    }
    if (!res || res.proxyError || !res.ok) throw new LookupError(`The link check answered ${res?.proxyError ?? res?.status}`);
    const { cacheSeconds, ...result } = parseAnswer(res.body);
    cache.set(key, result, cacheSeconds * 1e3);
    return result;
  }
  return { check, clear() {
    cache.clear();
  } };
}

// external-link-warning/src/lib/decide.js
function decide({ host, text, trusted, check, config: config2 }) {
  const mismatch = trusted ? "" : linkTextMismatch(text, host);
  const verdict = check?.verdict ?? "off";
  if (verdict === "unsafe") {
    const threats = check.google?.verdict === "unsafe" ? check.google.threats ?? [] : [];
    const reason = check.endpoint?.verdict === "unsafe" ? check.endpoint.reason : void 0;
    return {
      kind: threats.length ? "google" : "unsafe",
      block: config2.onUnsafe === "block",
      threats,
      ...reason ? { reason } : {},
      mismatch
    };
  }
  if (verdict === "failed") {
    if (config2.onFailure === "closed") return { kind: "closed", mismatch };
    if (trusted) return { kind: "open" };
    return { kind: "warn", line: "failed", mismatch };
  }
  if (trusted) return { kind: "open" };
  return { kind: "warn", line: verdict === "safe" ? "safe" : null, mismatch };
}
var paragraphs = (...parts) => parts.filter(Boolean).join("\n\n");
function dialogFor(decision, { host, href, text }, tr2) {
  const mismatchLine = decision.mismatch ? tr2("text.mismatch", { text: decision.mismatch || text, host }) : "";
  switch (decision.kind) {
    case "warn":
      return {
        type: "confirm",
        options: {
          title: tr2("dialog.title"),
          message: paragraphs(
            tr2("dialog.message", { host, href }),
            mismatchLine,
            decision.line === "safe" ? tr2("check.safe") : decision.line === "failed" ? tr2("check.failed") : ""
          ),
          confirmLabel: tr2("dialog.continue"),
          cancelLabel: tr2("dialog.cancel")
        }
      };
    case "unsafe": {
      const reason = decision.reason ? tr2("unsafe.reason", { reason: decision.reason }) : "";
      if (decision.block) {
        return { type: "alert", options: { title: tr2("blocked.title"), message: paragraphs(tr2("blocked.message", { host, href }), reason, mismatchLine), confirmLabel: tr2("close") } };
      }
      return {
        type: "confirm",
        options: {
          title: tr2("unsafe.title"),
          message: paragraphs(tr2("unsafe.message", { host, href }), reason, mismatchLine),
          confirmLabel: tr2("unsafe.continue"),
          cancelLabel: tr2("unsafe.cancel"),
          danger: true
        }
      };
    }
    case "closed":
      return { type: "alert", options: { title: tr2("closed.title"), message: paragraphs(tr2("closed.message", { host, href }), mismatchLine), confirmLabel: tr2("close") } };
    case "google": {
      const threats = THREAT_TYPES.filter((t) => decision.threats.includes(t));
      const lines = [
        tr2("google.target", { host }),
        href,
        ...threats.map((t) => tr2(`google.${t}`)),
        decision.reason ? tr2("unsafe.reason", { reason: decision.reason }) : "",
        mismatchLine,
        decision.block ? tr2("google.blocked") : "",
        tr2("google.imperfect")
      ].filter(Boolean);
      const buttons = decision.block ? [{ id: "close", label: tr2("close"), variant: "secondary" }] : [
        { id: "cancel", label: tr2("unsafe.cancel"), variant: "secondary" },
        { id: "open", label: tr2("unsafe.continue"), variant: "destructive" }
      ];
      return {
        type: "dialog",
        options: {
          title: tr2("google.title"),
          slot: "plugin-dialog",
          extraProps: { paragraphs: lines, advisory: { label: tr2("google.advisory"), url: ADVISORY_URL }, buttons }
        }
      };
    }
    default:
      return null;
  }
}

// external-link-warning/src/lib/strings.js
var EN = {
  "dialog.title": "Open external link?",
  "dialog.message": "You're about to visit {host}.\n\n{href}\n\nThis domain isn't on your trusted list. Only continue if you recognise it.",
  "dialog.continue": "Continue",
  "dialog.cancel": "Cancel",
  "trust.title": "Trust {host} from now on?",
  "trust.message": "Links to {host} and its subdomains will open without this warning on this device.",
  "trust.confirm": "Always trust {host}",
  "trust.cancel": "Just this once",
  trustedAdded: "{host} added to your trusted domains",
  "check.safe": "Checked: no known threats.",
  "check.failed": "Couldn't check this link.",
  "text.mismatch": "The link text says {text}, but the link goes to {host}.",
  "unsafe.title": "This link may be dangerous",
  "unsafe.message": "The link goes to {host}.\n\n{href}\n\nYour organisation's link check flagged it as unsafe. Only continue if you're sure it's safe.",
  "unsafe.reason": "Reason: {reason}",
  "unsafe.continue": "Open anyway",
  "unsafe.cancel": "Go back",
  "blocked.title": "Link blocked",
  "blocked.message": "The link goes to {host}.\n\n{href}\n\nYour organisation's link check flagged it as unsafe, so it can't be opened.",
  "closed.title": "Link couldn't be checked",
  "closed.message": "The link goes to {host}.\n\n{href}\n\nYour organisation couldn't check this link, so it can't be opened right now. Try again in a moment.",
  close: "Close",
  "google.title": "Suspected dangerous site",
  "google.target": "The link goes to {host}.",
  "google.SOCIAL_ENGINEERING": "Google Safe Browsing reports that this site may be a phishing site. It may try to trick you into giving away passwords or other personal information.",
  "google.MALWARE": "Google Safe Browsing reports that this site may install harmful software on your device.",
  "google.UNWANTED_SOFTWARE": "Google Safe Browsing reports that this site may offer software that changes your device in ways you may not want.",
  "google.POTENTIALLY_HARMFUL_APPLICATION": "Google Safe Browsing reports that this site may offer apps that could harm your device.",
  "google.imperfect": "These warnings aren't always right, and a site without a warning isn't always safe.",
  "google.blocked": "Your organisation doesn't allow opening links like this.",
  "google.advisory": "Advisory provided by Google"
};

// external-link-warning/src/ui/verdict-dialog.js
var import_react = require("react");
var import_ui = require("@plugin-host/ui");
var api = require("@plugin-host");
function VerdictDialog(props) {
  const paragraphs2 = Array.isArray(props?.paragraphs) ? props.paragraphs : [];
  const buttons = Array.isArray(props?.buttons) ? props.buttons : [];
  const advisory = props?.advisory;
  const [target, href, verdict, ...rest] = paragraphs2;
  const note = rest.length ? rest[rest.length - 1] : "";
  const middle = rest.slice(0, -1);
  return (0, import_react.createElement)(
    import_ui.Stack,
    { gap: 3 },
    target ? (0, import_react.createElement)(import_ui.Text, { weight: "medium" }, target) : null,
    href ? (0, import_react.createElement)(import_ui.Text, { size: "xs", tone: "muted" }, href) : null,
    verdict ? (0, import_react.createElement)(import_ui.Alert, { tone: "danger" }, verdict) : null,
    ...middle.map((line, i) => (0, import_react.createElement)(import_ui.Text, { key: `m${i}` }, line)),
    note ? (0, import_react.createElement)(import_ui.Text, { size: "xs", tone: "muted" }, note) : null,
    advisory?.url ? (0, import_react.createElement)("div", null, (0, import_react.createElement)(import_ui.LinkButton, { onClick: () => {
      void api.ui.openExternalUrl(advisory.url, "_blank");
    } }, advisory.label)) : null,
    (0, import_react.createElement)(import_ui.DialogButtons, { buttons, onClick: (id) => props.onResult?.(id) })
  );
}

// external-link-warning/src/index.js
var CONFIG_TTL_MS = 5 * 60 * 1e3;
var READY_TTL_MS = 60 * 1e3;
var CREDENTIALS = { google: "safebrowsing", endpoint: "linkcheck", endpointOpen: "linkcheck-open" };
var pluginApi = null;
var localTrusted = [];
var config = { ...DEFAULT_CONFIG };
var configAt = 0;
var configPromise = null;
var ready = null;
var readyAt = 0;
var endpoint = null;
var google = null;
function tr(key, vars) {
  const i18n = pluginApi && pluginApi.i18n;
  if (i18n && typeof i18n.has === "function" && i18n.has(key)) return i18n.t(key, vars);
  return String(EN[key] || key).replace(/\{(\w+)\}/g, (m, k) => vars && k in vars ? String(vars[k]) : m);
}
function warn(message, err) {
  try {
    pluginApi?.log?.warn(message, err);
  } catch {
  }
}
function loadConfig() {
  if (configPromise) return configPromise;
  configPromise = (async () => {
    try {
      const raw = await pluginApi.config.get();
      config = readConfig(raw);
      configAt = Date.now();
    } catch (err) {
      warn("Could not read the admin settings", err);
    } finally {
      configPromise = null;
    }
    return config;
  })();
  return configPromise;
}
async function currentConfig() {
  if (!configAt) return loadConfig();
  if (Date.now() - configAt > CONFIG_TTL_MS) void loadConfig();
  return config;
}
async function readiness() {
  if (ready && Date.now() - readyAt < READY_TTL_MS) return ready;
  const list = await pluginApi.proxy.accounts();
  const configured = (id) => Array.isArray(list) && list.some((a) => a && a.credentialId === id && a.connected === true);
  ready = {
    endpointCredential: configured(CREDENTIALS.endpoint) ? CREDENTIALS.endpoint : configured(CREDENTIALS.endpointOpen) ? CREDENTIALS.endpointOpen : null,
    google: configured(CREDENTIALS.google)
  };
  readyAt = Date.now();
  return ready;
}
function proxyRequest(credentialId, responseType) {
  return (url, init = {}) => pluginApi.proxy.fetch(credentialId, url, { ...init, responseType: init.responseType ?? responseType });
}
function services() {
  return {
    ready: async () => {
      const r = await readiness();
      return { endpoint: !!r.endpointCredential, google: r.google };
    },
    endpoint: {
      check: async (url, href, host, opts) => {
        const r = await readiness();
        return endpoint(r.endpointCredential).check(url, href, host, opts);
      }
    },
    google: { check: (href, opts) => google.check(href, opts) }
  };
}
async function trustedList(cfg) {
  const userDomains = parseDomains(pluginApi.plugin.settings.trustedDomainsCsv);
  return [.../* @__PURE__ */ new Set([...cfg.trustedDomains, ...userDomains, ...localTrusted])];
}
async function addLocalTrust(domain) {
  if (!domain || localTrusted.includes(domain)) return;
  localTrusted.push(domain);
  await pluginApi.storage.set("localTrusted", localTrusted);
  pluginApi.toast.success(tr("trustedAdded", { host: domain }));
}
async function decideFor(ctx, host) {
  const cfg = await currentConfig();
  const trusted = isTrusted(host, await trustedList(cfg));
  const check = trusted && cfg.skipTrusted ? { verdict: "off" } : await runChecks({
    href: ctx.href,
    host,
    config: cfg,
    features: pluginApi.host?.features,
    services: services(),
    log: warn
  });
  return decide({ host, text: ctx.text, trusted, check, config: cfg });
}
async function present(decision, ctx, host) {
  const dialog = dialogFor(decision, { host, href: ctx.href, text: ctx.text }, tr);
  if (!dialog) return;
  if (dialog.type === "alert") {
    await pluginApi.ui.alert(dialog.options);
    return;
  }
  let open = false;
  if (dialog.type === "confirm") open = await pluginApi.ui.confirm(dialog.options) === true;
  else open = await pluginApi.ui.openDialog(dialog.options) === "open";
  if (!open) return;
  if (decision.kind === "warn" && pluginApi.plugin.settings.rememberLocalChoices !== false) {
    const always = await pluginApi.ui.confirm({
      title: tr("trust.title", { host }),
      message: tr("trust.message", { host }),
      confirmLabel: tr("trust.confirm", { host }),
      cancelLabel: tr("trust.cancel")
    });
    if (always) await addLocalTrust(host);
  }
  await pluginApi.ui.openExternalUrl(ctx.href, "_blank");
}
async function activate(api2) {
  pluginApi = api2;
  config = { ...DEFAULT_CONFIG };
  configAt = 0;
  ready = null;
  readyAt = 0;
  const endpoints = /* @__PURE__ */ new Map();
  endpoint = (credentialId) => {
    if (!endpoints.has(credentialId)) endpoints.set(credentialId, createEndpoint({ request: proxyRequest(credentialId, "text") }));
    return endpoints.get(credentialId);
  };
  google = createSafeBrowsing({ request: proxyRequest(CREDENTIALS.google, "json") });
  const stored = await api2.storage.get("localTrusted");
  localTrusted = Array.isArray(stored) ? stored.slice() : [];
  loadConfig().catch(() => {
  });
  api2.log.info("External Link Warning plugin activated");
}
var hooks = {
  async onBeforeExternalLink(ctx) {
    if (!pluginApi || !ctx?.href) return void 0;
    const host = hostnameFromHref(ctx.href);
    if (!host) return void 0;
    let decision;
    try {
      decision = await decideFor(ctx, host);
    } catch (err) {
      warn("Link check failed", err);
      decision = { kind: config.onFailure === "closed" ? "closed" : "warn", line: "failed", mismatch: "" };
    }
    if (decision.kind === "open") return void 0;
    present(decision, ctx, host).catch((err) => warn("External link dialog failed", err));
    return false;
  }
};
var slots = {
  "plugin-dialog": { component: VerdictDialog }
};
