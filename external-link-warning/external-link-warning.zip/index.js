var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// external-link-warning/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);
var FALLBACK = {
  "dialog.title": "Open external link?",
  "dialog.message": "You're about to visit {host}.\n\n{href}\n\nThis domain isn't on your trusted list. Only continue if you recognise it.",
  "dialog.continue": "Continue",
  "dialog.cancel": "Cancel",
  "trust.title": "Trust {host} from now on?",
  "trust.message": "Links to {host} and its subdomains will open without this warning on this device.",
  "trust.confirm": "Always trust {host}",
  "trust.cancel": "Just this once",
  trustedAdded: "{host} added to your trusted domains"
};
function tr(key, vars) {
  const i18n = pluginApi && pluginApi.i18n;
  if (i18n && typeof i18n.has === "function" && i18n.has(key)) return i18n.t(key, vars);
  return String(FALLBACK[key] || key).replace(/\{(\w+)\}/g, (m, k) => vars && k in vars ? String(vars[k]) : m);
}
function parseDomains(input) {
  if (!input) return [];
  if (Array.isArray(input)) {
    return input.map((d) => normaliseDomain(String(d))).filter(Boolean);
  }
  return String(input).split(/[\s,;]+/).map(normaliseDomain).filter(Boolean);
}
function normaliseDomain(raw) {
  let d = String(raw).trim().toLowerCase();
  if (!d) return "";
  d = d.replace(/^\*\./, "");
  d = d.replace(/^https?:\/\//, "");
  d = d.replace(/\/.*$/, "");
  return d;
}
function hostnameFromHref(href) {
  try {
    const url = new URL(href);
    if (url.protocol !== "http:" && url.protocol !== "https:") return "";
    return url.hostname.toLowerCase();
  } catch {
    return "";
  }
}
function isTrusted(hostname, list) {
  if (!hostname) return false;
  for (const d of list) {
    if (!d) continue;
    if (hostname === d) return true;
    if (hostname.endsWith("." + d)) return true;
  }
  return false;
}
var pluginApi = null;
var cachedAdminDomains = [];
var adminFetched = false;
var adminFetchPromise = null;
var localTrusted = [];
function fetchAdminDomains() {
  if (adminFetched) return Promise.resolve(cachedAdminDomains);
  if (adminFetchPromise) return adminFetchPromise;
  adminFetchPromise = (async () => {
    try {
      const value = await pluginApi.admin.getConfig("trustedDomains");
      cachedAdminDomains = parseDomains(value);
    } catch (err) {
      pluginApi.log.warn("Could not load admin trusted-domains list", err);
      cachedAdminDomains = [];
    } finally {
      adminFetched = true;
    }
    return cachedAdminDomains;
  })();
  return adminFetchPromise;
}
async function getTrustedList() {
  const userDomains = parseDomains(pluginApi.plugin.settings.trustedDomainsCsv);
  const adminDomains = await fetchAdminDomains();
  return [.../* @__PURE__ */ new Set([...adminDomains, ...userDomains, ...localTrusted])];
}
async function addLocalTrust(domain) {
  if (!domain || localTrusted.includes(domain)) return;
  localTrusted.push(domain);
  await pluginApi.storage.set("localTrusted", localTrusted);
  pluginApi.toast.success(tr("trustedAdded", { host: domain }));
}
async function confirmAndOpen(href, hostname) {
  const proceed = await pluginApi.ui.confirm({
    title: tr("dialog.title"),
    message: tr("dialog.message", { host: hostname, href }),
    confirmLabel: tr("dialog.continue"),
    cancelLabel: tr("dialog.cancel")
  });
  if (!proceed) return;
  if (pluginApi.plugin.settings.rememberLocalChoices !== false) {
    const always = await pluginApi.ui.confirm({
      title: tr("trust.title", { host: hostname }),
      message: tr("trust.message", { host: hostname }),
      confirmLabel: tr("trust.confirm", { host: hostname }),
      cancelLabel: tr("trust.cancel")
    });
    if (always) await addLocalTrust(hostname);
  }
  await pluginApi.ui.openExternalUrl(href, "_blank");
}
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("localTrusted");
  localTrusted = Array.isArray(stored) ? stored.slice() : [];
  fetchAdminDomains().catch(() => {
  });
  api.log.info("External Link Warning plugin activated");
}
var hooks = {
  async onBeforeExternalLink(ctx) {
    if (!pluginApi || !ctx?.href) return;
    const hostname = hostnameFromHref(ctx.href);
    if (!hostname) return;
    const trusted = await getTrustedList();
    if (isTrusted(hostname, trusted)) return;
    confirmAndOpen(ctx.href, hostname).catch((err) => {
      pluginApi.log.warn("External link dialog failed", err);
    });
    return false;
  }
};
