// src/index.js
function activate(api) {
  const disposables = [];
  api.log.info("Plugin activated!");
  const isEnabled = api.plugin.settings.enabled;
  if (!isEnabled) {
    api.log.info("Plugin is disabled by user settings");
    return;
  }
  const runCount = (api.storage.get("runCount") || 0) + 1;
  api.storage.set("runCount", runCount);
  api.log.info(`Plugin has been activated ${runCount} time(s)`);
  disposables.push(
    api.hooks.onEmailOpen((email) => {
      api.log.info("Email opened:", email.subject);
    })
  );
  disposables.push(
    api.hooks.onAppReady(() => {
      api.log.info("App is ready!");
    })
  );
  return {
    dispose: () => {
      disposables.forEach((d) => d.dispose());
      api.log.info("Plugin deactivated");
    }
  };
}
function deactivate() {
}
export {
  activate,
  deactivate
};
