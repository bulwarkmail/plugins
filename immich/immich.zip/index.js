var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// immich/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var import_react4 = require("react");

// immich/src/lib/errors.js
var ImmichError = class extends Error {
  /**
   * @param {string} key  i18n key, e.g. 'error.token'
   * @param {Record<string, string|number>} [vars]
   * @param {number} [status] HTTP status, when there was one
   */
  constructor(key, vars = {}, status = 0) {
    super(key);
    this.name = "ImmichError";
    this.key = key;
    this.vars = vars;
    this.status = status;
  }
};
function oneLine(text) {
  const flat = String(text).replace(/\s+/g, " ").trim();
  return flat.length > 200 ? `${flat.slice(0, 197)}...` : flat;
}
function detailOf(body) {
  if (body == null) return "";
  if (typeof body === "string") {
    const text = body.trim();
    if (/^[{[]/.test(text)) {
      try {
        return detailOf(JSON.parse(text));
      } catch {
      }
    }
    if (/^<(!doctype|html)/i.test(text)) return "";
    return oneLine(text);
  }
  if (typeof body === "object") {
    const msg = Array.isArray(body.message) ? body.message.filter((m) => typeof m === "string").join("; ") : body.message;
    if (typeof msg === "string" && msg) return oneLine(msg);
    if (typeof body.error === "string") return oneLine(body.error);
  }
  return "";
}
function retryAfter(headers) {
  const seconds = Number(headers?.["retry-after"]);
  return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 0;
}
function errorFromResponse(res) {
  if (res.proxyError) {
    switch (res.proxyError) {
      case "no_credential":
        return new ImmichError("error.not_connected", {}, res.status);
      case "rate_limited":
        return new ImmichError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, 429);
      case "timeout":
        return new ImmichError("error.timeout", {}, 504);
      case "unreachable":
        return new ImmichError("error.unreachable", {}, 502);
      case "blocked_address":
        return new ImmichError("error.blocked", {}, 403);
      case "too_large":
        return new ImmichError("error.too_large", {}, 413);
      case "wrong_origin":
        return new ImmichError("error.wrong_server", {}, 403);
      default:
        return new ImmichError("error.proxy", { detail: detailOf(res.body) }, res.status);
    }
  }
  const status = res.status;
  const detail = detailOf(res.body);
  if (status === 401) return new ImmichError("error.token", {}, status);
  if (status === 403) return new ImmichError("error.forbidden", { detail: detail || `HTTP ${status}` }, status);
  if (status === 404) return new ImmichError("error.not_found", {}, status);
  if (status === 413) return new ImmichError("error.too_large", {}, status);
  if (status === 429) return new ImmichError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, status);
  if (status === 502 || status === 503 || status === 504) return new ImmichError("error.unavailable", {}, status);
  if (status >= 500) return new ImmichError("error.server", {}, status);
  if (status >= 400) return new ImmichError("error.rejected", { detail: detail || `HTTP ${status}` }, status);
  return new ImmichError("error.unexpected", { detail: `HTTP ${status}` }, status);
}
function toImmichError(err) {
  if (err instanceof ImmichError) return err;
  const message = err && typeof err.message === "string" ? err.message : String(err);
  if (/timed out|timeout/i.test(message)) return new ImmichError("error.timeout");
  if (/cancel|abort/i.test(message)) return new ImmichError("error.cancelled");
  if (/larger than|exceeds/i.test(message)) return new ImmichError("error.too_large");
  if (/permission|not allowed|not granted/i.test(message)) return new ImmichError("error.permission");
  if (/network|failed to fetch/i.test(message)) return new ImmichError("error.unreachable");
  return new ImmichError("error.unexpected", { detail: oneLine(message.split(/\r?\n/)[0]) });
}
function errorText(t2, err) {
  const e = toImmichError(err);
  return t2(e.key, e.vars);
}

// immich/src/lib/multipart.js
function quote(value) {
  return String(value).replace(/[\r\n]+/g, " ").replace(/(["\\])/g, "\\$1");
}
function randomBoundary() {
  let out = "----BulwarkImmich";
  for (let i = 0; i < 24; i++) out += Math.floor(Math.random() * 36).toString(36);
  return out;
}
function toBytes(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  return new TextEncoder().encode(String(data));
}
function buildMultipart(fields, boundary = randomBoundary()) {
  const enc = new TextEncoder();
  const chunks = [];
  for (const [name, value] of fields) {
    if (value === void 0 || value === null) continue;
    let head = `--${boundary}\r
Content-Disposition: form-data; name="${quote(name)}"`;
    if (typeof value === "object" && "data" in value) {
      head += `; filename="${quote(value.filename || "file")}"\r
Content-Type: ${value.type || "application/octet-stream"}\r
\r
`;
      chunks.push(enc.encode(head), toBytes(value.data), enc.encode("\r\n"));
    } else {
      head += "\r\n\r\n";
      chunks.push(enc.encode(head), enc.encode(String(value)), enc.encode("\r\n"));
    }
  }
  chunks.push(enc.encode(`--${boundary}--\r
`));
  const size = chunks.reduce((n, c) => n + c.byteLength, 0);
  const body = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    body.set(c, offset);
    offset += c.byteLength;
  }
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

// immich/src/lib/client.js
var PAGE_SIZE = 30;
var ACCEPT = "application/json";
function normalizeBase(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  let text = value.trim();
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = `https://${text}`;
  try {
    const url = new URL(text);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    const path = url.pathname.replace(/\/+$/, "").replace(/\/api$/, "");
    return `${url.origin}${path}`;
  } catch {
    return "";
  }
}
var BY_EXTENSION = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  gif: "image/gif",
  webp: "image/webp",
  heic: "image/heic",
  heif: "image/heif",
  avif: "image/avif",
  tif: "image/tiff",
  tiff: "image/tiff",
  bmp: "image/bmp",
  jxl: "image/jxl",
  dng: "image/x-adobe-dng",
  cr2: "image/x-canon-cr2",
  nef: "image/x-nikon-nef",
  arw: "image/x-sony-arw",
  mp4: "video/mp4",
  mov: "video/quicktime",
  m4v: "video/x-m4v",
  webm: "video/webm",
  mkv: "video/x-matroska",
  avi: "video/x-msvideo",
  "3gp": "video/3gpp",
  mts: "video/mp2t",
  m2ts: "video/mp2t"
};
function mediaType(name, type) {
  const t2 = String(type || "").toLowerCase().split(";")[0].trim();
  if (t2 && t2 !== "application/octet-stream") return t2;
  const ext = String(name || "").toLowerCase().split(".").pop();
  return BY_EXTENSION[ext] || t2 || "application/octet-stream";
}
function isMedia(name, type) {
  return /^(image|video)\//.test(mediaType(name, type));
}
function toAsset(raw) {
  const name = String(raw?.originalFileName || "photo");
  const kind = raw?.type === "VIDEO" ? "video" : "image";
  return {
    id: String(raw?.id || ""),
    name,
    kind,
    type: raw?.originalMimeType || mediaType(name, "") || (kind === "video" ? "video/mp4" : "image/jpeg"),
    size: Number(raw?.exifInfo?.fileSizeInByte) || 0,
    takenAt: raw?.localDateTime || raw?.fileCreatedAt || ""
  };
}
function filenameFromDisposition(header) {
  if (typeof header !== "string") return "";
  const star = /filename\*\s*=\s*([^']*)'[^']*'([^;]+)/i.exec(header);
  if (star) {
    try {
      return decodeURIComponent(star[2].trim());
    } catch {
    }
  }
  const plain = /filename\s*=\s*"((?:[^"\\]|\\.)*)"|filename\s*=\s*([^;]+)/i.exec(header);
  if (plain) return (plain[1] ?? plain[2] ?? "").replace(/\\(.)/g, "$1").trim();
  return "";
}
function createClient({ proxyFetch, credentialId, base }) {
  if (!base) throw new ImmichError("error.not_connected");
  async function request(path, { method = "GET", headers = {}, body, responseType = "json", signal } = {}) {
    const init = { method, headers: { Accept: ACCEPT, ...headers }, responseType };
    if (body !== void 0) init.body = body;
    if (signal) init.signal = signal;
    const res = await proxyFetch(credentialId, `${base}/api${path}`, init);
    if (!res || !res.ok) throw errorFromResponse(res || { status: 0, headers: {} });
    return res;
  }
  async function json(path, opts = {}) {
    const init = { ...opts, responseType: "text" };
    if (opts.json !== void 0) {
      init.body = JSON.stringify(opts.json);
      init.headers = { "Content-Type": "application/json", ...opts.headers };
      delete init.json;
    }
    const res = await request(path, init);
    const text = typeof res.body === "string" ? res.body : "";
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      throw new ImmichError("error.not_immich", {}, res.status);
    }
  }
  const page = (data) => {
    const assets = data?.assets ?? {};
    const items = Array.isArray(assets.items) ? assets.items.map(toAsset).filter((a) => a.id) : [];
    return { items, nextPage: assets.nextPage ? Number(assets.nextPage) || null : null };
  };
  async function search({ text = "", albumId = "", pageNumber = 1 } = {}) {
    const query = text.trim();
    const common = { page: pageNumber, size: PAGE_SIZE, ...albumId ? { albumIds: [albumId] } : {} };
    if (query) {
      try {
        return page(await json("/search/smart", { method: "POST", json: { ...common, query } }));
      } catch (err) {
        if (!(err instanceof ImmichError) || err.status !== 400 && err.status < 500) throw err;
      }
      return page(await json("/search/metadata", { method: "POST", json: { ...common, originalFileName: query, order: "desc" } }));
    }
    return page(await json("/search/metadata", { method: "POST", json: { ...common, order: "desc" } }));
  }
  return {
    base,
    credentialId,
    request,
    /** Who the key belongs to; also checks the connection. */
    async whoAmI() {
      const data = await json("/users/me");
      if (!data || typeof data !== "object" || !("email" in data || "name" in data)) throw new ImmichError("error.not_immich");
      return { name: String(data.name || ""), email: String(data.email || "") };
    },
    /** Own and shared albums, by name. */
    async albums() {
      const data = await json("/albums");
      const list = Array.isArray(data) ? data : [];
      return list.map((a) => ({ id: String(a.id || ""), name: String(a.albumName || ""), count: Number(a.assetCount) || 0 })).filter((a) => a.id).sort((a, b) => a.name.localeCompare(b.name));
    },
    /**
     * One page of photos and videos, newest first: all of them, those in an
     * album, or those matching `text` (smart search, else the file name).
     * @returns {Promise<{ items: ReturnType<typeof toAsset>[], nextPage: number|null }>}
     */
    async assets({ text = "", albumId = "", pageNumber = 1 } = {}) {
      if (albumId && !text.trim()) {
        const album = await json(`/albums/${encodeURIComponent(albumId)}`);
        if (Array.isArray(album?.assets)) {
          const all = album.assets.map(toAsset).filter((a) => a.id).sort((a, b) => String(b.takenAt).localeCompare(String(a.takenAt)));
          const start = (pageNumber - 1) * PAGE_SIZE;
          const items = all.slice(start, start + PAGE_SIZE);
          return { items, nextPage: start + PAGE_SIZE < all.length ? pageNumber + 1 : null };
        }
      }
      return search({ text, albumId, pageNumber });
    },
    async thumbnail(id, signal) {
      const res = await request(`/assets/${encodeURIComponent(id)}/thumbnail?size=thumbnail`, { responseType: "arraybuffer", signal, headers: { Accept: "image/*" } });
      return { data: res.body, type: (res.headers?.["content-type"] || "image/webp").split(";")[0].trim() };
    },
    /** The original file, with its name. */
    async download(asset, signal) {
      const res = await request(`/assets/${encodeURIComponent(asset.id)}/original`, { responseType: "arraybuffer", signal, headers: { Accept: "*/*" } });
      const header = (res.headers?.["content-type"] || "").split(";")[0].trim();
      const type = header && header !== "application/octet-stream" ? header : asset.type || "application/octet-stream";
      return { data: res.body, type, name: filenameFromDisposition(res.headers?.["content-disposition"]) || asset.name };
    },
    /**
     * Upload a photo or video. Immich files it by the date in the file
     * itself; `takenAt` is the fallback. Resolves to { id, duplicate }.
     * @param {{ data: Uint8Array|ArrayBuffer, name: string, type?: string, takenAt?: string }} file
     */
    async upload(file, { signal } = {}) {
      const at = file.takenAt && !Number.isNaN(Date.parse(file.takenAt)) ? new Date(file.takenAt).toISOString() : (/* @__PURE__ */ new Date()).toISOString();
      const size = file.data?.byteLength ?? 0;
      const { body, contentType } = buildMultipart([
        // Required up to Immich 2.x, ignored from 3.x on.
        ["deviceAssetId", `bulwark-${file.name}-${size}`.slice(0, 200)],
        ["deviceId", "bulwark-webmail"],
        ["fileCreatedAt", at],
        ["fileModifiedAt", at],
        ["filename", file.name],
        ["assetData", { filename: file.name, type: file.type, data: file.data }]
      ]);
      const data = await json("/assets", { method: "POST", headers: { "Content-Type": contentType }, body, signal });
      if (!data?.id) throw new ImmichError("error.unexpected", { detail: "no asset id" });
      return { id: String(data.id), duplicate: data.status === "duplicate" };
    },
    /** The photo's page in Immich's web app. */
    assetUrl(id) {
      return `${base}/photos/${encodeURIComponent(id)}`;
    }
  };
}

// immich/src/lib/connection.js
var PERSONAL = "personal";
async function adminServer(api) {
  try {
    return normalizeBase(await api.admin.getConfig("serverUrl"));
  } catch {
    return "";
  }
}
async function resolveConnection(api) {
  const configured = await adminServer(api);
  let accounts = [];
  try {
    accounts = await api.proxy.accounts() || [];
  } catch {
    accounts = [];
  }
  const mine = accounts.find((a) => a && a.credentialId === PERSONAL && a.connected);
  if (mine) {
    const base = configured && new URL(configured).origin === mine.origin ? configured : normalizeBase(mine.origin);
    return { state: "connected", base, credentialId: PERSONAL };
  }
  return { state: "disconnected", suggestedServer: configured };
}
function clientFor(api, connection) {
  if (!connection || connection.state !== "connected") throw new ImmichError("error.not_connected");
  return createClient({ proxyFetch: (...a) => api.proxy.fetch(...a), credentialId: connection.credentialId, base: connection.base });
}
async function connectPersonal(api, suggestedServer) {
  const result = await api.proxy.connect(PERSONAL, { mode: "password", ...suggestedServer ? { server: suggestedServer } : {} });
  if (!result?.connected) return { connected: false };
  const connection = await resolveConnection(api);
  if (connection.state !== "connected") return { connected: false };
  try {
    await clientFor(api, connection).whoAmI();
  } catch (err) {
    const e = toImmichError(err);
    if (e.key === "error.token" || e.key === "error.not_immich") await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    return { connected: false, error: e };
  }
  return { connected: true, connection };
}

// immich/src/lib/media.js
var MAX_ATTACH_BYTES = 25 * 1024 * 1024;
async function attachAssets(api, client, composerId, assets, { onProgress, onAttached, signal } = {}) {
  let attached = 0;
  for (let i = 0; i < assets.length; i++) {
    const asset = assets[i];
    if (signal?.aborted) throw new ImmichError("error.cancelled");
    onProgress?.(i, assets.length);
    if (asset.size > MAX_ATTACH_BYTES) throw new ImmichError("error.attach_too_large", { name: asset.name });
    const file = await client.download(asset, signal);
    const size = file.data?.byteLength ?? 0;
    if (size > MAX_ATTACH_BYTES) throw new ImmichError("error.attach_too_large", { name: file.name });
    const blob = await api.jmap.uploadBlob(new Uint8Array(file.data), file.name, file.type);
    const ok = await api.composer.attach(composerId, { blobId: blob.blobId, name: file.name, type: blob.type || file.type, size: blob.size ?? size });
    if (ok === false) throw new ImmichError("error.attach_refused", { name: file.name });
    attached++;
    onAttached?.(asset);
  }
  return attached;
}
async function saveAttachment(api, client, { emailId, blobId, name, type }) {
  if (!isMedia(name, type)) throw new ImmichError("error.not_media", { name: name || "" });
  const [view, file] = await Promise.all([
    api.email.get(emailId).catch(() => null),
    api.email.getAttachment(emailId, blobId)
  ]);
  const fileName = file?.name || name || "photo";
  const fileType = mediaType(fileName, file?.type || type);
  if (!/^(image|video)\//.test(fileType)) throw new ImmichError("error.not_media", { name: fileName });
  const result = await client.upload({ data: file.data, name: fileName, type: fileType, takenAt: view?.receivedAt || "" });
  return { name: fileName, ...result };
}

// immich/src/lib/background.js
var ACTION_ATTACH = "from-immich";
var ACTION_SAVE = "save-attachment";
function createBackground(api) {
  const t2 = (key, vars) => api.i18n.t(key, vars);
  async function ensureConnection() {
    const connection = await resolveConnection(api);
    if (connection.state === "connected") return connection;
    const go = await api.ui.confirm({ title: t2("connect.title"), message: t2("connect.needed"), confirmLabel: t2("connect.button"), cancelLabel: t2("common.cancel") });
    if (!go) return null;
    const result = await connectPersonal(api, connection.suggestedServer);
    if (!result.connected) {
      if (result.error) throw result.error;
      return null;
    }
    return result.connection;
  }
  async function attachFromImmich(composerId) {
    const result = await api.ui.openDialog({
      title: t2("picker.title"),
      slot: "plugin-dialog",
      extraProps: { view: "picker", composerId },
      width: 900
    });
    const attached = Number(result?.attached) || 0;
    if (attached) api.toast.success(t2("picker.attached", { count: attached }));
    return attached;
  }
  async function save(ctx) {
    try {
      const connection = await ensureConnection();
      if (!connection) return null;
      const result = await saveAttachment(api, clientFor(api, connection), ctx);
      api.toast.success(t2(result.duplicate ? "save.duplicate" : "save.done", { name: result.name }));
      return result;
    } catch (err) {
      api.toast.error(errorText(t2, err));
      return null;
    }
  }
  function onAction({ actionId, context } = {}) {
    const ctx = context || {};
    if (actionId === ACTION_ATTACH && typeof ctx.composerId === "string" && ctx.composerId) return attachFromImmich(ctx.composerId);
    if (actionId === ACTION_SAVE && ctx.emailId && ctx.blobId) return save(ctx);
    return null;
  }
  async function registerUi() {
    const calls = [
      api.ui.setActions("composer-attach-menu", [{ id: ACTION_ATTACH, label: t2("composer.attach_menu"), icon: "photo" }]),
      api.ui.setActions("attachment-menu", [{ id: ACTION_SAVE, label: t2("save.action"), icon: "cloud-upload" }])
    ];
    await Promise.all(calls.map((p) => Promise.resolve(p).catch((err) => api.log?.warn?.("setup failed", err?.message))));
  }
  return { onAction, registerUi, save, attachFromImmich };
}

// immich/src/ui/host.js
var current = null;
function setApi(api) {
  current = api;
}
function getApi() {
  if (current) return current;
  current = require("@plugin-host");
  return current;
}
function t(key, vars) {
  return getApi().i18n.t(key, vars);
}
function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return String(url || "");
  }
}
function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  try {
    return d.toLocaleDateString(getApi().i18n.getLocale(), { year: "numeric", month: "short", day: "numeric" });
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

// immich/src/ui/Picker.jsx
var import_react2 = require("react");
var import_ui2 = require("@plugin-host/ui");

// immich/src/ui/common.jsx
var import_react = require("react");
var import_ui = require("@plugin-host/ui");
var import_jsx_runtime = require("react/jsx-runtime");
function useConnection() {
  const [connection, setConnection] = (0, import_react.useState)(null);
  const [loading, setLoading] = (0, import_react.useState)(true);
  const refresh = (0, import_react.useCallback)(async () => {
    setLoading(true);
    try {
      setConnection(await resolveConnection(getApi()));
    } finally {
      setLoading(false);
    }
  }, []);
  (0, import_react.useEffect)(() => {
    void refresh();
  }, [refresh]);
  const client = (0, import_react.useMemo)(() => connection?.state === "connected" ? clientFor(getApi(), connection) : null, [connection]);
  return { connection, client, loading, refresh };
}
function ErrorAlert({ error, onRetry }) {
  if (!error) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Alert, { tone: "danger", icon: "alert-circle", action: onRetry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.LinkButton, { onClick: onRetry, children: t("common.retry") }) : null, children: errorText(t, error) });
}
function useConnect(connection, onConnected) {
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [error, setError] = (0, import_react.useState)(null);
  const connect = async () => {
    setBusy(true);
    setError(null);
    try {
      const result = await connectPersonal(getApi(), connection?.suggestedServer || "");
      if (result.connected) onConnected?.(result.connection);
      else if (result.error) setError(result.error);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  return { busy, error, connect };
}
function connectIntro(connection) {
  const intro = connection?.suggestedServer ? t("connect.intro_server", { host: hostOf(connection.suggestedServer) }) : t("connect.intro");
  return `${intro} ${t("connect.key_hint")}`;
}
function ConnectEmptyState({ connection, onConnected }) {
  const { busy, error, connect } = useConnect(connection, onConnected);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      import_ui.EmptyState,
      {
        icon: "photo",
        title: t("connect.title"),
        description: connectIntro(connection),
        actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Button, { busy, onClick: connect, children: t("connect.button") })
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorAlert, { error })
  ] });
}

// immich/src/lib/queue.js
function createQueue(limit = 4) {
  let running = 0;
  const waiting = [];
  const next = () => {
    if (running >= limit || waiting.length === 0) return;
    const { task, resolve, reject } = waiting.shift();
    running++;
    Promise.resolve().then(task).then(resolve, reject).finally(() => {
      running--;
      next();
    });
  };
  return {
    run(task) {
      return new Promise((resolve, reject) => {
        waiting.push({ task, resolve, reject });
        next();
      });
    },
    /** Drop tasks that haven't started (the list they were for is gone). */
    clear() {
      waiting.splice(0).forEach(({ reject }) => reject(new Error("cancelled")));
    }
  };
}

// immich/src/ui/Picker.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var SEARCH_DELAY_MS = 300;
function Tile({ asset, picked, onToggle, load }) {
  const [url, setUrl] = (0, import_react2.useState)(null);
  (0, import_react2.useEffect)(() => {
    let made = null;
    let cancelled = false;
    load(asset.id).then((thumb) => {
      if (cancelled || !thumb) return;
      made = URL.createObjectURL(new Blob([thumb.data], { type: thumb.type }));
      setUrl(made);
    }).catch(() => {
    });
    return () => {
      cancelled = true;
      if (made) URL.revokeObjectURL(made);
    };
  }, [asset.id, load]);
  const label = [asset.name, asset.kind === "video" ? t("picker.video") : "", formatDate(asset.takenAt)].filter(Boolean).join(", ");
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
    "button",
    {
      type: "button",
      "aria-pressed": picked,
      "aria-label": label,
      title: label,
      onClick: onToggle,
      style: {
        position: "relative",
        aspectRatio: "1 / 1",
        padding: 0,
        overflow: "hidden",
        cursor: "pointer",
        borderRadius: 6,
        border: picked ? "3px solid var(--color-primary)" : "1px solid var(--color-border)",
        background: "var(--color-muted)"
      },
      children: [
        url ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("img", { src: url, alt: "", style: { width: "100%", height: "100%", objectFit: "cover", display: "block" } }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: { fontSize: 12, color: "var(--color-muted-foreground)", padding: 4, wordBreak: "break-all" }, children: asset.name }),
        asset.kind === "video" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { "aria-hidden": "true", style: { position: "absolute", insetInlineStart: 4, bottom: 4, fontSize: 11, padding: "1px 5px", borderRadius: 4, background: "rgba(0,0,0,.6)", color: "#fff" }, children: t("picker.video") })
      ]
    }
  );
}
function Picker({ composerId, onClose }) {
  const { connection, client, loading, refresh } = useConnection();
  const [albums, setAlbums] = (0, import_react2.useState)([]);
  const [text, setText] = (0, import_react2.useState)("");
  const [albumId, setAlbumId] = (0, import_react2.useState)("");
  const [items, setItems] = (0, import_react2.useState)([]);
  const [nextPage, setNextPage] = (0, import_react2.useState)(null);
  const [searching, setSearching] = (0, import_react2.useState)(false);
  const [searched, setSearched] = (0, import_react2.useState)(false);
  const [error, setError] = (0, import_react2.useState)(null);
  const [picked, setPicked] = (0, import_react2.useState)(() => /* @__PURE__ */ new Map());
  const [busy, setBusy] = (0, import_react2.useState)("");
  const attachedCount = (0, import_react2.useRef)(0);
  const abortRef = (0, import_react2.useRef)(null);
  const queue = (0, import_react2.useMemo)(() => createQueue(4), [client]);
  const api = getApi();
  const loadThumb = (0, import_react2.useCallback)((id) => queue.run(() => client.thumbnail(id)), [client, queue]);
  (0, import_react2.useEffect)(() => {
    if (!client) return;
    client.albums().then(setAlbums).catch(() => setAlbums([]));
  }, [client]);
  const seq = (0, import_react2.useRef)(0);
  const run = (0, import_react2.useCallback)(async (pageNumber, q, album) => {
    if (!client) return;
    const mine = ++seq.current;
    setSearching(true);
    setError(null);
    try {
      const res = await client.assets({ text: q, albumId: album, pageNumber });
      if (mine !== seq.current) return;
      setItems((prev) => pageNumber === 1 ? res.items : [...prev, ...res.items]);
      setNextPage(res.nextPage);
      setSearched(true);
    } catch (err) {
      if (mine === seq.current) setError(err);
    } finally {
      if (mine === seq.current) setSearching(false);
    }
  }, [client]);
  const shownAlbum = (0, import_react2.useRef)(null);
  (0, import_react2.useEffect)(() => {
    if (!client) return void 0;
    const typed = searched && shownAlbum.current === albumId;
    shownAlbum.current = albumId;
    const timer = setTimeout(() => {
      void run(1, text, albumId);
    }, typed ? SEARCH_DELAY_MS : 0);
    return () => clearTimeout(timer);
  }, [client, text, albumId]);
  const close = () => onClose?.(attachedCount.current);
  const toggle = (asset) => setPicked((prev) => {
    const next = new Map(prev);
    if (next.has(asset.id)) next.delete(asset.id);
    else next.set(asset.id, asset);
    return next;
  });
  const attach = async () => {
    const assets = [...picked.values()];
    if (!assets.length) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setError(null);
    setBusy(t("picker.attaching", { current: 1, total: assets.length }));
    try {
      await attachAssets(api, client, composerId, assets, {
        signal: controller.signal,
        onProgress: (i, n) => setBusy(t("picker.attaching", { current: i + 1, total: n })),
        // What is in the message leaves the selection, so trying again doesn't attach it twice.
        onAttached: (asset) => {
          attachedCount.current++;
          setPicked((prev) => {
            const next = new Map(prev);
            next.delete(asset.id);
            return next;
          });
        }
      });
      close();
    } catch (err) {
      if (err?.key !== "error.cancelled") setError(err);
    } finally {
      abortRef.current = null;
      setBusy("");
    }
  };
  if (loading) return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Loading, { label: t("common.loading") });
  if (connection?.state !== "connected") return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ConnectEmptyState, { connection, onConnected: () => refresh() });
  const albumOptions = [{ value: "", label: t("picker.all") }, ...albums.map((a) => ({ value: a.id, label: a.name }))];
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { role: "search", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Row, { gap: 2, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.SearchInput, { value: text, onChange: setText, label: t("picker.search_label"), placeholder: t("picker.search_placeholder") }),
      albums.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Select, { value: albumId, onChange: (v) => setAlbumId(v), options: albumOptions, "aria-label": t("picker.album") })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ErrorAlert, { error }),
    busy && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Spinner, { label: busy }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { "aria-live": "polite", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", size: "xs", children: searching ? t("picker.searching") : t("picker.selected", { count: picked.size }) }) }),
    searched && items.length === 0 && !searching && !error && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.EmptyState, { compact: true, icon: "photo", title: t("picker.none") }),
    items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { role: "group", "aria-label": t("picker.results"), style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(104px, 1fr))", gap: 6 }, children: items.map((asset) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Tile, { asset, picked: picked.has(asset.id), onToggle: () => toggle(asset), load: loadThumb }, asset.id)) }),
    nextPage && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Row, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Button, { variant: "secondary", busy: searching, onClick: () => run(nextPage, text, albumId), children: t("picker.more") }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      import_ui2.DialogButtons,
      {
        buttons: [
          { id: "cancel", label: t("common.cancel"), variant: "secondary" },
          { id: "attach", label: picked.size ? t("picker.attach_count", { count: picked.size }) : t("picker.attach"), variant: "primary", disabled: picked.size === 0, busy: !!busy }
        ],
        onClick: (id) => {
          if (id === "cancel") {
            if (abortRef.current) abortRef.current.abort();
            else close();
          } else if (id === "attach") void attach();
        }
      }
    )
  ] });
}

// immich/src/ui/Settings.jsx
var import_react3 = require("react");
var import_ui3 = require("@plugin-host/ui");
var import_jsx_runtime3 = require("react/jsx-runtime");
function Settings() {
  const { connection, client, loading, refresh } = useConnection();
  const { busy, error: connectError, connect } = useConnect(connection, () => refresh());
  const [who, setWho] = (0, import_react3.useState)("");
  const [error, setError] = (0, import_react3.useState)(null);
  const api = getApi();
  (0, import_react3.useEffect)(() => {
    if (!client) return;
    client.whoAmI().then((w) => setWho(w.email || w.name)).catch((err) => setError(err));
  }, [client]);
  const disconnect = async () => {
    await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    setWho("");
    setError(null);
    await refresh();
  };
  const host = connection?.base ? hostOf(connection.base) : "";
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Stack, { gap: 6, children: /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_ui3.Section, { title: t("settings.title"), description: t("settings.intro", { attach: t("composer.attach_menu"), save: t("save.action") }), children: [
    loading && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Loading, {}),
    !loading && connection?.state === "disconnected" && /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_jsx_runtime3.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.SettingRow, { label: t("settings.connection"), description: connectIntro(connection), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Button, { busy, onClick: connect, children: t("connect.button") }) }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ErrorAlert, { error: connectError })
    ] }),
    !loading && connection?.state === "connected" && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.SettingRow, { label: t("settings.connection"), description: who ? t("settings.connected_as", { host, user: who }) : t("settings.connected", { host }), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Button, { variant: "secondary", onClick: disconnect, children: t("settings.disconnect") }) }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ErrorAlert, { error })
  ] }) });
}

// immich/src/index.js
var background = null;
async function activate(api) {
  setApi(api);
  background = createBackground(api);
  await background.registerUi();
  api.i18n.onLocaleChange(() => {
    void background.registerUi();
  });
}
var hooks = {
  onAction(event) {
    if (background) void Promise.resolve(background.onAction(event)).catch(() => {
    });
  }
};
function Dialog(props) {
  return (0, import_react4.createElement)(Picker, { composerId: props.composerId, onClose: (attached) => props.onResult?.({ attached }) });
}
var slots = {
  "plugin-dialog": { component: Dialog },
  "settings-section": { component: Settings }
};
