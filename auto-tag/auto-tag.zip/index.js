var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// auto-tag/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);
var rules = [];
var totalTagged = 0;
var pluginApi = null;
function fromText(email) {
  const from = email && email.from;
  if (!from) return "";
  if (typeof from === "string") return from.toLowerCase();
  const list = Array.isArray(from) ? from : [from];
  return list.filter(Boolean).map((a) => typeof a === "string" ? a : `${a.name || ""} <${a.email || ""}>`).join(", ").toLowerCase();
}
function subjectText(email) {
  return String(email && email.subject || "").toLowerCase();
}
function hasHeader(email, name) {
  const headers = email && email.headers;
  if (!headers) return false;
  const wanted = name.toLowerCase();
  if (Array.isArray(headers)) {
    return headers.some((h) => h && String(h.name || "").toLowerCase() === wanted);
  }
  if (typeof headers === "object") {
    return Object.keys(headers).some((k) => k.toLowerCase() === wanted);
  }
  return false;
}
function buildRules(settings) {
  const out = [];
  if (settings.tagGithub !== false) {
    out.push({
      name: "GitHub",
      keyword: "$github",
      check: (email) => {
        const from = fromText(email);
        return from.includes("notifications@github.com") || from.includes("noreply@github.com");
      }
    });
  }
  if (settings.tagNewsletter !== false) {
    out.push({
      name: "Newsletter",
      keyword: "$newsletter",
      check: (email) => {
        const from = fromText(email);
        const subject = subjectText(email);
        return hasHeader(email, "List-Unsubscribe") || from.includes("newsletter") || from.includes("noreply") || from.includes("no-reply") || subject.includes("unsubscribe") || subject.includes("weekly digest") || subject.includes("monthly update");
      }
    });
  }
  if (settings.tagInvoice !== false) {
    out.push({
      name: "Invoice",
      keyword: "$invoice",
      check: (email) => {
        const subject = subjectText(email);
        return subject.includes("invoice") || subject.includes("receipt") || subject.includes("payment confirmation") || subject.includes("order confirmation") || subject.includes("billing statement");
      }
    });
  }
  return out;
}
async function activate(api) {
  pluginApi = api;
  rules = buildRules(api.plugin.settings || {});
  api.plugin.onSettingsChange((settings) => {
    rules = buildRules(settings || {});
  });
  totalTagged = Number(await api.storage.get("totalTagged") || 0);
  if (rules.length === 0) {
    api.log.info("Auto Tag: no rules enabled");
    return;
  }
  api.log.info(`Auto Tag: ${rules.length} rule(s) active, ${totalTagged} message(s) tagged so far`);
}
var hooks = {
  async onNewEmailReceived(email) {
    if (!pluginApi || rules.length === 0) return;
    if (!email || typeof email !== "object") return;
    const emailId = email.id || email.emailId;
    if (!emailId) return;
    const rule = rules.find((r) => {
      try {
        return r.check(email);
      } catch {
        return false;
      }
    });
    if (!rule) return;
    if (email.keywords && email.keywords[rule.keyword]) return;
    try {
      await pluginApi.email.setKeyword(String(emailId), rule.keyword, email.accountId || void 0);
    } catch (err) {
      pluginApi.log.warn(`Auto Tag: could not tag "${email.subject || ""}" as ${rule.keyword}`, err);
      return;
    }
    pluginApi.log.info(`Auto Tag: tagged "${email.subject || ""}" as ${rule.keyword} (rule "${rule.name}")`);
    totalTagged++;
    void pluginApi.storage.set("totalTagged", totalTagged);
  }
};
