var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// email-stats/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// email-stats/src/lib/widget.js
var import_ui = require("@plugin-host/ui");
var POLL_MS = 3e3;
var ROWS = [
  { key: "opened", label: "Opened", icon: "mail-opened" },
  { key: "sent", label: "Sent", icon: "send" },
  { key: "received", label: "Received", icon: "inbox" }
];
function readStats(stored) {
  const s = stored && typeof stored === "object" ? stored : {};
  return {
    opened: Number(s.opened) || 0,
    sent: Number(s.sent) || 0,
    received: Number(s.received) || 0
  };
}
function makeStatsWidget(React2, api) {
  const { createElement: h, useCallback, useEffect, useState } = React2;
  return function StatsWidget() {
    const [stats, setStats] = useState(null);
    const refresh = useCallback(async () => {
      try {
        setStats(readStats(await api.storage.get("lifetime")));
      } catch (err) {
        api.log.warn("email-stats: could not read storage", err);
        setStats((prev) => prev ?? readStats(null));
      }
    }, []);
    useEffect(() => {
      void refresh();
      const id = setInterval(() => {
        void refresh();
      }, POLL_MS);
      const onFocus = () => {
        void refresh();
      };
      window.addEventListener("focus", onFocus);
      return () => {
        clearInterval(id);
        window.removeEventListener("focus", onFocus);
      };
    }, [refresh]);
    if (!stats) return h(import_ui.SidebarEmpty, null, "Loading…");
    return h(React2.Fragment, null, ...ROWS.map((row) => h(import_ui.SidebarRow, {
      key: row.key,
      icon: row.icon,
      label: row.label,
      detail: stats[row.key].toLocaleString()
    })));
  };
}

// email-stats/src/index.js
var React = require("react");
var slotApi = require("@plugin-host");
var slots = {
  "sidebar-section": {
    component: makeStatsWidget(React, slotApi),
    order: 10
  }
};
var pluginApi = null;
var lifetime = { opened: 0, sent: 0, received: 0 };
async function bump(field) {
  if (!pluginApi) return;
  lifetime[field]++;
  void pluginApi.storage.set("lifetime", lifetime);
}
var hooks = {
  onEmailOpen() {
    if (pluginApi?.plugin.settings.trackOpens === false) return;
    void bump("opened");
  },
  onAfterEmailSend() {
    if (pluginApi?.plugin.settings.trackSent === false) return;
    void bump("sent");
  },
  onNewEmailReceived() {
    void bump("received");
  }
};
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("lifetime") || null;
  if (stored && typeof stored === "object") {
    lifetime = {
      opened: Number(stored.opened) || 0,
      sent: Number(stored.sent) || 0,
      received: Number(stored.received) || 0
    };
  }
  api.log.info(
    `Email Stats activated (lifetime: opened=${lifetime.opened} sent=${lifetime.sent} received=${lifetime.received})`
  );
}
