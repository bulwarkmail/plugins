// src/index.js
function getReact() {
  return globalThis.__PLUGIN_EXTERNALS__?.React;
}
var h = (...args) => getReact().createElement(...args);
var useState = (...args) => getReact().useState(...args);
var useEffect = (...args) => getReact().useEffect(...args);
var sessionStats = { opened: 0, sent: 0, received: 0 };
var listeners = /* @__PURE__ */ new Set();
function notifyListeners() {
  listeners.forEach((fn) => fn({ ...sessionStats }));
}
function StatsWidget() {
  const [stats, setStats] = useState({ ...sessionStats });
  useEffect(() => {
    listeners.add(setStats);
    return () => listeners.delete(setStats);
  }, []);
  const today = (/* @__PURE__ */ new Date()).toLocaleDateString();
  return h(
    "div",
    { style: { padding: "12px", fontSize: "13px" } },
    h("div", { style: { fontWeight: 600, marginBottom: "8px" } }, `Session Stats \u2014 ${today}`),
    h(
      "div",
      { style: { display: "flex", flexDirection: "column", gap: "6px" } },
      h(
        "div",
        { style: { display: "flex", justifyContent: "space-between" } },
        h("span", null, "\u{1F4D6} Opened"),
        h("span", { style: { fontWeight: 600 } }, stats.opened)
      ),
      h(
        "div",
        { style: { display: "flex", justifyContent: "space-between" } },
        h("span", null, "\u{1F4E4} Sent"),
        h("span", { style: { fontWeight: 600 } }, stats.sent)
      ),
      h(
        "div",
        { style: { display: "flex", justifyContent: "space-between" } },
        h("span", null, "\u{1F4E5} Received"),
        h("span", { style: { fontWeight: 600 } }, stats.received)
      )
    )
  );
}
function activate(api) {
  const disposables = [];
  sessionStats = { opened: 0, sent: 0, received: 0 };
  const lifetime = api.storage.get("lifetime") || { opened: 0, sent: 0, received: 0 };
  if (api.plugin.settings.trackOpens !== false) {
    disposables.push(
      api.hooks.onEmailOpen(() => {
        sessionStats.opened++;
        lifetime.opened++;
        api.storage.set("lifetime", lifetime);
        notifyListeners();
      })
    );
  }
  if (api.plugin.settings.trackSent !== false) {
    disposables.push(
      api.hooks.onAfterEmailSend(() => {
        sessionStats.sent++;
        lifetime.sent++;
        api.storage.set("lifetime", lifetime);
        notifyListeners();
      })
    );
  }
  disposables.push(
    api.hooks.onNewEmailReceived(() => {
      sessionStats.received++;
      lifetime.received++;
      api.storage.set("lifetime", lifetime);
      notifyListeners();
    })
  );
  disposables.push(
    api.ui.registerSidebarWidget({
      id: "email-stats-widget",
      label: "Email Stats",
      render: StatsWidget,
      order: 10
    })
  );
  api.log.info("Email Stats plugin activated");
  return {
    dispose: () => {
      disposables.forEach((d) => d.dispose());
      listeners.clear();
    }
  };
}
export {
  activate
};
