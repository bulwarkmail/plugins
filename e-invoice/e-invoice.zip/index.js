var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all2) => {
  for (var name in all2)
    __defProp(target, name, { get: all2[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// e-invoice/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// e-invoice/src/ui/host.js
var current = null;
function setApi(api) {
  current = api;
}
function getApi() {
  if (current) return current;
  current = require("@plugin-host");
  return current;
}
function i18n() {
  const api = getApi();
  return { t: (k, v) => api.i18n.t(k, v), has: (k) => api.i18n.has(k), locale: api.i18n.getLocale() };
}

// e-invoice/src/ui/Banner.jsx
var import_react = require("react");
var import_ui = require("@plugin-host/ui");

// e-invoice/src/lib/xml.js
function parseXml(text2) {
  const doc = new DOMParser().parseFromString(text2, "application/xml");
  const error = doc.getElementsByTagName("parsererror")[0];
  if (error || !doc.documentElement) throw new Error("not well-formed XML");
  return doc;
}
function kids(el, name) {
  const out = [];
  if (!el) return out;
  for (let c = el.firstElementChild; c; c = c.nextElementSibling) {
    if (c.localName === name) out.push(c);
  }
  return out;
}
function all(el, path) {
  let level = el ? [el] : [];
  for (const step of path.split("/")) {
    level = level.flatMap((e) => kids(e, step));
    if (!level.length) break;
  }
  return level;
}
function one(el, ...paths) {
  for (const path of paths) {
    const found = all(el, path)[0];
    if (found) return found;
  }
  return null;
}
function text(el, ...paths) {
  const found = paths.length ? one(el, ...paths) : el;
  return found ? found.textContent.replace(/\s+/g, " ").trim() : "";
}
function block(el, ...paths) {
  const found = paths.length ? one(el, ...paths) : el;
  if (!found) return "";
  return found.textContent.replace(/\r\n?/g, "\n").split("\n").map((l) => l.trim()).join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
function attr(el, name) {
  return el ? (el.getAttribute(name) || "").trim() : "";
}
function num(el, ...paths) {
  const value = text(el, ...paths);
  if (!value) return null;
  const n = Number(value.replace(/\s/g, ""));
  return Number.isFinite(n) ? n : null;
}

// e-invoice/src/lib/parse.js
function syntaxOf(doc) {
  const root = doc.documentElement;
  const ns = root.namespaceURI || "";
  if ((root.localName === "Invoice" || root.localName === "CreditNote") && ns.includes("oasis")) return "ubl";
  if (root.localName === "CrossIndustryInvoice") return "cii";
  if (root.localName === "CrossIndustryDocument") return "zugferd1";
  return null;
}
function looksLikeInvoiceXml(head) {
  return /<(?:[\w.-]+:)?(?:CrossIndustryInvoice|CrossIndustryDocument)\b/.test(head) || /<(?:[\w.-]+:)?(?:Invoice|CreditNote)\b[^>]*urn:oasis:names:specification:ubl/.test(head);
}
function isoDate(value, format) {
  const v = (value || "").trim();
  if (!v) return "";
  if (/^\d{8}$/.test(v) && (!format || format === "102")) return `${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)}`;
  if (/^\d{6}$/.test(v) && format === "610") return `${v.slice(0, 4)}-${v.slice(4, 6)}`;
  const m = /^(\d{4}-\d{2}-\d{2})/.exec(v);
  return m ? m[1] : v;
}
function ciiDate(el, ...paths) {
  const node = one(el, ...paths.map((p) => `${p}/DateTimeString`)) || one(el, ...paths.map((p) => `${p}/DateString`));
  return node ? isoDate(node.textContent, attr(node, "format")) : "";
}
function compact(obj) {
  for (const key of Object.keys(obj)) {
    const v = obj[key];
    if (v === "" || v === null || v === void 0 || Array.isArray(v) && v.length === 0) delete obj[key];
  }
  return obj;
}
function profileOf(id) {
  const v = (id || "").toLowerCase();
  if (!v) return { name: "", family: "" };
  const xr = /xrechnung_(\d+(?:\.\d+)*)/.exec(v);
  if (xr) return { name: `XRechnung ${xr[1]}`, family: "xrechnung", extension: v.includes("#conformant#") };
  if (v.includes("xrechnung")) return { name: "XRechnung", family: "xrechnung" };
  if (v.includes("peppol")) return { name: "Peppol BIS Billing 3.0", family: "peppol" };
  if (v.startsWith("urn:ferd:")) {
    const level = /:(basic|comfort|extended)$/.exec(v)?.[1] || "";
    return { name: `ZUGFeRD 1.0 ${level.toUpperCase()}`.trim(), family: "zugferd1", level };
  }
  if (v.includes("minimum")) return { name: "MINIMUM", family: "facturx", level: "minimum" };
  if (v.includes("basicwl")) return { name: "BASIC WL", family: "facturx", level: "basicwl" };
  if (v.includes("extended")) return { name: "EXTENDED", family: "facturx", level: "extended" };
  if (v.includes("basic")) return { name: "BASIC", family: "facturx", level: "basic" };
  if (v.startsWith("urn:cen.eu:en16931:2017")) return { name: "EN 16931", family: "en16931", level: "en16931" };
  return { name: id, family: "" };
}
function ciiParty(p) {
  if (!p) return null;
  const address = one(p, "PostalTradeAddress");
  const taxIds = all(p, "SpecifiedTaxRegistration/ID");
  const contact = one(p, "DefinedTradeContact");
  return compact({
    name: text(p, "Name"),
    tradingName: text(p, "SpecifiedLegalOrganization/TradingBusinessName"),
    id: text(p, "ID") || text(p, "GlobalID"),
    legalId: text(p, "SpecifiedLegalOrganization/ID"),
    vatId: text(taxIds.find((t) => attr(t, "schemeID") === "VA")),
    taxNumber: text(taxIds.find((t) => attr(t, "schemeID") === "FC")),
    electronicAddress: text(p, "URIUniversalCommunication/URIID"),
    address: address ? compact({
      lines: [text(address, "LineOne"), text(address, "LineTwo"), text(address, "LineThree")].filter(Boolean),
      postcode: text(address, "PostcodeCode"),
      city: text(address, "CityName"),
      region: text(address, "CountrySubDivisionName"),
      country: text(address, "CountryID")
    }) : null,
    contact: contact ? compact({
      name: text(contact, "PersonName") || text(contact, "DepartmentName"),
      phone: text(contact, "TelephoneUniversalCommunication/CompleteNumber"),
      email: text(contact, "EmailURIUniversalCommunication/URIID")
    }) : null
  });
}
function ciiAllowanceCharge(ac) {
  const indicator = text(ac, "ChargeIndicator/Indicator", "ChargeIndicator").toLowerCase();
  return compact({
    charge: indicator === "true",
    amount: num(ac, "ActualAmount"),
    baseAmount: num(ac, "BasisAmount"),
    percent: num(ac, "CalculationPercent"),
    reason: text(ac, "Reason"),
    reasonCode: text(ac, "ReasonCode"),
    vatCategory: text(ac, "CategoryTradeTax/CategoryCode"),
    vatRate: num(ac, "CategoryTradeTax/RateApplicablePercent", "CategoryTradeTax/ApplicablePercent")
  });
}
function ciiAttachments(agreement) {
  return all(agreement, "AdditionalReferencedDocument").map((d) => {
    const bin = one(d, "AttachmentBinaryObject");
    return compact({
      id: text(d, "IssuerAssignedID"),
      description: text(d, "Name"),
      typeCode: text(d, "TypeCode"),
      uri: text(d, "URIID"),
      filename: attr(bin, "filename"),
      mimeType: attr(bin, "mimeCode"),
      base64: bin ? bin.textContent.replace(/\s+/g, "") : ""
    });
  });
}
function parseCii(doc, syntax) {
  const root = doc.documentElement;
  const v1 = syntax === "zugferd1";
  const context = one(root, v1 ? "SpecifiedExchangedDocumentContext" : "ExchangedDocumentContext");
  const header = one(root, v1 ? "HeaderExchangedDocument" : "ExchangedDocument");
  const tx = one(root, v1 ? "SpecifiedSupplyChainTradeTransaction" : "SupplyChainTradeTransaction");
  const agreement = one(tx, v1 ? "ApplicableSupplyChainTradeAgreement" : "ApplicableHeaderTradeAgreement");
  const delivery = one(tx, v1 ? "ApplicableSupplyChainTradeDelivery" : "ApplicableHeaderTradeDelivery");
  const settlement = one(tx, v1 ? "ApplicableSupplyChainTradeSettlement" : "ApplicableHeaderTradeSettlement");
  const sums = one(settlement, v1 ? "SpecifiedTradeSettlementMonetarySummation" : "SpecifiedTradeSettlementHeaderMonetarySummation");
  const currency = text(settlement, "InvoiceCurrencyCode") || attr(doc.querySelector("[currencyID]"), "currencyID");
  const taxTotals = all(sums, "TaxTotalAmount");
  const taxTotal = taxTotals.find((t) => !attr(t, "currencyID") || attr(t, "currencyID") === currency) || taxTotals[0];
  const lines2 = kids(tx, "IncludedSupplyChainTradeLineItem").map((li) => {
    const lineAgreement = one(li, v1 ? "SpecifiedSupplyChainTradeAgreement" : "SpecifiedLineTradeAgreement");
    const lineDelivery = one(li, v1 ? "SpecifiedSupplyChainTradeDelivery" : "SpecifiedLineTradeDelivery");
    const lineSettlement = one(li, v1 ? "SpecifiedSupplyChainTradeSettlement" : "SpecifiedLineTradeSettlement");
    const product = one(li, "SpecifiedTradeProduct");
    const qty = one(lineDelivery, "BilledQuantity");
    const netPrice = one(lineAgreement, "NetPriceProductTradePrice");
    return compact({
      id: text(li, "AssociatedDocumentLineDocument/LineID"),
      parentId: text(li, "AssociatedDocumentLineDocument/ParentLineID"),
      note: block(li, "AssociatedDocumentLineDocument/IncludedNote/Content"),
      name: text(product, "Name"),
      description: block(product, "Description"),
      sellerItemId: text(product, "SellerAssignedID"),
      standardItemId: text(product, "GlobalID"),
      quantity: qty ? num(qty) : null,
      unit: attr(qty, "unitCode"),
      unitPrice: num(netPrice, "ChargeAmount"),
      priceBaseQuantity: num(netPrice, "BasisQuantity"),
      grossPrice: num(lineAgreement, "GrossPriceProductTradePrice/ChargeAmount"),
      vatCategory: text(lineSettlement, "ApplicableTradeTax/CategoryCode"),
      vatRate: num(lineSettlement, "ApplicableTradeTax/RateApplicablePercent", "ApplicableTradeTax/ApplicablePercent"),
      netAmount: num(lineSettlement, v1 ? "SpecifiedTradeSettlementMonetarySummation/LineTotalAmount" : "SpecifiedTradeSettlementLineMonetarySummation/LineTotalAmount"),
      periodStart: ciiDate(lineSettlement, "BillingSpecifiedPeriod/StartDateTime"),
      periodEnd: ciiDate(lineSettlement, "BillingSpecifiedPeriod/EndDateTime"),
      allowancesCharges: kids(lineSettlement, "SpecifiedTradeAllowanceCharge").map(ciiAllowanceCharge)
    });
  });
  const means = kids(settlement, "SpecifiedTradeSettlementPaymentMeans").map((pm) => compact({
    code: text(pm, "TypeCode"),
    text: text(pm, "Information"),
    iban: text(pm, "PayeePartyCreditorFinancialAccount/IBANID") || text(pm, "PayeePartyCreditorFinancialAccount/ProprietaryID"),
    accountName: text(pm, "PayeePartyCreditorFinancialAccount/AccountName"),
    bic: text(pm, "PayeeSpecifiedCreditorFinancialInstitution/BICID"),
    debitedIban: text(pm, "PayerPartyDebtorFinancialAccount/IBANID"),
    card: text(pm, "ApplicableTradeSettlementFinancialCard/ID")
  }));
  const terms = kids(settlement, "SpecifiedTradePaymentTerms");
  return {
    syntax,
    profileId: text(context, "GuidelineSpecifiedDocumentContextParameter/ID"),
    processId: text(context, "BusinessProcessSpecifiedDocumentContextParameter/ID"),
    number: text(header, "ID"),
    typeCode: text(header, "TypeCode"),
    issueDate: ciiDate(header, "IssueDateTime"),
    dueDate: terms.map((t) => ciiDate(t, "DueDateDateTime")).find(Boolean) || "",
    currency,
    taxCurrency: text(settlement, "TaxCurrencyCode"),
    notes: kids(header, "IncludedNote").map((n) => block(n, "Content")).filter(Boolean),
    buyerReference: text(agreement, "BuyerReference"),
    orderReference: text(agreement, "BuyerOrderReferencedDocument/IssuerAssignedID"),
    salesOrderReference: text(agreement, "SellerOrderReferencedDocument/IssuerAssignedID"),
    contractReference: text(agreement, "ContractReferencedDocument/IssuerAssignedID"),
    projectReference: [text(agreement, "SpecifiedProcuringProject/ID"), text(agreement, "SpecifiedProcuringProject/Name")].filter(Boolean).join(" "),
    precedingInvoices: kids(settlement, "InvoiceReferencedDocument").map((d) => compact({ number: text(d, "IssuerAssignedID"), date: ciiDate(d, "FormattedIssueDateTime") })),
    deliveryDate: ciiDate(delivery, "ActualDeliverySupplyChainEvent/OccurrenceDateTime"),
    periodStart: ciiDate(settlement, "BillingSpecifiedPeriod/StartDateTime"),
    periodEnd: ciiDate(settlement, "BillingSpecifiedPeriod/EndDateTime"),
    seller: ciiParty(one(agreement, "SellerTradeParty")),
    buyer: ciiParty(one(agreement, "BuyerTradeParty")),
    payee: ciiParty(one(settlement, "PayeeTradeParty")),
    shipTo: ciiParty(one(delivery, "ShipToTradeParty")),
    lines: lines2,
    allowancesCharges: kids(settlement, "SpecifiedTradeAllowanceCharge").map(ciiAllowanceCharge),
    vat: kids(settlement, "ApplicableTradeTax").map((t) => compact({
      category: text(t, "CategoryCode"),
      rate: num(t, "RateApplicablePercent", "ApplicablePercent"),
      basis: num(t, "BasisAmount"),
      amount: num(t, "CalculatedAmount"),
      exemptionReason: text(t, "ExemptionReason"),
      exemptionCode: text(t, "ExemptionReasonCode")
    })),
    totals: compact({
      lineTotal: num(sums, "LineTotalAmount"),
      allowanceTotal: num(sums, "AllowanceTotalAmount"),
      chargeTotal: num(sums, "ChargeTotalAmount"),
      taxBasis: num(sums, "TaxBasisTotalAmount"),
      taxTotal: taxTotal ? num(taxTotal) : null,
      rounding: num(sums, "RoundingAmount"),
      grandTotal: num(sums, "GrandTotalAmount"),
      prepaid: num(sums, "TotalPrepaidAmount"),
      due: num(sums, "DuePayableAmount")
    }),
    payment: compact({
      means,
      reference: text(settlement, "PaymentReference"),
      terms: terms.map((t) => block(t, "Description")).filter(Boolean).join("\n"),
      mandateId: terms.map((t) => text(t, "DirectDebitMandateID")).find(Boolean) || "",
      creditorId: text(settlement, "CreditorReferenceID")
    }),
    attachments: ciiAttachments(agreement)
  };
}
function ublParty(p) {
  if (!p) return null;
  const address = one(p, "PostalAddress");
  const schemes = all(p, "PartyTaxScheme");
  const vat = schemes.find((s) => text(s, "TaxScheme/ID").toUpperCase() === "VAT");
  const other = schemes.find((s) => s !== vat);
  const contact = one(p, "Contact");
  const legal = one(p, "PartyLegalEntity");
  const legalName = text(legal, "RegistrationName");
  const tradingName = text(p, "PartyName/Name");
  return compact({
    name: legalName || tradingName,
    tradingName: legalName && tradingName !== legalName ? tradingName : "",
    id: text(p, "PartyIdentification/ID"),
    legalId: text(legal, "CompanyID"),
    vatId: text(vat, "CompanyID"),
    taxNumber: text(other, "CompanyID"),
    electronicAddress: text(p, "EndpointID"),
    address: address ? compact({
      lines: [text(address, "StreetName"), text(address, "AdditionalStreetName"), text(address, "AddressLine/Line")].filter(Boolean),
      postcode: text(address, "PostalZone"),
      city: text(address, "CityName"),
      region: text(address, "CountrySubentity"),
      country: text(address, "Country/IdentificationCode")
    }) : null,
    contact: contact ? compact({
      name: text(contact, "Name"),
      phone: text(contact, "Telephone"),
      email: text(contact, "ElectronicMail")
    }) : null
  });
}
function ublAllowanceCharge(ac) {
  return compact({
    charge: text(ac, "ChargeIndicator").toLowerCase() === "true",
    amount: num(ac, "Amount"),
    baseAmount: num(ac, "BaseAmount"),
    percent: num(ac, "MultiplierFactorNumeric"),
    reason: text(ac, "AllowanceChargeReason"),
    reasonCode: text(ac, "AllowanceChargeReasonCode"),
    vatCategory: text(ac, "TaxCategory/ID"),
    vatRate: num(ac, "TaxCategory/Percent")
  });
}
function parseUbl(doc) {
  const root = doc.documentElement;
  const credit = root.localName === "CreditNote";
  const sums = one(root, "LegalMonetaryTotal");
  const currency = text(root, "DocumentCurrencyCode") || attr(doc.querySelector("[currencyID]"), "currencyID");
  const taxTotals = kids(root, "TaxTotal");
  const mainTax = taxTotals.find((t) => attr(one(t, "TaxAmount"), "currencyID") === currency) || taxTotals[0];
  const delivery = one(root, "Delivery");
  const lines2 = kids(root, credit ? "CreditNoteLine" : "InvoiceLine").map((li) => {
    const qty = one(li, credit ? "CreditedQuantity" : "InvoicedQuantity");
    const item = one(li, "Item");
    const price = one(li, "Price");
    const priceAllowance = one(price, "AllowanceCharge");
    return compact({
      id: text(li, "ID"),
      note: block(li, "Note"),
      name: text(item, "Name"),
      description: block(item, "Description"),
      sellerItemId: text(item, "SellersItemIdentification/ID"),
      standardItemId: text(item, "StandardItemIdentification/ID"),
      quantity: qty ? num(qty) : null,
      unit: attr(qty, "unitCode"),
      unitPrice: num(price, "PriceAmount"),
      priceBaseQuantity: num(price, "BaseQuantity"),
      grossPrice: num(priceAllowance, "BaseAmount"),
      vatCategory: text(item, "ClassifiedTaxCategory/ID"),
      vatRate: num(item, "ClassifiedTaxCategory/Percent"),
      netAmount: num(li, "LineExtensionAmount"),
      periodStart: isoDate(text(li, "InvoicePeriod/StartDate")),
      periodEnd: isoDate(text(li, "InvoicePeriod/EndDate")),
      allowancesCharges: kids(li, "AllowanceCharge").map(ublAllowanceCharge)
    });
  });
  const means = kids(root, "PaymentMeans").map((pm) => compact({
    code: text(pm, "PaymentMeansCode"),
    text: attr(one(pm, "PaymentMeansCode"), "name"),
    iban: text(pm, "PayeeFinancialAccount/ID"),
    accountName: text(pm, "PayeeFinancialAccount/Name"),
    bic: text(pm, "PayeeFinancialAccount/FinancialInstitutionBranch/ID"),
    debitedIban: text(pm, "PaymentMandate/PayerFinancialAccount/ID"),
    card: text(pm, "CardAccount/PrimaryAccountNumberID"),
    reference: text(pm, "PaymentID"),
    mandateId: text(pm, "PaymentMandate/ID")
  }));
  return {
    syntax: "ubl",
    profileId: text(root, "CustomizationID"),
    processId: text(root, "ProfileID"),
    number: text(root, "ID"),
    typeCode: text(root, credit ? "CreditNoteTypeCode" : "InvoiceTypeCode") || (credit ? "381" : "380"),
    issueDate: isoDate(text(root, "IssueDate")),
    dueDate: isoDate(text(root, "DueDate") || text(root, "PaymentMeans/PaymentDueDate")),
    currency,
    taxCurrency: text(root, "TaxCurrencyCode"),
    notes: kids(root, "Note").map((n) => block(n)).filter(Boolean),
    buyerReference: text(root, "BuyerReference"),
    orderReference: text(root, "OrderReference/ID"),
    salesOrderReference: text(root, "OrderReference/SalesOrderID"),
    contractReference: text(root, "ContractDocumentReference/ID"),
    projectReference: text(root, "ProjectReference/ID"),
    precedingInvoices: all(root, "BillingReference/InvoiceDocumentReference").map((d) => compact({ number: text(d, "ID"), date: isoDate(text(d, "IssueDate")) })),
    deliveryDate: isoDate(text(delivery, "ActualDeliveryDate")),
    periodStart: isoDate(text(root, "InvoicePeriod/StartDate")),
    periodEnd: isoDate(text(root, "InvoicePeriod/EndDate")),
    seller: ublParty(one(root, "AccountingSupplierParty/Party")),
    buyer: ublParty(one(root, "AccountingCustomerParty/Party")),
    payee: ublParty(one(root, "PayeeParty")),
    shipTo: delivery && one(delivery, "DeliveryLocation") ? compact({
      name: text(delivery, "DeliveryParty/PartyName/Name"),
      address: compact({
        lines: [text(delivery, "DeliveryLocation/Address/StreetName"), text(delivery, "DeliveryLocation/Address/AdditionalStreetName")].filter(Boolean),
        postcode: text(delivery, "DeliveryLocation/Address/PostalZone"),
        city: text(delivery, "DeliveryLocation/Address/CityName"),
        country: text(delivery, "DeliveryLocation/Address/Country/IdentificationCode")
      })
    }) : null,
    lines: lines2,
    allowancesCharges: kids(root, "AllowanceCharge").map(ublAllowanceCharge),
    vat: kids(mainTax, "TaxSubtotal").map((s) => compact({
      category: text(s, "TaxCategory/ID"),
      rate: num(s, "TaxCategory/Percent"),
      basis: num(s, "TaxableAmount"),
      amount: num(s, "TaxAmount"),
      exemptionReason: text(s, "TaxCategory/TaxExemptionReason"),
      exemptionCode: text(s, "TaxCategory/TaxExemptionReasonCode")
    })),
    totals: compact({
      lineTotal: num(sums, "LineExtensionAmount"),
      allowanceTotal: num(sums, "AllowanceTotalAmount"),
      chargeTotal: num(sums, "ChargeTotalAmount"),
      taxBasis: num(sums, "TaxExclusiveAmount"),
      taxTotal: num(mainTax, "TaxAmount"),
      rounding: num(sums, "PayableRoundingAmount"),
      grandTotal: num(sums, "TaxInclusiveAmount"),
      prepaid: num(sums, "PrepaidAmount"),
      due: num(sums, "PayableAmount")
    }),
    payment: compact({
      means,
      reference: means.map((m) => m.reference).find(Boolean) || "",
      terms: kids(root, "PaymentTerms").map((t) => block(t, "Note")).filter(Boolean).join("\n"),
      mandateId: means.map((m) => m.mandateId).find(Boolean) || "",
      creditorId: all(root, "AccountingSupplierParty/Party/PartyIdentification/ID").filter((e) => attr(e, "schemeID") === "SEPA").map((e) => text(e))[0] || ""
    }),
    attachments: kids(root, "AdditionalDocumentReference").map((d) => {
      const bin = one(d, "Attachment/EmbeddedDocumentBinaryObject");
      return compact({
        id: text(d, "ID"),
        description: text(d, "DocumentDescription"),
        typeCode: text(d, "DocumentTypeCode"),
        uri: text(d, "Attachment/ExternalReference/URI"),
        filename: attr(bin, "filename"),
        mimeType: attr(bin, "mimeCode"),
        base64: bin ? bin.textContent.replace(/\s+/g, "") : ""
      });
    })
  };
}
function parseInvoice(xmlText) {
  const doc = parseXml(xmlText.replace(/^﻿/, ""));
  const syntax = syntaxOf(doc);
  if (!syntax) throw new Error("not an e-invoice");
  const invoice = syntax === "ubl" ? parseUbl(doc) : parseCii(doc, syntax);
  for (const key of Object.keys(invoice)) {
    const v = invoice[key];
    if (v === null || v === void 0) delete invoice[key];
  }
  invoice.profile = profileOf(invoice.profileId);
  invoice.isCreditNote = ["381", "396", "81", "83", "532"].includes(invoice.typeCode) || syntax === "ubl" && doc.documentElement.localName === "CreditNote";
  return invoice;
}

// e-invoice/src/lib/inflate.js
var LENGTH_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
var LENGTH_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
var DIST_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
var DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
var CLEN_ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
var FAST_BITS = 9;
var FAST_MASK = (1 << FAST_BITS) - 1;
function huffman(lengths) {
  const counts = new Uint16Array(16);
  for (const l of lengths) counts[l]++;
  counts[0] = 0;
  const offsets = new Uint16Array(16);
  for (let i = 1; i < 16; i++) offsets[i] = offsets[i - 1] + counts[i - 1];
  const symbols = new Uint16Array(lengths.length);
  for (let s = 0; s < lengths.length; s++) if (lengths[s]) symbols[offsets[lengths[s]]++] = s;
  const next = new Uint16Array(16);
  for (let len = 1, code = 0; len < 16; len++) {
    code = code + counts[len - 1] << 1;
    next[len] = code;
  }
  const fast = new Int32Array(1 << FAST_BITS);
  for (let s = 0; s < lengths.length; s++) {
    const len = lengths[s];
    if (!len) continue;
    const code = next[len]++;
    if (len > FAST_BITS) continue;
    let reversed = 0;
    for (let i = 0; i < len; i++) reversed |= (code >> i & 1) << len - 1 - i;
    for (let k = reversed; k <= FAST_MASK; k += 1 << len) fast[k] = len << 16 | s;
  }
  return { counts, symbols, fast };
}
var FIXED = null;
function fixedTables() {
  if (!FIXED) {
    const lit = new Uint8Array(288);
    lit.fill(8, 0, 144);
    lit.fill(9, 144, 256);
    lit.fill(7, 256, 280);
    lit.fill(8, 280, 288);
    FIXED = { lit: huffman(lit), dist: huffman(new Uint8Array(30).fill(5)) };
  }
  return FIXED;
}
function inflateRaw(input, maxOutput = 64 * 1024 * 1024) {
  let pos = 0;
  let bitBuf = 0;
  let bitCount = 0;
  let out = new Uint8Array(Math.min(Math.max(input.length * 4, 1024), maxOutput));
  let outLen = 0;
  const bits = (n) => {
    while (bitCount < n) {
      if (pos >= input.length) throw new Error("inflate: unexpected end of data");
      bitBuf |= input[pos++] << bitCount;
      bitCount += 8;
    }
    const v = bitBuf & (1 << n) - 1;
    bitBuf >>>= n;
    bitCount -= n;
    return v;
  };
  const decode = ({ counts, symbols, fast }) => {
    while (bitCount < FAST_BITS && pos < input.length) {
      bitBuf |= input[pos++] << bitCount;
      bitCount += 8;
    }
    const entry = fast[bitBuf & FAST_MASK];
    if (entry && entry >>> 16 <= bitCount) {
      const len = entry >>> 16;
      bitBuf >>>= len;
      bitCount -= len;
      return entry & 65535;
    }
    let code = 0;
    let first = 0;
    let index = 0;
    for (let len = 1; len < 16; len++) {
      code |= bits(1);
      const count = counts[len];
      if (code - first < count) return symbols[index + code - first];
      index += count;
      first = first + count << 1;
      code <<= 1;
    }
    throw new Error("inflate: bad code");
  };
  const ensure = (extra) => {
    if (outLen + extra <= out.length) return;
    if (outLen + extra > maxOutput) throw new Error("inflate: output too large");
    const next = new Uint8Array(Math.min(Math.max(out.length * 2, outLen + extra), maxOutput));
    next.set(out.subarray(0, outLen));
    out = next;
  };
  let final = 0;
  while (!final) {
    final = bits(1);
    const type = bits(2);
    if (type === 0) {
      bitBuf = 0;
      bitCount = 0;
      if (pos + 4 > input.length) throw new Error("inflate: unexpected end of data");
      const len = input[pos] | input[pos + 1] << 8;
      const nlen = input[pos + 2] | input[pos + 3] << 8;
      if ((len ^ 65535) !== nlen) throw new Error("inflate: bad stored block");
      pos += 4;
      if (pos + len > input.length) throw new Error("inflate: unexpected end of data");
      ensure(len);
      out.set(input.subarray(pos, pos + len), outLen);
      outLen += len;
      pos += len;
      continue;
    }
    let lit;
    let dist;
    if (type === 1) {
      ({ lit, dist } = fixedTables());
    } else if (type === 2) {
      const hlit = bits(5) + 257;
      const hdist = bits(5) + 1;
      const hclen = bits(4) + 4;
      const clens = new Uint8Array(19);
      for (let i = 0; i < hclen; i++) clens[CLEN_ORDER[i]] = bits(3);
      const clen = huffman(clens);
      const lengths = new Uint8Array(hlit + hdist);
      for (let i = 0; i < hlit + hdist; ) {
        const sym = decode(clen);
        if (sym < 16) {
          lengths[i++] = sym;
          continue;
        }
        let repeat;
        let value = 0;
        if (sym === 16) {
          if (i === 0) throw new Error("inflate: bad lengths");
          value = lengths[i - 1];
          repeat = 3 + bits(2);
        } else if (sym === 17) repeat = 3 + bits(3);
        else repeat = 11 + bits(7);
        if (i + repeat > lengths.length) throw new Error("inflate: bad lengths");
        lengths.fill(value, i, i + repeat);
        i += repeat;
      }
      lit = huffman(lengths.subarray(0, hlit));
      dist = huffman(lengths.subarray(hlit));
    } else {
      throw new Error("inflate: bad block type");
    }
    for (; ; ) {
      const sym = decode(lit);
      if (sym < 256) {
        ensure(1);
        out[outLen++] = sym;
      } else if (sym === 256) {
        break;
      } else {
        const li = sym - 257;
        if (li >= 29) throw new Error("inflate: bad length");
        const length = LENGTH_BASE[li] + bits(LENGTH_EXTRA[li]);
        const di = decode(dist);
        if (di >= 30) throw new Error("inflate: bad distance");
        const distance = DIST_BASE[di] + bits(DIST_EXTRA[di]);
        if (distance > outLen) throw new Error("inflate: distance too far back");
        ensure(length);
        for (let k = 0; k < length; k++, outLen++) out[outLen] = out[outLen - distance];
      }
    }
  }
  return out.slice(0, outLen);
}
function inflate(input, maxOutput) {
  const zlib = input.length > 2 && (input[0] & 15) === 8 && (input[0] << 8 | input[1]) % 31 === 0;
  return inflateRaw(zlib ? input.subarray(2) : input, maxOutput);
}

// e-invoice/src/lib/pdf.js
var latin1 = (bytes) => new TextDecoder("latin1").decode(bytes);
function isPdf(bytes) {
  return bytes.length > 5 && latin1(bytes.subarray(0, 1024)).includes("%PDF-");
}
function pdfString(raw) {
  if (raw.startsWith("<")) {
    const hex = raw.slice(1, -1).replace(/\s/g, "");
    const bytes2 = new Uint8Array(hex.length / 2);
    for (let i = 0; i < bytes2.length; i++) bytes2[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return decodeTextBytes(bytes2);
  }
  const body = raw.slice(1, -1).replace(/\\([nrtbf()\\]|[0-7]{1,3})/g, (_, e) => {
    if (/^[0-7]/.test(e)) return String.fromCharCode(parseInt(e, 8));
    return { n: "\n", r: "\r", t: "	", b: "\b", f: "\f" }[e] ?? e;
  });
  const bytes = Uint8Array.from(body, (c) => c.charCodeAt(0) & 255);
  return decodeTextBytes(bytes);
}
function decodeTextBytes(bytes) {
  if (bytes[0] === 254 && bytes[1] === 255) return new TextDecoder("utf-16be").decode(bytes.subarray(2));
  if (bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191) return new TextDecoder().decode(bytes.subarray(3));
  return latin1(bytes);
}
function fileNames(text2) {
  const names = /* @__PURE__ */ new Map();
  const spec = /\/EF\s*<<\s*\/(?:U?F)\s+(\d+)\s+\d+\s+R[^>]*>>/g;
  let m;
  while (m = spec.exec(text2)) {
    const objectNumber = Number(m[1]);
    const around = text2.slice(Math.max(0, m.index - 600), m.index + m[0].length + 600);
    const name = /\/UF\s*(\((?:\\.|[^\\)])*\)|<[0-9A-Fa-f\s]*>)/.exec(around) || /\/F\s*(\((?:\\.|[^\\)])*\)|<[0-9A-Fa-f\s]*>)/.exec(around);
    if (name && !names.has(objectNumber)) names.set(objectNumber, pdfString(name[1]));
  }
  return names;
}
function directLength(dict, text2) {
  const ref = /\/Length\s+(\d+)\s+(\d+)\s+R/.exec(dict);
  if (ref) {
    const target = new RegExp(`(?:^|[^0-9])${ref[1]}\\s+${ref[2]}\\s+obj\\s*(\\d+)\\s*endobj`).exec(text2);
    return target ? Number(target[1]) : null;
  }
  const direct = /\/Length\s+(\d+)/.exec(dict);
  return direct ? Number(direct[1]) : null;
}
function embeddedFiles(bytes, { maxFiles = 20, maxFileBytes = 20 * 1024 * 1024 } = {}) {
  const text2 = latin1(bytes);
  const encrypted = /\/Encrypt\s+(\d+\s+\d+\s+R|<<)/.test(text2);
  const names = fileNames(text2);
  const files = [];
  const streamRe = />>\s*stream(\r\n|\n|\r)/g;
  let m;
  while ((m = streamRe.exec(text2)) && files.length < maxFiles) {
    const objAt = text2.lastIndexOf("obj", m.index);
    const header = objAt > 0 ? /(\d+)\s+\d+\s+$/.exec(text2.slice(Math.max(0, objAt - 24), objAt)) : null;
    const dict = objAt > 0 ? text2.slice(objAt + 3, m.index + 2) : "";
    const objectNumber = header ? Number(header[1]) : -1;
    if (!/\/Type\s*\/EmbeddedFile\b/.test(dict) && !/\/Subtype\s*\/(?:text#2[Ff]xml|application#2[Ff]xml)/.test(dict)) continue;
    const start = m.index + m[0].length;
    const end = text2.indexOf("endstream", start);
    if (end < 0) break;
    const length = directLength(dict, text2);
    let raw = bytes.subarray(start, length !== null && start + length <= end ? start + length : end);
    if (length === null) {
      let e = raw.length;
      while (e > 0 && (raw[e - 1] === 10 || raw[e - 1] === 13)) e--;
      raw = raw.subarray(0, e);
    }
    streamRe.lastIndex = end;
    const filter = /\/Filter\s*\[?\s*\/(\w+)/.exec(dict)?.[1];
    let data;
    try {
      if (!filter) data = raw.slice();
      else if (filter === "FlateDecode" || filter === "Fl") data = inflate(raw, maxFileBytes);
      else continue;
    } catch {
      continue;
    }
    files.push({ name: names.get(objectNumber) || "", data, encrypted });
  }
  return files;
}

// e-invoice/src/lib/detect.js
var MAX_XML_BYTES = 10 * 1024 * 1024;
var MAX_PDF_BYTES = 20 * 1024 * 1024;
var ext = (name) => (/\.([a-z0-9]+)$/i.exec(name || "")?.[1] || "").toLowerCase();
function kindOf(att) {
  const type = (att.type || "").toLowerCase();
  const e = ext(att.name);
  if (e === "xml" || /[/+]xml$/.test(type)) return "xml";
  if (e === "pdf" || type === "application/pdf") return "pdf";
  return null;
}
function candidates(attachments) {
  const out = [];
  for (const att of attachments || []) {
    const kind = kindOf(att);
    if (!kind || !att.blobId) continue;
    if (att.size > (kind === "xml" ? MAX_XML_BYTES : MAX_PDF_BYTES)) continue;
    out.push({ ...att, kind });
  }
  return out.sort((a, b) => a.kind === b.kind ? 0 : a.kind === "xml" ? -1 : 1);
}
function decodeXml(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (u8[0] === 254 && u8[1] === 255) return new TextDecoder("utf-16be").decode(u8);
  if (u8[0] === 255 && u8[1] === 254) return new TextDecoder("utf-16le").decode(u8);
  const head = new TextDecoder("latin1").decode(u8.subarray(0, 200));
  const declared = /encoding\s*=\s*["']([\w.-]+)["']/i.exec(head)?.[1];
  try {
    return new TextDecoder(declared || "utf-8").decode(u8);
  } catch {
    return new TextDecoder("utf-8").decode(u8);
  }
}
function tryParse(text2) {
  if (!looksLikeInvoiceXml(text2)) return null;
  try {
    return parseInvoice(text2);
  } catch {
    return null;
  }
}
function invoiceFromBytes(kind, bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (kind === "xml") {
    const text2 = decodeXml(u8);
    const invoice = tryParse(text2);
    return invoice ? { invoice, xml: text2 } : null;
  }
  if (kind === "pdf" && isPdf(u8)) {
    for (const file of embeddedFiles(u8)) {
      const text2 = decodeXml(file.data);
      const invoice = tryParse(text2);
      if (invoice) return { invoice, xml: text2, embeddedName: file.name || "" };
    }
  }
  return null;
}
async function findInvoice(attachments, read) {
  for (const att of candidates(attachments)) {
    let data;
    try {
      data = await read(att.blobId);
    } catch {
      continue;
    }
    const found = invoiceFromBytes(att.kind, data);
    if (found) {
      return {
        ...found,
        source: { blobId: att.blobId, name: att.name || "", kind: att.kind, embeddedName: found.embeddedName || "" }
      };
    }
  }
  return null;
}

// e-invoice/src/lib/present.js
function createFormat(locale) {
  const safeLocale = (() => {
    try {
      new Intl.NumberFormat(locale);
      return locale;
    } catch {
      return "en";
    }
  })();
  const money = (amount, currency) => {
    if (typeof amount !== "number" || !Number.isFinite(amount)) return "";
    if (/^[A-Z]{3}$/.test(currency || "")) {
      try {
        return new Intl.NumberFormat(safeLocale, { style: "currency", currency, minimumFractionDigits: 2, maximumFractionDigits: 4 }).format(amount);
      } catch {
      }
    }
    return new Intl.NumberFormat(safeLocale, { minimumFractionDigits: 2, maximumFractionDigits: 4 }).format(amount) + (currency ? ` ${currency}` : "");
  };
  const number = (n) => typeof n === "number" && Number.isFinite(n) ? new Intl.NumberFormat(safeLocale, { maximumFractionDigits: 4 }).format(n) : "";
  const percent = (n) => typeof n === "number" && Number.isFinite(n) ? `${new Intl.NumberFormat(safeLocale, { maximumFractionDigits: 2 }).format(n)} %` : "";
  const date = (iso) => {
    if (!iso) return "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
    const d = /* @__PURE__ */ new Date(`${iso}T12:00:00Z`);
    try {
      return new Intl.DateTimeFormat(safeLocale, { year: "numeric", month: "2-digit", day: "2-digit", timeZone: "UTC" }).format(d);
    } catch {
      return iso;
    }
  };
  return { money, number, percent, date, locale: safeLocale };
}
function groupIban(iban) {
  const v = (iban || "").replace(/\s+/g, "");
  return /^[A-Z]{2}\d{2}[A-Z0-9]+$/i.test(v) ? v.replace(/(.{4})(?=.)/g, "$1 ") : iban || "";
}
function label(t, has2, prefix, code, fallback = code) {
  if (!code) return "";
  const key = `${prefix}.${code}`;
  return has2(key) ? t(key) : fallback;
}
function country(code, locale) {
  if (!code) return "";
  try {
    return new Intl.DisplayNames([locale], { type: "region" }).of(code) || code;
  } catch {
    return code;
  }
}
function partyBlock(p, { t, fmt }) {
  if (!p) return null;
  const a = p.address || {};
  const cityLine = [a.postcode, a.city].filter(Boolean).join(" ");
  const lines2 = [
    p.tradingName && p.tradingName !== p.name ? p.tradingName : "",
    ...a.lines || [],
    cityLine,
    a.region || "",
    a.country ? country(a.country, fmt.locale) : ""
  ].filter(Boolean);
  const details = [];
  if (p.vatId) details.push({ label: t("party.vat_id"), value: p.vatId });
  if (p.taxNumber) details.push({ label: t("party.tax_number"), value: p.taxNumber });
  if (p.legalId) details.push({ label: t("party.register"), value: p.legalId });
  if (p.id) details.push({ label: t("party.id"), value: p.id });
  if (p.contact?.name) details.push({ label: t("party.contact"), value: p.contact.name });
  if (p.contact?.phone) details.push({ label: t("party.phone"), value: p.contact.phone });
  if (p.contact?.email) details.push({ label: t("party.email"), value: p.contact.email });
  if (p.electronicAddress && p.electronicAddress !== p.contact?.email) details.push({ label: t("party.electronic_address"), value: p.electronicAddress });
  return { name: p.name || "", lines: lines2, details };
}
function period(start, end, fmt) {
  if (start && end) return `${fmt.date(start)} – ${fmt.date(end)}`;
  return fmt.date(start || end);
}
function amountDue(inv) {
  const t = inv.totals || {};
  return t.due ?? t.grandTotal ?? null;
}
function documentTitle(inv, t, has2) {
  return label(t, has2, "type", inv.typeCode, inv.isCreditNote ? t("type.381") : t("type.380"));
}
function formatName(inv, source) {
  const syntax = { ubl: "UBL", cii: "CII", zugferd1: "CII" }[inv.syntax] || "";
  const profile = inv.profile?.name || "";
  if (source?.kind === "pdf") {
    if (inv.syntax === "zugferd1") return profile || "ZUGFeRD 1.0";
    if (inv.profile?.family === "xrechnung") return `ZUGFeRD · ${profile}`;
    return profile ? `ZUGFeRD / Factur-X · ${profile}` : "ZUGFeRD / Factur-X";
  }
  if (inv.profile?.family === "xrechnung") return `${profile} (${syntax})`;
  return profile ? `${profile} (${syntax})` : `${syntax} e-invoice`;
}
function present(inv, { t, has: has2, locale, source }) {
  const fmt = createFormat(locale);
  const cur = inv.currency || "";
  const money = (n) => fmt.money(n, cur);
  const facts = [];
  const fact = (key, value) => {
    if (value) facts.push({ label: t(key), value });
  };
  fact("fact.number", inv.number);
  fact("fact.issue_date", fmt.date(inv.issueDate));
  fact("fact.due_date", fmt.date(inv.dueDate));
  fact("fact.delivery_date", fmt.date(inv.deliveryDate));
  fact("fact.period", period(inv.periodStart, inv.periodEnd, fmt));
  fact("fact.buyer_reference", inv.buyerReference);
  fact("fact.order", inv.orderReference);
  fact("fact.sales_order", inv.salesOrderReference);
  fact("fact.contract", inv.contractReference);
  fact("fact.project", inv.projectReference);
  for (const p of inv.precedingInvoices || []) {
    fact("fact.preceding", [p.number, p.date ? fmt.date(p.date) : ""].filter(Boolean).join(", "));
  }
  fact("fact.format", formatName(inv, source));
  const lines2 = (inv.lines || []).map((l, i) => {
    const qty = [fmt.number(l.quantity), label(t, has2, "unit", l.unit)].filter(Boolean).join(" ");
    const details = [
      l.description && l.description !== l.name ? l.description : "",
      l.sellerItemId ? `${t("line.item_number")} ${l.sellerItemId}` : "",
      l.periodStart || l.periodEnd ? period(l.periodStart, l.periodEnd, fmt) : "",
      ...(l.allowancesCharges || []).map((ac) => `${ac.charge ? t("line.charge") : t("line.allowance")}${ac.reason ? ` (${ac.reason})` : ""}: ${money(ac.amount)}`),
      l.note || ""
    ].filter(Boolean);
    return {
      key: `${l.id || ""}-${i}`,
      position: l.id || String(i + 1),
      name: l.name || l.description || "",
      details,
      quantity: qty,
      unitPrice: money(l.unitPrice) + (l.priceBaseQuantity && l.priceBaseQuantity !== 1 ? ` / ${fmt.number(l.priceBaseQuantity)}` : ""),
      vat: l.vatCategory === "S" || l.vatRate ? fmt.percent(l.vatRate ?? 0) : label(t, has2, "vatcat", l.vatCategory),
      net: money(l.netAmount),
      sub: !!l.parentId
    };
  });
  const tt = inv.totals || {};
  const summary = [];
  const row = (key, value, strong = false, vars) => {
    if (typeof value === "number" && Number.isFinite(value)) summary.push({ label: t(key, vars), value: money(value), strong });
  };
  row("total.lines", tt.lineTotal);
  for (const ac of inv.allowancesCharges || []) {
    const name = ac.reason || label(t, has2, ac.charge ? "charge" : "allowance", ac.reasonCode, "");
    summary.push({
      label: `${ac.charge ? t("total.charge") : t("total.allowance")}${name ? `: ${name}` : ""}`,
      value: money(ac.charge ? ac.amount : -(ac.amount || 0))
    });
  }
  row("total.net", tt.taxBasis);
  for (const v of inv.vat || []) {
    const what = v.category === "S" || v.rate && v.category !== "E" ? t("total.vat_rate", { rate: fmt.percent(v.rate ?? 0) }) : `${t("total.vat")} (${label(t, has2, "vatcat", v.category)})`;
    summary.push({ label: what, value: money(v.amount ?? 0) });
  }
  if ((inv.vat || []).length === 0) row("total.vat", tt.taxTotal);
  row("total.gross", tt.grandTotal, tt.due === void 0 || tt.due === tt.grandTotal);
  row("total.prepaid", tt.prepaid ? -tt.prepaid : void 0);
  row("total.rounding", tt.rounding || void 0);
  if (tt.due !== void 0 && tt.due !== tt.grandTotal) row(inv.isCreditNote ? "total.credit" : "total.due", tt.due, true);
  const vatRows = (inv.vat || []).map((v, i) => ({
    key: String(i),
    category: label(t, has2, "vatcat", v.category),
    rate: fmt.percent(v.rate ?? 0),
    basis: money(v.basis),
    amount: money(v.amount),
    reason: v.exemptionReason || (v.exemptionCode ? label(t, has2, "vatex", v.exemptionCode) : "")
  }));
  const payment = [];
  const pay = (key, value) => {
    if (value) payment.push({ label: t(key), value });
  };
  const means = inv.payment?.means || [];
  for (const m of means) {
    pay("pay.means", label(t, has2, "means", m.code, m.text || m.code));
    pay("pay.account_name", m.accountName);
    pay("pay.iban", groupIban(m.iban));
    pay("pay.bic", m.bic);
    pay("pay.debited_iban", groupIban(m.debitedIban));
    pay("pay.card", m.card ? `•••• ${m.card.slice(-4)}` : "");
  }
  pay("pay.reference", inv.payment?.reference);
  pay("pay.mandate", inv.payment?.mandateId);
  pay("pay.creditor_id", inv.payment?.creditorId);
  pay("pay.terms", inv.payment?.terms);
  const attachments = (inv.attachments || []).map((a, i) => ({
    key: String(i),
    name: a.filename || a.id || t("attachment.unnamed"),
    description: a.description || "",
    mimeType: a.mimeType || "",
    size: a.base64 ? Math.floor(a.base64.length * 3 / 4) : 0,
    base64: a.base64 || "",
    uri: a.uri || ""
  }));
  return {
    title: documentTitle(inv, t, has2),
    number: inv.number || "",
    currency: cur,
    due: money(amountDue(inv)),
    facts,
    seller: partyBlock(inv.seller, { t, fmt }),
    buyer: partyBlock(inv.buyer, { t, fmt }),
    payee: inv.payee?.name && inv.payee.name !== inv.seller?.name ? partyBlock(inv.payee, { t, fmt }) : null,
    shipTo: inv.shipTo?.name || inv.shipTo?.address ? partyBlock(inv.shipTo, { t, fmt }) : null,
    lines: lines2,
    summary,
    vatRows,
    payment,
    notes: inv.notes || [],
    attachments,
    noLines: lines2.length === 0
  };
}
function oneLine(inv, { t, has: has2, locale }) {
  const fmt = createFormat(locale);
  const vars = {
    title: documentTitle(inv, t, has2),
    number: inv.number || "",
    seller: inv.seller?.name || "",
    amount: fmt.money(amountDue(inv), inv.currency),
    due: fmt.date(inv.dueDate)
  };
  return t(inv.dueDate && !inv.isCreditNote ? "summary.with_due" : "summary.plain", vars);
}

// e-invoice/src/lib/check.js
var CENT = 0.0101;
var sum = (values) => Math.round(values.reduce((a, b) => a + b, 0) * 100) / 100;
var differs = (a, b) => Math.abs(a - b) > CENT;
var has = (v) => typeof v === "number" && Number.isFinite(v);
function daysBetween(fromIso, toIso) {
  const a = Date.parse(`${fromIso}T00:00:00Z`);
  const b = Date.parse(`${toIso}T00:00:00Z`);
  return Number.isNaN(a) || Number.isNaN(b) ? null : Math.round((b - a) / 864e5);
}
function checkInvoice(inv, { today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) } = {}) {
  const out = [];
  const t = inv.totals || {};
  const add = (id, level, vars = {}) => out.push({ id, level, vars });
  const missing = [];
  if (!inv.number) missing.push("number");
  if (!inv.issueDate) missing.push("issue_date");
  if (!inv.seller?.name) missing.push("seller");
  if (!inv.buyer?.name) missing.push("buyer");
  if (!inv.currency) missing.push("currency");
  if (missing.length) add("missing", "warning", { fields: missing });
  if (inv.seller && !inv.seller.vatId && !inv.seller.taxNumber && !inv.seller.legalId) add("no_tax_id", "warning");
  if (inv.profile?.level === "minimum" || inv.profile?.level === "basicwl") add("not_einvoice_profile", "warning", { profile: inv.profile.name });
  if (inv.profile?.family === "xrechnung" && !inv.buyerReference) add("no_buyer_reference", "warning");
  let sumsChecked = 0;
  let sumsWrong = 0;
  const compare = (id, expected, actual) => {
    if (!has(expected) || !has(actual)) return;
    sumsChecked++;
    if (differs(expected, actual)) {
      sumsWrong++;
      add(id, "warning", { expected, actual, currency: inv.currency || "" });
    }
  };
  const topLines = (inv.lines || []).filter((l) => !l.parentId);
  if (topLines.length && topLines.every((l) => has(l.netAmount))) {
    compare("line_sum", sum(topLines.map((l) => l.netAmount)), t.lineTotal);
  }
  if (has(t.lineTotal)) {
    compare("tax_basis", sum([t.lineTotal, -(t.allowanceTotal || 0), t.chargeTotal || 0]), t.taxBasis);
  }
  const vat = inv.vat || [];
  if (vat.length && vat.every((v) => has(v.amount))) compare("vat_sum", sum(vat.map((v) => v.amount)), t.taxTotal);
  for (const v of vat) {
    if (!has(v.basis) || !has(v.rate) || !has(v.amount)) continue;
    const expected = Math.round(v.basis * v.rate) / 100;
    sumsChecked++;
    if (differs(expected, v.amount)) {
      sumsWrong++;
      add("vat_rate", "warning", { rate: v.rate, expected, actual: v.amount, currency: inv.currency || "" });
    }
  }
  compare("grand_total", sum([t.taxBasis ?? NaN, t.taxTotal || 0]), t.grandTotal);
  const thinProfile = inv.profile?.level === "minimum" || inv.profile?.level === "basicwl";
  if (has(t.grandTotal) && !thinProfile && !inv.profile?.extension) {
    compare("amount_due", sum([t.grandTotal, -(t.prepaid || 0), t.rounding || 0]), t.due);
  }
  if (sumsChecked > 0 && sumsWrong === 0) add("sums_ok", "ok");
  const transfer = (inv.payment?.means || []).some((m) => ["30", "42", "58"].includes(m.code));
  if (transfer && !(inv.payment.means || []).some((m) => m.iban)) add("no_iban", "warning");
  if (inv.isCreditNote) add("credit_note", "info");
  const due = t.due ?? t.grandTotal;
  if (inv.dueDate && has(due) && due > 0 && !inv.isCreditNote) {
    const days = daysBetween(today, inv.dueDate);
    if (days !== null && days < 0) add("overdue", "info", { days: -days });
  }
  return out;
}

// e-invoice/src/lib/forward.js
var FORWARDED_KEY = "forwarded";
var ADDRESS_KEY = "accountingAddress";
var MAX_REMEMBERED = 500;
var EMAIL_RE = /^[^\s@<>()",;:]+@[^\s@<>()",;:]+\.[^\s@<>()",;:]+$/;
function isAddress(value) {
  return EMAIL_RE.test((value || "").trim());
}
function resolveAddress({ config = {}, settings = {}, remembered = "" }) {
  const admin = (config.accountingAddress || "").trim();
  const own = (settings.accountingAddress || "").trim();
  if (admin && config.lockAddress) return admin;
  return [own, admin, remembered].find(isAddress) || "";
}
function messageKey(email) {
  return `${email.accountId || ""}:${email.id}`;
}
async function forwardedInfo(storage, email) {
  const all2 = await storage.get(FORWARDED_KEY).catch(() => null) || {};
  return all2[messageKey(email)] || null;
}
async function recordForward(storage, email, entry) {
  const all2 = await storage.get(FORWARDED_KEY).catch(() => null) || {};
  delete all2[messageKey(email)];
  all2[messageKey(email)] = entry;
  const keys = Object.keys(all2);
  for (const k of keys.slice(0, Math.max(0, keys.length - MAX_REMEMBERED))) delete all2[k];
  await storage.set(FORWARDED_KEY, all2);
}
function forwardNote(inv, { t, has: has2, locale }) {
  const lines2 = [t("forward.note", { summary: oneLine(inv, { t, has: has2, locale }) })];
  if (inv.buyerReference) lines2.push(`${t("fact.buyer_reference")}: ${inv.buyerReference}`);
  if (inv.orderReference) lines2.push(`${t("fact.order")}: ${inv.orderReference}`);
  return lines2.join("\n");
}
function attachmentsFor(source, mode) {
  return mode === "forward.invoice_only" && source?.blobId ? [source.blobId] : void 0;
}
async function askAddress(api) {
  const t = (k, v) => api.i18n.t(k, v);
  for (; ; ) {
    const answer = await api.ui.prompt({
      title: t("ask.title"),
      message: t("ask.message"),
      confirmLabel: t("ask.save"),
      fields: [{ name: "address", label: t("ask.label"), placeholder: "rechnungseingang@example.com", required: true }]
    });
    const address = (answer?.address || "").trim();
    if (!answer) return "";
    if (isAddress(address)) {
      await api.storage.set(ADDRESS_KEY, address).catch(() => {
      });
      return address;
    }
    api.toast.error(t("ask.invalid"));
  }
}
async function currentAddress(api) {
  const config = await Promise.resolve(api.config.get()).catch(() => ({})) || {};
  const remembered = await api.storage.get(ADDRESS_KEY).catch(() => "") || "";
  return resolveAddress({ config, settings: api.plugin.settings || {}, remembered });
}
async function forwardToAccounting(api, { email, invoice, source, quiet = false }) {
  const t = (k, v) => api.i18n.t(k, v);
  const i18n2 = { t, has: (k) => api.i18n.has(k), locale: api.i18n.getLocale() };
  let address = await currentAddress(api);
  if (!address && !quiet) address = await askAddress(api);
  if (!address) return "no-address";
  try {
    const result = await api.email.forward(email.id, {
      to: [address],
      text: forwardNote(invoice, i18n2),
      ...attachmentsFor(source, api.plugin.settings?.forwardWhat) ? { attachments: attachmentsFor(source, api.plugin.settings.forwardWhat) } : {},
      ...email.accountId ? { accountId: email.accountId } : {}
    });
    if (!result?.sent) {
      if (!quiet && result?.reason === "stopped") api.toast.info(t("forward.stopped"));
      return result?.reason === "stopped" ? "stopped" : "declined";
    }
    await recordForward(api.storage, email, { to: address, at: (/* @__PURE__ */ new Date()).toISOString() }).catch(() => {
    });
    if (!quiet) api.toast.success(t("forward.done", { address }));
    return "sent";
  } catch (err) {
    if (!quiet) api.toast.error(t("forward.failed", { error: err?.message || String(err) }));
    return "failed";
  }
}

// e-invoice/src/lib/scan-cache.js
var EINVOICE_KEYWORD = "$einvoice";
var SCANNED_KEY = "scanned";
var MAX = 500;
async function knownNoInvoice(storage, key, attachments) {
  const all2 = await storage.get(SCANNED_KEY).catch(() => null) || {};
  return all2[key] === attachments;
}
async function rememberNoInvoice(storage, key, attachments) {
  const all2 = await storage.get(SCANNED_KEY).catch(() => null) || {};
  delete all2[key];
  all2[key] = attachments;
  const keys = Object.keys(all2);
  for (const k of keys.slice(0, Math.max(0, keys.length - MAX))) delete all2[k];
  await storage.set(SCANNED_KEY, all2).catch(() => {
  });
}

// e-invoice/src/ui/Banner.jsx
var import_jsx_runtime = require("react/jsx-runtime");
function openInvoiceDialog(api, { invoice, source, email }) {
  return api.ui.openDialog({
    title: api.i18n.t("dialog.title"),
    slot: "plugin-dialog",
    width: 880,
    extraProps: { invoice, source, email: email ? { id: email.id, accountId: email.accountId, subject: email.subject } : null }
  });
}
function tagInvoice(api, email) {
  if (api.plugin.settings?.tagMessages === false) return;
  if ((email.keywords || []).includes(EINVOICE_KEYWORD)) return;
  void Promise.resolve(api.email.setKeyword(email.id, EINVOICE_KEYWORD, email.accountId)).catch(() => {
  });
}
function Banner({ email }) {
  const api = getApi();
  const { t, has: has2, locale } = i18n();
  const [found, setFound] = (0, import_react.useState)(null);
  const [forwarded, setForwarded] = (0, import_react.useState)(null);
  const [busy, setBusy] = (0, import_react.useState)(false);
  const attachmentKey = (email?.attachments || []).map((a) => a.blobId).join(",");
  (0, import_react.useEffect)(() => {
    setFound(null);
    setForwarded(null);
    if (!email || candidates(email.attachments).length === 0) return void 0;
    let live = true;
    (async () => {
      if (await knownNoInvoice(api.storage, messageKey(email), attachmentKey)) return;
      const result = await findInvoice(email.attachments, async (blobId) => (await api.email.getAttachment(email.id, blobId, email.accountId)).data);
      if (!live) return;
      if (!result) {
        await rememberNoInvoice(api.storage, messageKey(email), attachmentKey);
        return;
      }
      setFound(result);
      setForwarded(await forwardedInfo(api.storage, email));
      tagInvoice(api, email);
    })().catch(() => {
    });
    return () => {
      live = false;
    };
  }, [email?.id, email?.accountId, attachmentKey]);
  if (!found) return null;
  const { invoice, source } = found;
  const warnings = checkInvoice(invoice).filter((c) => c.level === "warning").length;
  const forward = async () => {
    setBusy(true);
    try {
      if (await forwardToAccounting(api, { email, invoice, source }) === "sent") setForwarded(await forwardedInfo(api.storage, email));
    } finally {
      setBusy(false);
    }
  };
  const show = async () => {
    await openInvoiceDialog(api, { invoice, source, email });
    setForwarded(await forwardedInfo(api.storage, email));
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.InfoBar, { icon: "file-invoice", tone: "info", eyebrow: formatName(invoice, source), title: oneLine(invoice, { t, has: has2, locale }), children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Row, { gap: 2, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.BarButton, { icon: "file-invoice", onClick: () => void show(), children: t("banner.show") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.BarButton, { icon: "mail-forward", busy, onClick: () => void forward(), children: forwarded ? t("banner.forward_again") : t("banner.forward") }),
    forwarded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Text, { tone: "muted", size: "xs", children: t("banner.forwarded", { address: forwarded.to, date: new Date(forwarded.at).toLocaleDateString(locale) }) }),
    warnings > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Badge, { tone: "warning", children: t("banner.warnings", { count: warnings }) })
  ] }) });
}

// e-invoice/src/ui/InvoiceView.jsx
var import_react2 = require("react");
var import_ui2 = require("@plugin-host/ui");

// e-invoice/src/lib/print.js
var esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var lines = (s) => esc(s).replace(/\n/g, "<br>");
var STYLE = `
  .inv { font-size: 10pt; line-height: 1.4; color: #111; }
  .inv h1 { font-size: 16pt; margin: 0 0 2mm; }
  .inv h2 { font-size: 10pt; text-transform: uppercase; letter-spacing: .04em; color: #555; margin: 6mm 0 2mm; }
  .inv .parties { display: flex; gap: 8mm; margin-top: 4mm; }
  .inv .party { flex: 1; }
  .inv .party b { display: block; }
  .inv .muted { color: #555; }
  .inv dl { display: grid; grid-template-columns: 38mm 1fr; gap: 1mm 4mm; margin: 0; }
  .inv dt { color: #555; }
  .inv dd { margin: 0; }
  .inv table { width: 100%; border-collapse: collapse; margin-top: 2mm; }
  .inv th { text-align: start; font-weight: 600; border-bottom: 1px solid #999; padding: 1.5mm 2mm; font-size: 9pt; color: #333; }
  .inv td { padding: 1.5mm 2mm; border-bottom: 1px solid #ddd; vertical-align: top; }
  .inv .num { text-align: end; white-space: nowrap; font-variant-numeric: tabular-nums; }
  .inv .sub td:first-child { padding-inline-start: 6mm; }
  .inv .detail { color: #555; font-size: 9pt; }
  .inv tfoot td, .inv tfoot th { border: 0; padding: 1mm 2mm; font-weight: normal; }
  .inv tfoot .strong th, .inv tfoot .strong td { font-weight: 700; border-top: 1px solid #999; padding-top: 2mm; }
  .inv tr { break-inside: avoid; }
  .inv .footer { margin-top: 8mm; font-size: 8pt; color: #777; }
`;
function party(title, p) {
  if (!p) return "";
  const details = p.details.map((d) => `${esc(d.label)}: ${esc(d.value)}`).join("<br>");
  return `<div class="party"><h2>${esc(title)}</h2><b>${esc(p.name)}</b>${p.lines.map(esc).join("<br>")}${details ? `<div class="muted">${details}</div>` : ""}</div>`;
}
function list(items) {
  return `<dl>${items.map((i) => `<dt>${esc(i.label)}</dt><dd>${lines(i.value)}</dd>`).join("")}</dl>`;
}
function printHtml(p, t, { generatedFrom = "" } = {}) {
  const lineRows = p.lines.map((l) => `<tr class="${l.sub ? "sub" : ""}">
    <td>${esc(l.position)}</td>
    <td>${esc(l.name)}${l.details.length ? `<div class="detail">${l.details.map(lines).join("<br>")}</div>` : ""}</td>
    <td class="num">${esc(l.quantity)}</td>
    <td class="num">${esc(l.unitPrice)}</td>
    <td class="num">${esc(l.vat)}</td>
    <td class="num">${esc(l.net)}</td>
  </tr>`).join("");
  const summary = p.summary.map((s) => `<tr class="${s.strong ? "strong" : ""}"><th colspan="5" class="num">${esc(s.label)}</th><td class="num">${esc(s.value)}</td></tr>`).join("");
  const vat = p.vatRows.length ? `<h2>${esc(t("section.vat"))}</h2><table>
    <thead><tr><th>${esc(t("col.category"))}</th><th class="num">${esc(t("col.rate"))}</th><th class="num">${esc(t("col.basis"))}</th><th class="num">${esc(t("col.vat_amount"))}</th></tr></thead>
    <tbody>${p.vatRows.map((v) => `<tr><td>${esc(v.category)}${v.reason ? `<div class="detail">${esc(v.reason)}</div>` : ""}</td><td class="num">${esc(v.rate)}</td><td class="num">${esc(v.basis)}</td><td class="num">${esc(v.amount)}</td></tr>`).join("")}</tbody>
  </table>` : "";
  return `<style>${STYLE}</style><div class="inv">
  <h1>${esc(p.title)} ${esc(p.number)}</h1>
  <div class="parties">${party(t("section.seller"), p.seller)}${party(t("section.buyer"), p.buyer)}</div>
  ${p.payee || p.shipTo ? `<div class="parties">${party(t("section.payee"), p.payee)}${party(t("section.ship_to"), p.shipTo)}</div>` : ""}
  <h2>${esc(t("section.details"))}</h2>${list(p.facts)}
  <h2>${esc(t("section.items"))}</h2>
  ${p.noLines ? `<p class="muted">${esc(t("items.none"))}</p>` : ""}
  <table>
    ${p.noLines ? "" : `<thead><tr><th>${esc(t("col.pos"))}</th><th>${esc(t("col.item"))}</th><th class="num">${esc(t("col.quantity"))}</th><th class="num">${esc(t("col.unit_price"))}</th><th class="num">${esc(t("col.vat"))}</th><th class="num">${esc(t("col.net"))}</th></tr></thead>
    <tbody>${lineRows}</tbody>`}
    <tfoot>${summary}</tfoot>
  </table>
  ${vat}
  ${p.payment.length ? `<h2>${esc(t("section.payment"))}</h2>${list(p.payment)}` : ""}
  ${p.notes.length ? `<h2>${esc(t("section.notes"))}</h2>${p.notes.map((n) => `<p>${lines(n)}</p>`).join("")}` : ""}
  ${generatedFrom ? `<div class="footer">${esc(generatedFrom)}</div>` : ""}
</div>`;
}

// e-invoice/src/ui/InvoiceView.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var preLine = { whiteSpace: "pre-line" };
function fromBase64(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function Party({ title, party: party2 }) {
  if (!party2) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: title }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { weight: "medium", children: party2.name }),
    party2.lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", children: line }, i)),
    party2.details.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { style: { marginTop: 6 }, children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailList, { children: party2.details.map((d) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailRow, { label: d.label, children: d.value }, d.label)) }) })
  ] });
}
function checkText(t, c, fmt) {
  const vars = { ...c.vars };
  if (Array.isArray(vars.fields)) vars.fields = vars.fields.map((f) => t(`field.${f}`)).join(", ");
  if (typeof vars.expected === "number") vars.expected = fmt(vars.expected, vars.currency);
  if (typeof vars.actual === "number") vars.actual = fmt(vars.actual, vars.currency);
  return t(`check.${c.id}`, vars);
}
function InvoiceView({ invoice, source, email, onResult }) {
  const api = getApi();
  const { t, has: has2, locale } = i18n();
  const p = (0, import_react2.useMemo)(() => present(invoice, { t, has: has2, locale, source }), [invoice, source, locale]);
  const checks = (0, import_react2.useMemo)(() => checkInvoice(invoice), [invoice]);
  const [forwarded, setForwarded] = (0, import_react2.useState)(null);
  const [busy, setBusy] = (0, import_react2.useState)(false);
  const [address, setAddress] = (0, import_react2.useState)("");
  (0, import_react2.useEffect)(() => {
    if (!email) return;
    void forwardedInfo(api.storage, email).then(setForwarded);
    void currentAddress(api).then(setAddress);
  }, [email?.id]);
  const forward = async () => {
    setBusy(true);
    try {
      const outcome = await forwardToAccounting(api, { email, invoice, source });
      if (outcome === "sent") setForwarded(await forwardedInfo(api.storage, email));
      setAddress(await currentAddress(api));
    } finally {
      setBusy(false);
    }
  };
  const print = () => {
    void Promise.resolve(api.ui.print({
      title: `${p.title} ${p.number}`.trim(),
      html: printHtml(p, t, { generatedFrom: t("print.footer", { format: formatName(invoice, source), file: source?.embeddedName || source?.name || "" }) })
    })).catch((err) => api.toast.error(err?.message || String(err)));
  };
  const download = (a) => {
    void Promise.resolve(api.ui.downloadFile({ content: fromBase64(a.base64), filename: a.name, contentType: a.mimeType || "application/octet-stream" })).catch((err) => api.toast.error(t("attachment.download_failed", { error: err?.message || String(err) })));
  };
  const columns = [
    { key: "position", label: t("col.pos"), hideNarrow: true, width: "3rem" },
    { key: "item", label: t("col.item") },
    { key: "quantity", label: t("col.quantity"), align: "end", hideNarrow: true },
    { key: "unitPrice", label: t("col.unit_price"), align: "end", hideNarrow: true },
    { key: "vat", label: t("col.vat"), align: "end", hideNarrow: true },
    { key: "net", label: t("col.net"), align: "end" }
  ];
  const rows = p.lines.map((l) => ({
    key: l.key,
    position: l.position,
    item: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { style: l.sub ? { paddingInlineStart: 16 } : void 0, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: l.name }),
      l.details.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { size: "xs", tone: "muted", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: preLine, children: d }) }, i))
    ] }),
    quantity: l.quantity,
    unitPrice: l.unitPrice,
    vat: l.vat,
    net: l.net
  }));
  const warnings = checks.filter((c) => c.level === "warning");
  const infos = checks.filter((c) => c.level === "info");
  const ok = checks.some((c) => c.level === "ok");
  const fmtMoney = (n, cur) => {
    try {
      return new Intl.NumberFormat(locale, cur ? { style: "currency", currency: cur } : {}).format(n);
    } catch {
      return String(n);
    }
  };
  const buttons = [
    { id: "close", label: t("dialog.close"), variant: "secondary" },
    { id: "print", label: t("dialog.print"), variant: "secondary" },
    ...email ? [{ id: "forward", label: forwarded ? t("dialog.forward_again") : t("dialog.forward"), variant: forwarded ? "secondary" : "primary", disabled: busy }] : []
  ];
  const onButton = (id) => {
    if (id === "close") onResult?.(null);
    else if (id === "print") print();
    else if (id === "forward") void forward();
  };
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Row, { gap: 2, align: "baseline", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Text, { size: "base", weight: "semibold", children: [
          p.title,
          " ",
          p.number
        ] }),
        invoice.isCreditNote && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Badge, { tone: "info", children: t("badge.credit_note") })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Text, { tone: "muted", size: "xs", children: [
        formatName(invoice, source),
        source?.name ? ` · ${source.name}` : ""
      ] })
    ] }),
    (warnings.length > 0 || infos.length > 0 || ok || forwarded) && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 2, children: [
      forwarded && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: "success", icon: "mail-forward", children: t("forward.already", { address: forwarded.to, date: new Date(forwarded.at).toLocaleString(locale) }) }),
      warnings.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: "warning", icon: "alert-triangle", children: checkText(t, c, fmtMoney) }, `w${i}`)),
      infos.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: "info", icon: "info-circle", children: checkText(t, c, fmtMoney) }, `i${i}`)),
      ok && warnings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Text, { tone: "success", size: "xs", children: [
        t("check.sums_ok"),
        " ",
        t("check.not_validation")
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Row, { fill: true, gap: 6, align: "start", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Party, { title: t("section.seller"), party: p.seller }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Party, { title: t("section.buyer"), party: p.buyer })
    ] }),
    (p.payee || p.shipTo) && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Row, { fill: true, gap: 6, align: "start", children: [
      p.payee ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Party, { title: t("section.payee"), party: p.payee }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", {}),
      p.shipTo ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Party, { title: t("section.ship_to"), party: p.shipTo }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", {})
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: t("section.details") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailList, { children: p.facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailRow, { label: f.label, children: f.value }, f.label)) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: t("section.items") }),
      p.noLines && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", size: "xs", children: t("items.none") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Table, { label: t("section.items"), columns, rows, summary: p.summary })
    ] }),
    p.vatRows.length > 1 || p.vatRows.some((v) => v.reason) ? /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: t("section.vat") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        import_ui2.Table,
        {
          label: t("section.vat"),
          columns: [
            { key: "category", label: t("col.category") },
            { key: "rate", label: t("col.rate"), align: "end" },
            { key: "basis", label: t("col.basis"), align: "end" },
            { key: "amount", label: t("col.vat_amount"), align: "end" }
          ],
          rows: p.vatRows.map((v) => ({ ...v, category: v.reason ? /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: v.category }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { size: "xs", tone: "muted", children: v.reason })
          ] }) : v.category }))
        }
      )
    ] }) : null,
    p.payment.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: t("section.payment") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailList, { children: p.payment.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailRow, { label: d.label, mono: d.label === t("pay.iban") || d.label === t("pay.bic"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: preLine, children: d.value }) }, `${d.label}${i}`)) })
    ] }),
    p.notes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: t("section.notes") }),
      p.notes.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: preLine, children: n }) }, i))
    ] }),
    p.attachments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 1, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DetailHeading, { children: t("section.attachments") }),
      p.attachments.map((a) => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Row, { gap: 2, justify: "between", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Text, { truncate: true, children: [
          a.name,
          a.description ? ` · ${a.description}` : ""
        ] }),
        a.base64 ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.LinkButton, { icon: "download", onClick: () => download(a), children: t("attachment.download") }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", size: "xs", children: a.uri })
      ] }, a.key))
    ] }),
    email && address && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", size: "xs", children: t("forward.goes_to", { address }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DialogButtons, { buttons, onClick: onButton })
  ] });
}

// e-invoice/src/lib/background.js
var ACTION_SHOW = "show-invoice";
function createBackground(api, { openDialog, tag }) {
  const t = (key, vars) => api.i18n.t(key, vars);
  let queue = Promise.resolve();
  async function registerUi() {
    await Promise.resolve(api.ui.setActions("attachment-menu", [
      { id: ACTION_SHOW, label: t("action.show"), icon: "file-invoice", mimeTypes: ["application/pdf", "application/xml", "text/xml"] }
    ])).catch(() => {
    });
    const tagging = api.plugin.settings?.tagMessages !== false;
    await Promise.resolve(api.ui.setListFilters(tagging ? [{ id: "einvoices", label: t("filter.label"), icon: "file-invoice", hasKeyword: EINVOICE_KEYWORD }] : [])).catch(() => {
    });
  }
  async function showAttachment({ emailId, blobId, name, type }) {
    if (!kindOf({ name, type })) return;
    const [file, email] = await Promise.all([
      api.email.getAttachment(emailId, blobId),
      Promise.resolve(api.email.get(emailId)).catch(() => null)
    ]);
    const kind = kindOf({ name: file.name, type: file.type });
    const found = invoiceFromBytes(kind, file.data);
    if (!found) {
      api.toast.info(t("action.not_invoice", { name: file.name }));
      return;
    }
    await openDialog({ invoice: found.invoice, source: { blobId, name: file.name, kind, embeddedName: found.embeddedName || "" }, email });
  }
  async function onAction({ surface, actionId, context }) {
    if (surface === "attachment-menu" && actionId === ACTION_SHOW && context?.emailId && context?.blobId) {
      try {
        await showAttachment(context);
      } catch (err) {
        api.toast.error(t("action.failed", { error: err?.message || String(err) }));
      }
    }
  }
  async function lookAtNewEmail(summary) {
    const settings = api.plugin.settings || {};
    const tagging = settings.tagMessages !== false;
    if (!summary?.hasAttachment || !tagging && !settings.autoForward) return;
    const email = await api.email.get(summary.id, summary.accountId);
    if (!email) return;
    const found = await findInvoice(email.attachments, async (blobId) => (await api.email.getAttachment(email.id, blobId, email.accountId)).data);
    if (!found) return;
    if (tagging) tag(email);
    if (settings.autoForward && !await forwardedInfo(api.storage, email)) {
      const outcome = await forwardToAccounting(api, { email, invoice: found.invoice, source: found.source, quiet: true });
      if (outcome === "sent") api.toast.info(t("auto.done", { subject: email.subject || "" }));
    }
  }
  function onNewEmail(summary) {
    queue = queue.then(() => lookAtNewEmail(summary)).catch(() => {
    });
    return queue;
  }
  function badges(current2, { email }) {
    if (!(email?.keywords || []).includes(EINVOICE_KEYWORD)) return void 0;
    return [...current2, { key: "einvoice", label: t("badge.list"), icon: "file-invoice", title: t("badge.list_title") }];
  }
  return { registerUi, onAction, onNewEmail, badges };
}

// e-invoice/src/index.js
var background = null;
async function activate(api) {
  setApi(api);
  background = createBackground(api, {
    openDialog: (props) => openInvoiceDialog(api, props),
    tag: (email) => tagInvoice(api, email)
  });
  await background.registerUi();
  api.i18n.onLocaleChange(() => {
    void background.registerUi();
  });
  api.plugin.onSettingsChange(() => {
    void background.registerUi();
  });
}
var hooks = {
  onAction(event) {
    if (background) void background.onAction(event);
  },
  onNewEmailReceived(email) {
    if (background) void background.onNewEmail(email);
  },
  onEmailListItemRender(badges, context) {
    return background ? background.badges(badges, context) : void 0;
  }
};
var slots = {
  "email-banner": {
    component: Banner,
    // The banner reads the attachments; without any there is nothing to do.
    shouldShow: ({ email }) => !!email && (email.hasAttachment || (email.attachments || []).length > 0)
  },
  "plugin-dialog": { component: InvoiceView }
};
