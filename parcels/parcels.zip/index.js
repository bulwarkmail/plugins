var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// parcels/src/index.js
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var import_plugin_host5 = __toESM(require("@plugin-host"), 1);

// parcels/src/lib/checkdigits.js
var digits = (s) => [...s].map((c) => c.charCodeAt(0) - 48);
function gs1Mod10(number) {
  if (!/^\d{2,}$/.test(number)) return false;
  const body = digits(number.slice(0, -1)).reverse();
  let sum = 0;
  body.forEach((d, i) => {
    sum += d * (i % 2 === 0 ? 3 : 1);
  });
  return (10 - sum % 10) % 10 === Number(number.at(-1));
}
function upsCheck(number) {
  if (!/^1Z[0-9A-Z]{16}$/.test(number)) return false;
  const body = number.slice(2, 17);
  let sum = 0;
  [...body].forEach((c, i) => {
    const v = /\d/.test(c) ? Number(c) : (c.charCodeAt(0) - 63) % 10;
    sum += i % 2 === 1 ? v * 2 : v;
  });
  return (10 - sum % 10) % 10 === Number(number[17]);
}
function s10Check(number) {
  if (!/^[A-Z]{2}\d{9}[A-Z]{2}$/.test(number)) return false;
  const weights = [8, 6, 4, 2, 3, 5, 9, 7];
  const body = digits(number.slice(2, 10));
  const sum = body.reduce((acc, d, i) => acc + d * weights[i], 0);
  let check = 11 - sum % 11;
  if (check === 10) check = 0;
  else if (check === 11) check = 5;
  return check === Number(number[10]);
}
function mod7Check(number) {
  if (!/^\d{10}$/.test(number)) return false;
  return Number(number.slice(0, 9)) % 7 === Number(number[9]);
}
function fedex12Check(number) {
  if (!/^\d{12}$/.test(number)) return false;
  const weights = [1, 3, 7];
  const body = digits(number.slice(0, 11)).reverse();
  const sum = body.reduce((acc, d, i) => acc + d * weights[i % 3], 0);
  return sum % 11 % 10 === Number(number[11]);
}

// parcels/src/lib/carriers/dhl.js
var nospace = (s) => s.replace(/\s+/g, "");
var dhl_default = {
  id: "dhl",
  name: "DHL",
  keywords: /\bDHL\b|Deutsche Post|\bPackstation\b/i,
  // Statuses come from the DHL Unified Tracking API when the admin set it up.
  dhlApi: true,
  formats: [
    // DHL Paket barcode, an SSCC with DHL's GS1 prefix: 20 digits, GS1 check.
    { re: /\b00340\d{15}\b/g, strength: "strong", check: gs1Mod10 },
    // The same, printed in groups of four.
    { re: /\b0034 0\d{3}(?: \d{4}){3}\b/g, strength: "strong", check: gs1Mod10, normalize: nospace },
    // International DHL Paket ("JJD" + 18 digits); no public check digit.
    { re: /\bJJD\d{18}\b/g, strength: "strong" },
    // DHL Parcel UK / Express "JD" + 18 digits.
    { re: /\bJD\d{18}\b/g, strength: "medium" },
    // DHL eCommerce "GM" + 16-18 digits.
    { re: /\bGM\d{16,18}\b/g, strength: "medium" },
    // Deutsche Post / DHL registered mail (UPU S10, country DE).
    { re: /\b[A-Z]{2}\d{9}DE\b/g, strength: "strong", check: s10Check },
    // DHL Express waybill: 10 digits, mod 7.
    { re: /\b\d{10}\b/g, strength: "weak", check: mod7Check },
    // DHL Paket 12-digit number; no published check digit.
    { re: /\b\d{12}\b/g, strength: "weak" }
  ],
  trackingUrl: (n) => `https://www.dhl.com/global-en/home/tracking.html?tracking-id=${encodeURIComponent(n)}&submit=1`
};

// parcels/src/lib/carriers/ups.js
var ups_default = {
  id: "ups",
  name: "UPS",
  // Case-sensitive: "ups" is an English word.
  keywords: /\bUPS\b|ups\.com/,
  formats: [
    { re: /\b1Z[0-9A-Z]{16}\b/g, strength: "strong", check: upsCheck },
    // Printed with spaces, e.g. "1Z 999 AA1 01 2345 678 4".
    { re: /\b1Z(?: ?[0-9A-Z]){16}\b/g, strength: "strong", check: upsCheck, normalize: (s) => s.replace(/\s+/g, "") }
  ],
  trackingUrl: (n) => `https://www.ups.com/track?tracknum=${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/usps.js
var usps_default = {
  id: "usps",
  name: "USPS",
  keywords: /\bUSPS\b|Postal Service/i,
  formats: [
    { re: /\b9[1-5]\d{18,20}\b/g, strength: "medium", check: gs1Mod10 },
    { re: /\b420\d{5}9[1-5]\d{18,20}\b/g, strength: "medium", normalize: (s) => s.slice(8), check: gs1Mod10 },
    { re: /\b[A-Z]{2}\d{9}US\b/g, strength: "strong", check: s10Check }
  ],
  trackingUrl: (n) => `https://tools.usps.com/go/TrackConfirmAction?tLabels=${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/royalmail.js
var royalmail_default = {
  id: "royalmail",
  name: "Royal Mail",
  keywords: /Royal ?Mail/i,
  formats: [
    { re: /\b[A-Z]{2}\d{9}GB\b/g, strength: "strong", check: s10Check }
  ],
  trackingUrl: (n) => `https://www.royalmail.com/track-your-item#/tracking-results/${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/postnl.js
var postnl_default = {
  id: "postnl",
  name: "PostNL",
  keywords: /\bPostNL\b/i,
  formats: [
    { re: /\b3S[A-Z]{4}\d{6,11}\b/g, strength: "strong" },
    { re: /\b[A-Z]{2}\d{9}NL\b/g, strength: "strong", check: s10Check }
  ],
  trackingUrl: (n) => `https://jouw.postnl.nl/track-and-trace/${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/amazon.js
var amazon_default = {
  id: "amazon",
  name: "Amazon",
  keywords: /\bAmazon\b/i,
  formats: [
    { re: /\bTB[ACM]\d{12}\b/g, strength: "strong" }
  ],
  trackingUrl: (n) => `https://track.amazon.com/tracking/${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/fedex.js
var fedex_default = {
  id: "fedex",
  name: "FedEx",
  keywords: /\bFed ?Ex\b/i,
  formats: [
    { re: /\b\d{12}\b/g, strength: "weak", check: fedex12Check },
    { re: /\b\d{15}\b/g, strength: "weak", check: gs1Mod10 }
  ],
  trackingUrl: (n) => `https://www.fedex.com/fedextrack/?trknbr=${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/dpd.js
var dpd_default = {
  id: "dpd",
  name: "DPD",
  keywords: /\bDPD\b/i,
  formats: [
    { re: /\b0\d{13}\b/g, strength: "weak" }
  ],
  trackingUrl: (n) => `https://tracking.dpd.de/status/en_US/parcel/${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/hermes.js
var hermes_default = {
  id: "hermes",
  name: "Hermes",
  keywords: /\bHermes\b|\bEvri\b|myhermes/i,
  formats: [
    // "H" followed by 15-19 digits or capitals (Hermes DE 20-character IDs,
    // Evri 16). At least ten digits in a row, so words in capitals don't match.
    { re: /\bH[0-9A-Z]{15,19}\b/g, strength: "medium", check: (n) => /\d{10}/.test(n) },
    // Hermes DE 14-digit numbers.
    { re: /\b\d{14}\b/g, strength: "weak" }
  ],
  trackingUrl: (n) => `https://www.myhermes.de/empfangen/sendungsverfolgung/sendungsinformation#${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/gls.js
var gls_default = {
  id: "gls",
  name: "GLS",
  keywords: /\bGLS\b/i,
  formats: [
    { re: /\b\d{11,12}\b/g, strength: "weak" }
  ],
  trackingUrl: (n) => `https://gls-group.com/GROUP/en/parcel-tracking?match=${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/post.js
var post_default = {
  id: "post",
  name: "Post",
  keywords: /\bpost\b|registered mail|einschreiben|recommand/i,
  formats: [
    { re: /\b[A-Z]{2}\d{9}(?!DE\b|GB\b|US\b|NL\b)[A-Z]{2}\b/g, strength: "strong", check: s10Check }
  ],
  trackingUrl: (n) => `https://t.17track.net/en#nums=${encodeURIComponent(n)}`
};

// parcels/src/lib/carriers/index.js
var CARRIERS = [dhl_default, ups_default, usps_default, royalmail_default, postnl_default, amazon_default, fedex_default, dpd_default, hermes_default, gls_default, post_default];
var byId = new Map(CARRIERS.map((c) => [c.id, c]));
function carrierByName(name) {
  if (typeof name !== "string" || !name.trim()) return null;
  return CARRIERS.find((c) => c.id !== "post" && c.keywords.test(name)) ?? null;
}

// parcels/src/lib/structured.js
var MAX_HTML = 2e6;
var decodeEntities = (s) => s.replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/&amp;/g, "&");
var isType = (node, type) => {
  const t4 = node?.["@type"];
  const match = (v) => typeof v === "string" && v.replace(/^https?:\/\/schema\.org\//, "") === type;
  return Array.isArray(t4) ? t4.some(match) : match(t4);
};
var nameOf = (v) => {
  if (typeof v === "string") return v;
  if (v && typeof v === "object") return typeof v.name === "string" ? v.name : typeof v.legalName === "string" ? v.legalName : "";
  return "";
};
var cleanNumber = (v) => typeof v === "string" || typeof v === "number" ? String(v).replace(/\s+/g, "").toUpperCase() : "";
var httpUrl = (v) => typeof v === "string" && /^https?:\/\//i.test(v.trim()) ? v.trim() : "";
function collectJsonLd(node, out, depth = 0) {
  if (!node || typeof node !== "object" || depth > 12) return;
  if (Array.isArray(node)) {
    for (const item of node) collectJsonLd(item, out, depth + 1);
    return;
  }
  if (isType(node, "ParcelDelivery") || node.trackingNumber && (node.carrier || node.provider || node.trackingUrl)) {
    const number = cleanNumber(node.trackingNumber);
    if (number) {
      out.push({
        number,
        carrierName: nameOf(node.carrier) || nameOf(node.provider),
        trackingUrl: httpUrl(node.trackingUrl)
      });
    }
  }
  for (const value of Object.values(node)) {
    if (value && typeof value === "object") collectJsonLd(value, out, depth + 1);
  }
}
function fromJsonLd(html, out) {
  const re = /<script\b[^>]*type\s*=\s*["']?application\/ld\+json["']?[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while (m = re.exec(html)) {
    let data;
    try {
      data = JSON.parse(m[1].trim().replace(/^<!--|-->$/g, ""));
    } catch {
      try {
        data = JSON.parse(decodeEntities(m[1].trim()));
      } catch {
        continue;
      }
    }
    collectJsonLd(data, out);
  }
}
function itemprops(fragment, prop) {
  const values = [];
  const re = new RegExp(`<([a-z0-9]+)\\b([^>]*\\bitemprop\\s*=\\s*["']?${prop}["']?[^>]*)>([^<]*)`, "gi");
  let m;
  while (m = re.exec(fragment)) {
    const attrs = m[2];
    const attr = /\b(?:content|href)\s*=\s*"([^"]*)"|\b(?:content|href)\s*=\s*'([^']*)'/i.exec(attrs);
    const raw = attr ? attr[1] ?? attr[2] : m[3];
    values.push(decodeEntities(raw).trim());
  }
  return values;
}
function fromMicrodata(html, out) {
  const re = /itemtype\s*=\s*["']?https?:\/\/schema\.org\/ParcelDelivery["']?/gi;
  let m;
  while (m = re.exec(html)) {
    const rest = html.slice(m.index);
    const next = rest.slice(1).search(/itemtype\s*=\s*["']?https?:\/\/schema\.org\/ParcelDelivery/i);
    const fragment = rest.slice(0, next < 0 ? 2e4 : next + 1);
    const numbers = itemprops(fragment, "trackingNumber").map(cleanNumber).filter(Boolean);
    if (!numbers.length) continue;
    let carrierName = "";
    const carrierAt = fragment.search(/itemprop\s*=\s*["']?(?:carrier|provider)["']?/i);
    if (carrierAt >= 0) {
      const tail = fragment.slice(carrierAt);
      const direct = /itemprop\s*=\s*["']?(?:carrier|provider)["']?[^>]*\bcontent\s*=\s*["']([^"']+)["']/i.exec(tail);
      carrierName = direct ? decodeEntities(direct[1]) : itemprops(tail, "name")[0] ?? "";
    }
    const trackingUrl = httpUrl(itemprops(fragment, "trackingUrl")[0]);
    for (const number of numbers) out.push({ number, carrierName, trackingUrl });
  }
}
function structuredParcels(html) {
  if (typeof html !== "string" || !html) return [];
  const doc = html.length > MAX_HTML ? html.slice(0, MAX_HTML) : html;
  const out = [];
  if (/application\/ld\+json/i.test(doc)) fromJsonLd(doc, out);
  if (/schema\.org\/ParcelDelivery/i.test(doc)) fromMicrodata(doc, out);
  const seen = /* @__PURE__ */ new Set();
  return out.filter((p) => p.number.length >= 6 && p.number.length <= 40 && /^[0-9A-Z-]+$/.test(p.number) && !seen.has(p.number) && seen.add(p.number));
}
function htmlFromSource(source) {
  if (typeof source !== "string") return "";
  const marker = "--- HTML Version ---";
  const at = source.indexOf(marker);
  return at < 0 ? "" : source.slice(at + marker.length);
}

// parcels/src/lib/detect.js
var TRACKING_WORDS = /track|sendung|paket|parcel|package|shipment|shipping|shipped|dispatch|versand|verfolg|lieferung|zustellung|delivery|colis|suivi|livraison|env[ií]o|seguimiento|entrega|spedizion|pacco|tracciamento|consegna|zending|pakket|bezorg|przesy[lł]k|z[aá]silk|waybill|\bawb\b|consignment|barcode/i;
var NEGATIVE_WORDS = /order|bestell|auftrag|invoice|rechnung|customer|kunden|phone|telefon|hotline|\btel\b|\bfax\b|mobil|handy|iban|\bbic\b|konto|account|referen|\bref\b|\bvat\b|\bust\b|steuer|\btax\b|\bzip\b|\bplz\b|postcode|postleitzahl|\bsku\b|article|artikel|ticket|voucher|gutschein|coupon|\bpin\b|\btan\b|commande|pedido|ordine|bestelling|factur|fattura|contract|vertrag|policy|police|mitglied|member|\bbank|card\b|karte|serial|seriennummer|imei|meeting|konferenz|zoom|webex|passcode|kennwort/i;
var RANK = { strong: 3, medium: 2, weak: 1 };
var MAX_RESULTS = 10;
function lastMatchIndex(re, text) {
  const g = new RegExp(re.source, "gi");
  let last = -1;
  let m;
  while (m = g.exec(text)) {
    last = m.index;
    if (m[0].length === 0) g.lastIndex++;
  }
  return last;
}
function labelBefore(before) {
  const cut = Math.max(
    before.lastIndexOf("\n"),
    before.lastIndexOf(". "),
    before.lastIndexOf("|"),
    before.lastIndexOf(";"),
    before.lastIndexOf("•")
  );
  return before.slice(cut + 1).slice(-60);
}
function judge(candidate, haystack, wholeMessage) {
  const { carrier, strength, index, end } = candidate;
  if (strength === "strong") return { ok: true, distance: 0 };
  const before = haystack.slice(Math.max(0, index - 100), index);
  const after = haystack.slice(end, end + 40).split("\n")[0];
  if (/[+#]\s?$/.test(before) || /\d[-/.,]$/.test(before) || /^[-/.,]\d/.test(after)) return { ok: false };
  const label = labelBefore(before);
  const labelTracking = TRACKING_WORDS.test(label);
  const labelNegative = NEGATIVE_WORDS.test(label);
  if (labelNegative && !labelTracking) return { ok: false };
  const trackingAt = lastMatchIndex(TRACKING_WORDS, before);
  const negativeAt = lastMatchIndex(NEGATIVE_WORDS, before);
  if (!labelTracking && negativeAt >= 0 && negativeAt > trackingAt) return { ok: false };
  const trackingBefore = labelTracking || trackingAt >= 0;
  const nearTracking = trackingBefore || TRACKING_WORDS.test(after);
  const carrierAt = lastMatchIndex(carrier.keywords, before);
  const nearby = carrierAt >= 0 || carrier.keywords.test(after);
  const anywhere = nearby || carrier.keywords.test(wholeMessage);
  const distance = carrierAt >= 0 ? before.length - carrierAt : nearby ? 50 : 1e3;
  if (strength === "medium") return { ok: anywhere || nearTracking, distance };
  return { ok: anywhere && trackingBefore, distance };
}
function textCandidates(haystack) {
  const out = [];
  CARRIERS.forEach((carrier, order) => {
    for (const format of carrier.formats) {
      const re = new RegExp(format.re.source, format.re.flags.includes("g") ? format.re.flags : `${format.re.flags}g`);
      let m;
      while (m = re.exec(haystack)) {
        const number = format.normalize ? format.normalize(m[0]) : m[0];
        if (format.check && !format.check(number)) continue;
        out.push({ carrier, number, strength: format.strength, index: m.index, end: m.index + m[0].length, order });
      }
    }
  });
  return out;
}
function identifyNumber(number, { minStrength = "weak" } = {}) {
  const n = String(number || "").replace(/\s+/g, "").toUpperCase();
  let best = null;
  CARRIERS.forEach((carrier, order) => {
    for (const format of carrier.formats) {
      const re = new RegExp(`^(?:${format.re.source.replace(/\\b/g, "")})$`);
      if (RANK[format.strength] < RANK[minStrength] || !re.test(n)) continue;
      const number2 = format.normalize ? format.normalize(n) : n;
      if (format.check && !format.check(number2)) continue;
      const score = RANK[format.strength] * 100 - order;
      if (!best || score > best.score) best = { carrier, number: number2, score };
    }
  });
  return best ? { carrier: best.carrier, number: best.number } : null;
}
function describe(carrier, number, extra = {}) {
  return {
    number,
    carrier: carrier ? carrier.id : "other",
    carrierName: carrier ? carrier.name : extra.carrierName || "",
    trackingUrl: extra.trackingUrl || (carrier ? carrier.trackingUrl(number) : `https://t.17track.net/en#nums=${encodeURIComponent(number)}`),
    source: extra.source || "text"
  };
}
function detectParcels(message) {
  const subject = typeof message?.subject === "string" ? message.subject : "";
  const text = typeof message?.text === "string" ? message.text : "";
  const html = typeof message?.html === "string" ? message.html : htmlFromSource(message?.source);
  const sender = (Array.isArray(message?.from) ? message.from : []).map((a) => `${a?.name ?? ""} ${a?.email ?? ""}`).join(" ");
  const results = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (entry) => {
    if (seen.has(entry.number) || results.length >= MAX_RESULTS) return;
    seen.add(entry.number);
    results.push(entry);
  };
  for (const s of structuredParcels(html)) {
    const known = identifyNumber(s.number);
    const carrier = carrierByName(s.carrierName) ?? known?.carrier ?? null;
    push(describe(carrier, known && known.carrier === carrier ? known.number : s.number, {
      carrierName: s.carrierName,
      trackingUrl: s.trackingUrl,
      source: "schema"
    }));
  }
  const haystack = `${subject}
${text}`;
  const wholeMessage = `${sender}
${haystack}`;
  const accepted = [];
  for (const c of textCandidates(haystack)) {
    const verdict = judge(c, haystack, wholeMessage);
    if (verdict.ok) accepted.push({ ...c, distance: verdict.distance });
  }
  accepted.sort((a, b) => RANK[b.strength] - RANK[a.strength] || a.distance - b.distance || a.order - b.order || a.index - b.index);
  const chosen = /* @__PURE__ */ new Map();
  for (const c of accepted) if (!chosen.has(c.number)) chosen.set(c.number, c);
  [...chosen.values()].sort((a, b) => a.index - b.index).forEach((c) => push(describe(c.carrier, c.number)));
  return results;
}
function onlyCheckedShape(n) {
  const fits = [];
  for (const carrier of CARRIERS) {
    for (const format of carrier.formats) {
      if (format.strength !== "weak") continue;
      if (new RegExp(`^(?:${format.re.source.replace(/\\b/g, "")})$`).test(n)) fits.push({ carrier, format });
    }
  }
  if (fits.length !== 1 || !fits[0].format.check?.(n)) return null;
  return { carrier: fits[0].carrier, number: n };
}
function parcelFromInput(input) {
  const n = String(input || "").replace(/\s+/g, "").toUpperCase();
  if (!/^[0-9A-Z-]{6,40}$/.test(n)) return null;
  const known = identifyNumber(n, { minStrength: "medium" }) ?? onlyCheckedShape(n);
  return describe(known?.carrier ?? null, known?.number ?? n, { source: "manual" });
}

// parcels/src/lib/status.js
var STATUSES = [
  "pending",
  "info_received",
  "in_transit",
  "out_for_delivery",
  "available_for_pickup",
  "delivered",
  "failed",
  "exception",
  "expired",
  "not_found",
  "unknown"
];
var FINAL_STATUSES = /* @__PURE__ */ new Set(["delivered", "expired"]);
var FROM_17TRACK = {
  NotFound: "not_found",
  InfoReceived: "info_received",
  InTransit: "in_transit",
  Expired: "expired",
  AvailableForPickup: "available_for_pickup",
  OutForDelivery: "out_for_delivery",
  DeliveryFailure: "failed",
  Delivered: "delivered",
  Exception: "exception"
};
function from17track(status) {
  return FROM_17TRACK[status] ?? "unknown";
}
function fromDhl(code, text = "") {
  const t4 = String(text || "");
  switch (code) {
    case "pre-transit":
      return "info_received";
    case "transit":
      if (/out.?for.?delivery|zustellfahrzeug|in zustellung|delivery vehicle/i.test(t4)) return "out_for_delivery";
      if (/pick.?up|abholbereit|ready for collection|packstation|filiale/i.test(t4) && /ready|available|bereit|liegt/i.test(t4)) return "available_for_pickup";
      return "in_transit";
    case "delivered":
      return "delivered";
    case "failure":
      return "failed";
    default:
      return "unknown";
  }
}

// parcels/src/lib/parcels.js
var PREFIX = "parcel:";
var POLL_INTERVAL_MS = 30 * 6e4;
var MAX_AGE_MS = 30 * 24 * 36e5;
var MAX_PER_TICK = 20;
var CARD_REFRESH_MS = 5 * 6e4;
var MANUAL_REFRESH_MS = 1e4;
var QUIET = /* @__PURE__ */ new Set(["pending", "unknown", "not_found"]);
async function getParcel(storage, number) {
  const p = await storage.get(PREFIX + number);
  return p && typeof p === "object" && p.number === number ? p : null;
}
async function saveParcel(storage, parcel) {
  await storage.set(PREFIX + parcel.number, parcel);
}
async function listParcels(storage) {
  const keys = (await storage.keys() || []).filter((k) => typeof k === "string" && k.startsWith(PREFIX));
  const out = [];
  for (const key of keys) {
    const p = await storage.get(key);
    if (p && typeof p === "object" && typeof p.number === "string") out.push(p);
  }
  return out;
}
function newParcel(found, { emailId = null, subject = "", now = Date.now() } = {}) {
  return {
    number: found.number,
    carrier: found.carrier,
    carrierName: found.carrierName || "",
    trackingUrl: found.trackingUrl || "",
    emailId,
    subject: String(subject || "").slice(0, 200),
    addedAt: now,
    status: null,
    text: "",
    location: "",
    time: "",
    eta: null,
    events: [],
    lastPolledAt: 0,
    lastChangeAt: 0,
    received: false,
    stopped: false,
    error: null
  };
}
async function rememberParcels(storage, found, meta = {}) {
  const out = [];
  for (const f of found) {
    let p = await getParcel(storage, f.number);
    if (!p) {
      p = newParcel(f, meta);
      await saveParcel(storage, p);
    }
    out.push(p);
  }
  return out;
}
function isDue(p, now, intervalMs = POLL_INTERVAL_MS) {
  if (!p || p.received || p.stopped) return false;
  if (p.status && FINAL_STATUSES.has(p.status)) return false;
  if (now - (p.addedAt || 0) >= MAX_AGE_MS) return false;
  if (p.retryAt && now < p.retryAt) return false;
  return !p.lastPolledAt || now - p.lastPolledAt >= intervalMs;
}
function isTooOld(p, now) {
  return !p.received && !p.stopped && !FINAL_STATUSES.has(p.status) && now - (p.addedAt || 0) >= MAX_AGE_MS;
}
function applyOutcome(p, outcome, now) {
  const next = { ...p, lastPolledAt: now };
  if (outcome?.error) {
    next.error = outcome.error.code || "service";
    if (outcome.error.retryAfter) next.retryAt = now + outcome.error.retryAfter * 1e3;
    return { parcel: next, changed: false };
  }
  const r = outcome?.result;
  if (!r) return { parcel: next, changed: false };
  const previous = p.status;
  next.error = null;
  delete next.retryAt;
  next.status = r.status;
  next.text = r.text || "";
  next.location = r.location || "";
  next.time = r.time || "";
  next.eta = r.eta || null;
  next.events = Array.isArray(r.events) ? r.events.slice(0, 20) : [];
  if (!next.carrierName && r.carrierName) next.carrierName = r.carrierName;
  const changed = previous != null && previous !== r.status && !QUIET.has(r.status);
  if (previous !== r.status) next.lastChangeAt = now;
  return { parcel: next, changed };
}
function claimToken() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
function visibleParcels(list) {
  return list.filter((p) => !p.received).sort((a, b) => Math.max(b.lastChangeAt || 0, b.addedAt || 0) - Math.max(a.lastChangeAt || 0, a.addedAt || 0));
}
async function pollDue(storage, tracker3, { now = Date.now(), onChange, claimDelayMs = 50, intervalMs = POLL_INTERVAL_MS } = {}) {
  const all = await listParcels(storage);
  for (const p of all) {
    if (isTooOld(p, now)) await saveParcel(storage, { ...p, stopped: true });
  }
  const candidates = all.filter((p) => isDue(p, now, intervalMs)).sort((a, b) => (a.lastPolledAt || 0) - (b.lastPolledAt || 0)).slice(0, MAX_PER_TICK);
  if (!candidates.length) return { polled: 0, changed: 0, retryAfter: 0 };
  const token = claimToken();
  for (const p of candidates) {
    const fresh = await getParcel(storage, p.number);
    if (fresh && isDue(fresh, now, intervalMs)) await saveParcel(storage, { ...fresh, lastPolledAt: now, pollClaim: token });
  }
  if (claimDelayMs) await new Promise((r) => setTimeout(r, claimDelayMs));
  const due = [];
  for (const p of candidates) {
    const current = await getParcel(storage, p.number);
    if (current && current.pollClaim === token) due.push(p);
  }
  if (!due.length) return { polled: 0, changed: 0, retryAfter: 0 };
  const outcomes = await tracker3.trackMany(due);
  let changed = 0;
  let retryAfter = 0;
  for (const p of due) {
    const outcome = outcomes.get(p.number);
    if (!outcome) continue;
    if (outcome.error?.retryAfter) retryAfter = Math.max(retryAfter, outcome.error.retryAfter);
    const current = await getParcel(storage, p.number) ?? p;
    if (current.received) continue;
    const { parcel, changed: didChange } = applyOutcome({ ...current, status: p.status }, outcome, now);
    delete parcel.pollClaim;
    await saveParcel(storage, parcel);
    if (didChange) {
      changed++;
      if (onChange) await onChange(parcel, current.status);
    }
  }
  return { polled: due.length, changed, retryAfter };
}

// parcels/src/lib/tracking.js
var DEFAULT_CONFIG = {
  track17Url: "https://api.17track.net/track/v2.2",
  dhlUrl: "https://api-eu.dhl.com/track/shipments"
};
var CONFIG_TTL_MS = 5 * 6e4;
var UNAVAILABLE_MS = 10 * 6e4;
var TRACK17_BATCH = 40;
var MAX_EVENTS = 20;
var TrackingError = class extends Error {
  constructor(code, { retryAfter, detail } = {}) {
    super(detail ? `${code}: ${detail}` : code);
    this.name = "TrackingError";
    this.code = code;
    if (retryAfter) this.retryAfter = retryAfter;
  }
};
function retryAfterOf(res) {
  const raw = res?.headers?.["retry-after"] ?? res?.headers?.["Retry-After"];
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? Math.min(n, 3600) : 60;
}
function errorFromResponse(res) {
  if (!res) return new TrackingError("service");
  if (res.proxyError) {
    switch (res.proxyError) {
      case "no_credential":
        return new TrackingError("not_configured");
      case "rate_limited":
        return new TrackingError("rate_limit", { retryAfter: retryAfterOf(res) });
      case "timeout":
        return new TrackingError("timeout");
      case "unreachable":
        return new TrackingError("unreachable");
      case "blocked_address":
      case "wrong_origin":
      case "redirect_off_origin":
        return new TrackingError("blocked");
      default:
        return new TrackingError("service", { detail: res.proxyError });
    }
  }
  if (res.status === 401 || res.status === 403) return new TrackingError("auth");
  if (res.status === 429) return new TrackingError("rate_limit", { retryAfter: retryAfterOf(res) });
  if (res.status === 408 || res.status === 504) return new TrackingError("timeout");
  if (!res.ok) return new TrackingError("service", { detail: `HTTP ${res.status}` });
  return null;
}
function wrapThrown(err) {
  if (err instanceof TrackingError) return err;
  const msg = String(err?.message ?? err);
  if (/timed out/i.test(msg)) return new TrackingError("timeout");
  if (/network|fetch|reach/i.test(msg)) return new TrackingError("unreachable");
  return new TrackingError("service", { detail: msg.slice(0, 200) });
}
var str = (v) => typeof v === "string" ? v : "";
function normalize17(item) {
  const info = item?.track_info;
  if (!info) return { status: "pending", text: "", location: "", time: "", events: [], eta: null, provider: "17track" };
  const providers = info.tracking?.providers ?? [];
  const events = (providers[0]?.events ?? []).slice(0, MAX_EVENTS).map((e) => ({
    time: str(e.time_iso) || str(e.time_utc),
    text: str(e.description_translation?.description) || str(e.description),
    location: str(e.location),
    status: from17track(e.stage)
  }));
  const latest = info.latest_event;
  const eta = info.time_metrics?.estimated_delivery_date;
  return {
    status: from17track(info.latest_status?.status),
    text: str(latest?.description_translation?.description) || str(latest?.description),
    location: str(latest?.location),
    time: str(latest?.time_iso) || str(latest?.time_utc),
    events,
    eta: eta && (eta.from || eta.to) ? { from: str(eta.from), to: str(eta.to) } : null,
    carrierName: str(providers[0]?.provider?.name),
    provider: "17track"
  };
}
function normalizeDhl(shipment) {
  const s = shipment?.status ?? {};
  const place = (e) => str(e?.location?.address?.addressLocality);
  const events = (shipment?.events ?? []).slice(0, MAX_EVENTS).map((e) => ({
    time: str(e.timestamp),
    text: str(e.description) || str(e.status),
    location: place(e),
    status: fromDhl(e.statusCode, `${str(e.status)} ${str(e.description)}`)
  }));
  const etaTo = str(shipment?.estimatedDeliveryTimeFrame?.estimatedThrough) || str(shipment?.estimatedTimeOfDelivery);
  const etaFrom = str(shipment?.estimatedDeliveryTimeFrame?.estimatedFrom);
  return {
    status: fromDhl(s.statusCode, `${str(s.status)} ${str(s.description)}`),
    text: str(s.description) || str(s.status),
    location: place(s),
    time: str(s.timestamp),
    events,
    eta: etaTo || etaFrom ? { from: etaFrom, to: etaTo } : null,
    carrierName: "DHL",
    provider: "dhl"
  };
}
var NOT_FOUND = (provider) => ({ status: "not_found", text: "", location: "", time: "", events: [], eta: null, provider });
function createTracker(api, { now = () => Date.now() } = {}) {
  let config = null;
  let configAt = 0;
  const unavailable = /* @__PURE__ */ new Map();
  async function getConfig() {
    if (config && now() - configAt < CONFIG_TTL_MS) return config;
    let raw = {};
    try {
      raw = await api.config.get() || {};
    } catch {
      raw = {};
    }
    const url = (v, d) => typeof v === "string" && /^https?:\/\/[^\s]+$/i.test(v.trim()) ? v.trim().replace(/\/+$/, "") : d;
    config = { track17Url: url(raw.track17Url, DEFAULT_CONFIG.track17Url), dhlUrl: url(raw.dhlUrl, DEFAULT_CONFIG.dhlUrl) };
    configAt = now();
    return config;
  }
  const isUnavailable = (provider) => (unavailable.get(provider) ?? 0) > now();
  const markUnavailable = (provider) => unavailable.set(provider, now() + UNAVAILABLE_MS);
  async function dhl(number) {
    const { dhlUrl } = await getConfig();
    const res = await api.proxy.fetch("dhl", `${dhlUrl}?trackingNumber=${encodeURIComponent(number)}`, {
      headers: { Accept: "application/json" },
      responseType: "json"
    });
    if (res && !res.proxyError && res.status === 404) return NOT_FOUND("dhl");
    const err = errorFromResponse(res);
    if (err) throw err;
    const shipment = res.body?.shipments?.[0];
    return shipment ? normalizeDhl(shipment) : NOT_FOUND("dhl");
  }
  async function post17(path, numbers) {
    const { track17Url } = await getConfig();
    const res = await api.proxy.fetch("track17", `${track17Url}/${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(numbers.map((number) => ({ number }))),
      responseType: "json"
    });
    const err = errorFromResponse(res);
    if (err) throw err;
    const body = res.body ?? {};
    if (typeof body.code === "number" && body.code !== 0) {
      const codes = (body.data?.errors ?? []).map((e) => e.code);
      if (body.code === 401 || codes.includes(-18010002) || codes.includes(-18010001)) throw new TrackingError("auth");
      if (codes.includes(-18010012) || codes.includes(-18010013) || codes.includes(-18010014)) throw new TrackingError("quota");
      if (body.code === 429) throw new TrackingError("rate_limit", { retryAfter: 60 });
      throw new TrackingError("service", { detail: `17TRACK code ${body.code}` });
    }
    return { accepted: body.data?.accepted ?? [], rejected: body.data?.rejected ?? [] };
  }
  async function track17(numbers, out) {
    const first = await post17("gettrackinfo", numbers);
    for (const item of first.accepted) out.set(item.number, { result: normalize17(item) });
    const unregistered = [];
    for (const r of first.rejected) {
      if (r.error?.code === -18019902) unregistered.push(r.number);
      else if (r.error?.code === -18019903) out.set(r.number, { error: new TrackingError("unknown_number") });
      else out.set(r.number, { error: new TrackingError("service", { detail: String(r.error?.code ?? "") }) });
    }
    if (!unregistered.length) return;
    const reg = await post17("register", unregistered);
    const ready = new Set(reg.accepted.map((a) => a.number));
    for (const r of reg.rejected) {
      if (r.error?.code === -18019901) ready.add(r.number);
      else if (r.error?.code === -18019903) out.set(r.number, { error: new TrackingError("unknown_number") });
      else out.set(r.number, { error: new TrackingError("service", { detail: String(r.error?.code ?? "") }) });
    }
    if (!ready.size) return;
    const second = await post17("gettrackinfo", [...ready]);
    for (const item of second.accepted) out.set(item.number, { result: normalize17(item) });
    for (const n of ready) if (!out.has(n)) out.set(n, { result: { ...NOT_FOUND("17track"), status: "pending" } });
  }
  async function trackMany(parcels) {
    const out = await trackManyInner(parcels);
    for (const [number, o] of out) {
      if (o.error && o.error.code !== "not_configured") api.log?.warn?.(`parcels: ${number}: ${o.error.message}`);
    }
    return out;
  }
  async function trackManyInner(parcels) {
    const out = /* @__PURE__ */ new Map();
    const via17 = [];
    const fallback = /* @__PURE__ */ new Map();
    for (const p of parcels) {
      if (p.carrier === "dhl" && !isUnavailable("dhl")) {
        try {
          const result = await dhl(p.number);
          if (result.status === "not_found") {
            fallback.set(p.number, result);
            via17.push(p.number);
          } else {
            out.set(p.number, { result });
          }
        } catch (e) {
          const err = wrapThrown(e);
          if (err.code === "not_configured") {
            markUnavailable("dhl");
            via17.push(p.number);
          } else {
            out.set(p.number, { error: err });
          }
        }
      } else {
        via17.push(p.number);
      }
    }
    for (let i = 0; i < via17.length; i += TRACK17_BATCH) {
      const batch = via17.slice(i, i + TRACK17_BATCH);
      if (isUnavailable("track17")) {
        for (const n of batch) out.set(n, fallback.has(n) ? { result: fallback.get(n) } : { error: new TrackingError("not_configured") });
        continue;
      }
      try {
        await track17(batch, out);
      } catch (e) {
        const err = wrapThrown(e);
        if (err.code === "not_configured") markUnavailable("track17");
        for (const n of batch) {
          if (out.has(n)) continue;
          out.set(n, fallback.has(n) && err.code === "not_configured" ? { result: fallback.get(n) } : { error: err });
        }
      }
    }
    return out;
  }
  const inFlight = /* @__PURE__ */ new Map();
  return {
    trackMany,
    track(parcel) {
      const running = inFlight.get(parcel.number);
      if (running) return running;
      const promise = trackMany([parcel]).then((m) => m.get(parcel.number) ?? { error: new TrackingError("service") }).finally(() => inFlight.delete(parcel.number));
      inFlight.set(parcel.number, promise);
      return promise;
    },
    /** Forget the cached admin settings and "not set up" marks (e.g. after a settings change). */
    reset() {
      config = null;
      unavailable.clear();
    }
  };
}

// parcels/src/lib/view.js
var ERROR_CODES = /* @__PURE__ */ new Set([
  "not_configured",
  "auth",
  "rate_limit",
  "quota",
  "timeout",
  "unreachable",
  "blocked",
  "unknown_number",
  "service"
]);
function statusLabel(t4, status) {
  return t4(`status.${STATUSES.includes(status) ? status : "pending"}`);
}
function errorText(t4, code) {
  return t4(`error.${ERROR_CODES.has(code) ? code : "service"}`);
}
function shownStatus(parcel) {
  return parcel.error && !parcel.status ? null : parcel.status || null;
}
function shortStatus(t4, parcel) {
  if (parcel.stopped) return t4("short.stopped");
  const status = shownStatus(parcel);
  if (!status && parcel.error) return t4("short.error");
  return t4(`short.${STATUSES.includes(status) ? status : "pending"}`);
}
var ICONS = {
  pending: "package",
  info_received: "package",
  in_transit: "truck",
  out_for_delivery: "truck-delivery",
  available_for_pickup: "building-store",
  delivered: "circle-check",
  failed: "alert-triangle",
  exception: "alert-triangle",
  expired: "clock",
  not_found: "help-circle",
  unknown: "help-circle"
};
function statusIcon(parcel) {
  const status = shownStatus(parcel);
  if (!status && parcel.error) return "alert-triangle";
  return ICONS[status] ?? "package";
}
function statusBarTone(parcel) {
  const status = shownStatus(parcel);
  if (!status) return parcel.error ? "warning" : "neutral";
  switch (status) {
    case "delivered":
      return "success";
    case "out_for_delivery":
    case "available_for_pickup":
      return "primary";
    case "failed":
    case "exception":
      return "danger";
    case "info_received":
    case "in_transit":
      return "info";
    default:
      return "neutral";
  }
}
function carrierLabel(t4, parcel) {
  return parcel.carrierName || t4("carrier.other");
}
function trackLabel(t4, parcel) {
  return parcel.carrierName ? t4("card.track", { carrier: parcel.carrierName }) : t4("card.trackOnline");
}
function shortNumber(number) {
  const n = String(number || "");
  return n.length > 14 ? `${n.slice(0, 4)}…${n.slice(-4)}` : n;
}
function formatTime(value, locale) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  try {
    return new Intl.DateTimeFormat(locale || "en", { dateStyle: "medium", timeStyle: "short" }).format(d);
  } catch {
    return d.toISOString().slice(0, 16).replace("T", " ");
  }
}
function formatDate(value, locale) {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  try {
    return new Intl.DateTimeFormat(locale || "en", { weekday: "short", day: "numeric", month: "short" }).format(d);
  } catch {
    return d.toISOString().slice(0, 10);
  }
}
function eventLine(parcel, locale) {
  return [parcel.text, parcel.location, formatTime(parcel.time, locale)].filter(Boolean).join(" · ");
}
var oneLine = (s, max) => {
  const flat = String(s || "").replace(/\s+/g, " ").trim();
  return flat.length > max ? `${flat.slice(0, max - 1)}…` : flat;
};
function notificationFor(t4, parcel) {
  const title = oneLine(t4("notify.title", { status: statusLabel(t4, parcel.status) }), 120);
  const what = `${carrierLabel(t4, parcel)} ${parcel.number}`;
  const body = oneLine([what, parcel.subject, parcel.text].filter(Boolean).join(" · "), 300);
  const tag = `parcel-${String(parcel.number).replace(/[^A-Za-z0-9._:-]/g, "").slice(0, 50)}`;
  return { title, body, tag };
}

// parcels/src/lib/background.js
var VISIT_REFRESH_MS = 5 * 6e4;
var HINT_WORDS = /track|sendung|paket|parcel|package|shipment|shipped|versand|lieferung|delivery|colis|envío|envio|spedizion|zending|verzonden|przesyłk|zásilk|\b1Z[0-9A-Z]{6}|\bJJD\d|\b00340\d/i;
function mightContainParcel(summary) {
  const from = (summary?.from ?? []).map((a) => `${a?.name ?? ""} ${a?.email ?? ""}`).join(" ");
  const text = `${summary?.subject ?? ""}
${summary?.preview ?? ""}
${from}`;
  return HINT_WORDS.test(text) || CARRIERS.some((c) => c.id !== "post" && c.keywords.test(text));
}
function createBackground(api, { tracker: tracker3 = createTracker(api), now = () => Date.now() } = {}) {
  let backoffUntil = 0;
  let running = false;
  let lastVisitAt = -Infinity;
  let lastManualAt = -Infinity;
  const setting = (key, fallback) => {
    const v = api.plugin?.settings?.[key];
    return typeof v === "boolean" ? v : fallback;
  };
  async function notifyChange(parcel) {
    if (!setting("notify", true)) return;
    try {
      await api.notifications.show(notificationFor(api.i18n.t.bind(api.i18n), parcel));
    } catch (err) {
      api.log?.warn?.("parcels: notification failed", err);
    }
  }
  async function poll(intervalMs = POLL_INTERVAL_MS) {
    if (running || now() < backoffUntil) return null;
    running = true;
    try {
      const result = await pollDue(api.storage, tracker3, { now: now(), onChange: notifyChange, intervalMs });
      if (result.retryAfter) backoffUntil = now() + result.retryAfter * 1e3;
      return result;
    } catch (err) {
      api.log?.warn?.("parcels: polling failed", err);
      return null;
    } finally {
      running = false;
    }
  }
  const tick = () => poll();
  async function visit() {
    if (now() - lastVisitAt < VISIT_REFRESH_MS || running || now() < backoffUntil) return null;
    lastVisitAt = now();
    return poll(VISIT_REFRESH_MS);
  }
  async function refresh() {
    if (now() - lastManualAt < MANUAL_REFRESH_MS || running || now() < backoffUntil) return null;
    lastManualAt = now();
    return poll(MANUAL_REFRESH_MS);
  }
  async function onNewEmail(summary) {
    if (!setting("trackNewMail", true) || !summary?.id || !mightContainParcel(summary)) return [];
    let mail;
    try {
      mail = await api.email.get(summary.id);
    } catch {
      return [];
    }
    if (!mail) return [];
    const found = detectParcels(mail);
    if (!found.length) return [];
    return rememberParcels(api.storage, found, { emailId: mail.id, subject: mail.subject, now: now() });
  }
  return { tick, visit, refresh, onNewEmail, notifyChange };
}
function bannerShouldShow(context) {
  const email = context?.email;
  if (!email) return false;
  try {
    return detectParcels(email).length > 0;
  } catch {
    return false;
  }
}

// parcels/src/lib/runtime.js
var background;
function getBackground(api) {
  return background ?? (background = createBackground(api));
}

// parcels/src/ui/card.js
var React = __toESM(require("react"), 1);
var import_plugin_host = __toESM(require("@plugin-host"), 1);
var import_ui = require("@plugin-host/ui");
var h = React.createElement;
var tracker = null;
var getTracker = () => tracker ?? (tracker = createTracker(import_plugin_host.default));
var t = (key, vars) => import_plugin_host.default.i18n.t(key, vars);
function ParcelBar({ parcel, busy, onRefresh, onReceived, onOpen }) {
  const locale = import_plugin_host.default.i18n.getLocale();
  const status = shownStatus(parcel);
  const detail = eventLine(parcel, locale);
  const eta = parcel.eta && status !== "delivered" ? formatDate(parcel.eta.to || parcel.eta.from, locale) : "";
  const carrier = carrierLabel(t, parcel);
  const title = status ? h("span", { "data-status": status }, statusLabel(t, status)) : parcel.number;
  const numberLine = [status ? parcel.number : "", eta ? t("card.eta", { date: eta }) : ""].filter(Boolean).join(" · ");
  return h(
    "div",
    { "data-parcel": parcel.number },
    h(
      import_ui.InfoBar,
      { tone: statusBarTone(parcel), icon: statusIcon(parcel), eyebrow: carrier, title },
      detail ? h(import_ui.Text, { tone: "muted" }, detail) : null,
      numberLine ? h(import_ui.Text, { tone: "muted" }, numberLine) : null,
      parcel.stopped ? h(import_ui.Text, { tone: "muted" }, t("widget.stopped")) : null,
      parcel.error ? h("div", { role: "status" }, h(import_ui.Text, { tone: "danger" }, errorText(t, parcel.error))) : null,
      h(
        import_ui.Row,
        { gap: 2 },
        h(import_ui.BarButton, { icon: "external-link", onClick: onOpen }, trackLabel(t, parcel)),
        h(import_ui.BarButton, { icon: "refresh", onClick: onRefresh, busy }, busy ? t("card.refreshing") : status ? t("card.refresh") : t("card.lookup")),
        parcel.received ? h(import_ui.BarButton, { icon: "check", active: true, onClick: () => onReceived(false) }, t("card.received")) : h(import_ui.BarButton, { icon: "check", onClick: () => onReceived(true) }, t("card.markReceived"))
      )
    )
  );
}
function ParcelCard(props) {
  const email = props?.email ?? null;
  const found = React.useMemo(() => email ? detectParcels(email) : [], [email?.id, email?.text, email?.source]);
  const [parcels, setParcels] = React.useState([]);
  const [busy, setBusy] = React.useState({});
  const lastManual = React.useRef({});
  const store = React.useCallback((p) => {
    setParcels((list) => list.map((x) => x.number === p.number ? p : x));
  }, []);
  const refresh = React.useCallback(async (p) => {
    setBusy((b) => ({ ...b, [p.number]: true }));
    try {
      const outcome = await getTracker().track(p);
      const current = await getParcel(import_plugin_host.default.storage, p.number) ?? p;
      const { parcel } = applyOutcome(current, outcome, Date.now());
      await saveParcel(import_plugin_host.default.storage, parcel);
      store(parcel);
    } catch (err) {
      import_plugin_host.default.log.warn("parcels: lookup failed", err);
    } finally {
      setBusy((b) => ({ ...b, [p.number]: false }));
    }
  }, [store]);
  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!found.length) {
        setParcels([]);
        return;
      }
      const stored = await rememberParcels(import_plugin_host.default.storage, found, { emailId: email?.id ?? null, subject: email?.subject ?? "", now: Date.now() });
      if (cancelled) return;
      setParcels(stored);
      const auto = import_plugin_host.default.plugin.settings?.autoLookup !== false;
      if (!auto) return;
      const now = Date.now();
      for (const p of stored) {
        if (p.received || p.stopped || p.status === "delivered") continue;
        if (!p.lastPolledAt || now - p.lastPolledAt > CARD_REFRESH_MS) void refresh(p);
      }
    })().catch((err) => import_plugin_host.default.log.warn("parcels: could not load parcels", err));
    return () => {
      cancelled = true;
    };
  }, [found, refresh]);
  if (!parcels.length) return null;
  const onRefresh = (p) => () => {
    const now = Date.now();
    if (now - (lastManual.current[p.number] ?? 0) < MANUAL_REFRESH_MS) return;
    lastManual.current[p.number] = now;
    void refresh(p);
  };
  const onReceived = (p) => async (received) => {
    const current = await getParcel(import_plugin_host.default.storage, p.number) ?? p;
    const next = { ...current, received };
    await saveParcel(import_plugin_host.default.storage, next);
    store(next);
  };
  const onOpen = (p) => () => {
    void import_plugin_host.default.ui.openExternalUrl(p.trackingUrl);
  };
  return h(
    React.Fragment,
    null,
    parcels.map((p) => h(ParcelBar, {
      key: p.number,
      parcel: p,
      busy: !!busy[p.number],
      onRefresh: onRefresh(p),
      onReceived: onReceived(p),
      onOpen: onOpen(p)
    }))
  );
}

// parcels/src/ui/dialog.js
var React2 = __toESM(require("react"), 1);
var import_plugin_host2 = __toESM(require("@plugin-host"), 1);
var import_ui2 = require("@plugin-host/ui");
var h2 = React2.createElement;
var t2 = (key, vars) => import_plugin_host2.default.i18n.t(key, vars);
function AddDialog({ onResult }) {
  const [input, setInput] = React2.useState("");
  const [error, setError] = React2.useState("");
  const [busy, setBusy] = React2.useState(false);
  const submit = async () => {
    if (busy || !input.trim()) return;
    const found = parcelFromInput(input);
    if (!found) {
      setError(t2("widget.addInvalid"));
      return;
    }
    setBusy(true);
    try {
      const [stored] = await rememberParcels(import_plugin_host2.default.storage, [found], { now: Date.now() });
      if (stored.received) await saveParcel(import_plugin_host2.default.storage, { ...stored, received: false });
      onResult?.({ added: stored.number });
    } catch (err) {
      import_plugin_host2.default.log.warn("parcels: could not add the number", err);
      setBusy(false);
    }
  };
  return h2(
    import_ui2.Stack,
    { gap: 4 },
    h2(
      import_ui2.Field,
      { label: t2("widget.addPlaceholder"), error: error || void 0 },
      h2(import_ui2.Input, {
        value: input,
        maxLength: 40,
        autoFocus: true,
        autoComplete: "off",
        spellCheck: false,
        onChange: (e) => {
          setInput(e.target.value);
          setError("");
        },
        onKeyDown: (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            void submit();
          }
        }
      })
    ),
    h2(import_ui2.DialogButtons, {
      buttons: [
        { id: "cancel", label: t2("dialog.cancel"), variant: "secondary" },
        { id: "add", label: t2("widget.addButton"), variant: "primary", busy, disabled: !input.trim() }
      ],
      onClick: (id) => {
        if (id === "cancel") onResult?.(null);
        else void submit();
      }
    })
  );
}
function ParcelDialog({ number, onResult }) {
  const [parcel, setParcel] = React2.useState(void 0);
  React2.useEffect(() => {
    let cancelled = false;
    getParcel(import_plugin_host2.default.storage, number).then((p) => {
      if (!cancelled) setParcel(p ?? null);
    }).catch((err) => {
      import_plugin_host2.default.log.warn("parcels: could not read the parcel", err);
      if (!cancelled) setParcel(null);
    });
    return () => {
      cancelled = true;
    };
  }, [number]);
  if (parcel === void 0) return h2(import_ui2.Loading);
  if (parcel === null) return h2(import_ui2.Text, { tone: "muted" }, t2("widget.empty"));
  const locale = import_plugin_host2.default.i18n.getLocale();
  const status = shownStatus(parcel);
  const carrier = carrierLabel(t2, parcel);
  const detail = eventLine(parcel, locale);
  const eta = parcel.eta && status !== "delivered" ? formatDate(parcel.eta.to || parcel.eta.from, locale) : "";
  const markReceived = async () => {
    const current = await getParcel(import_plugin_host2.default.storage, parcel.number) ?? parcel;
    await saveParcel(import_plugin_host2.default.storage, { ...current, received: true });
    onResult?.({ received: parcel.number });
  };
  return h2(
    import_ui2.Stack,
    { gap: 4 },
    h2(
      import_ui2.Stack,
      { gap: 1 },
      h2("div", { "data-status": status || "" }, h2(import_ui2.Text, { weight: "medium" }, status ? statusLabel(t2, status) : statusLabel(t2, "pending"))),
      detail ? h2(import_ui2.Text, { tone: "muted" }, detail) : null,
      // Without a subject the dialog's title is already carrier and number.
      parcel.subject ? h2(import_ui2.Text, { tone: "muted" }, `${carrier} ${parcel.number}`) : null,
      eta ? h2(import_ui2.Text, { tone: "muted" }, t2("card.eta", { date: eta })) : null,
      parcel.stopped ? h2(import_ui2.Text, { tone: "muted" }, t2("widget.stopped")) : null
    ),
    parcel.error ? h2(import_ui2.Alert, { tone: "warning", icon: "alert-triangle" }, errorText(t2, parcel.error)) : null,
    h2(import_ui2.DialogButtons, {
      buttons: [
        { id: "received", label: t2("card.markReceived"), variant: "secondary", icon: "check" },
        { id: "track", label: trackLabel(t2, parcel), variant: "primary", icon: "external-link" }
      ],
      onClick: (id) => {
        if (id === "track") void import_plugin_host2.default.ui.openExternalUrl(parcel.trackingUrl);
        else void markReceived();
      }
    })
  );
}
function PluginDialog(props) {
  if (props?.mode === "add") return h2(AddDialog, { onResult: props.onResult });
  if (props?.mode === "parcel" && typeof props.number === "string") return h2(ParcelDialog, { number: props.number, onResult: props.onResult });
  return null;
}

// parcels/src/ui/widget.js
var React3 = __toESM(require("react"), 1);
var import_plugin_host3 = __toESM(require("@plugin-host"), 1);
var import_ui3 = require("@plugin-host/ui");
var h3 = React3.createElement;
var t3 = (key, vars) => import_plugin_host3.default.i18n.t(key, vars);
var RELOAD_MS = 15e3;
var COLLAPSED = 5;
var DIALOG_WIDTH = 440;
var tracker2 = null;
var getTracker2 = () => tracker2 ?? (tracker2 = createTracker(import_plugin_host3.default));
function parcelName(parcel) {
  return parcel.subject || `${carrierLabel(t3, parcel)} ${parcel.number}`;
}
function rowLabels(parcels) {
  const count = /* @__PURE__ */ new Map();
  for (const p of parcels) if (p.subject) count.set(p.subject, (count.get(p.subject) ?? 0) + 1);
  return parcels.map((p) => p.subject && count.get(p.subject) > 1 ? `${carrierLabel(t3, p)} · ${p.subject}` : parcelName(p));
}
function Item({ parcel, label, onOpen }) {
  const carrier = carrierLabel(t3, parcel);
  const status = shownStatus(parcel);
  const tooltip = [parcel.subject, `${carrier} ${shortNumber(parcel.number)}`, status ? statusLabel(t3, status) : ""].filter(Boolean).join("\n");
  return h3(
    "div",
    { "data-parcel": parcel.number, "data-status": status || "" },
    h3(import_ui3.SidebarRow, { icon: statusIcon(parcel), label, detail: shortStatus(t3, parcel), title: tooltip, onClick: onOpen })
  );
}
function DeliveriesWidget() {
  const [parcels, setParcels] = React3.useState(null);
  const [expanded, setExpanded] = React3.useState(false);
  const reload = React3.useCallback(async () => {
    try {
      setParcels(visibleParcels(await listParcels(import_plugin_host3.default.storage)));
    } catch (err) {
      import_plugin_host3.default.log.warn("parcels: could not read parcels", err);
      setParcels([]);
    }
  }, []);
  const refreshAll = React3.useCallback(async () => {
    try {
      await getBackground(import_plugin_host3.default).visit();
    } catch (err) {
      import_plugin_host3.default.log.warn("parcels: could not refresh deliveries", err);
    } finally {
      await reload();
    }
  }, [reload]);
  React3.useEffect(() => {
    void reload();
    void refreshAll();
    const timer = setInterval(() => {
      void reload();
    }, RELOAD_MS);
    const onFocus = () => {
      void refreshAll();
    };
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", onFocus);
    };
  }, [reload, refreshAll]);
  const openParcel = (p) => async () => {
    try {
      await import_plugin_host3.default.ui.openDialog({ title: parcelName(p), slot: "plugin-dialog", extraProps: { mode: "parcel", number: p.number }, width: DIALOG_WIDTH });
    } catch (err) {
      import_plugin_host3.default.log.warn("parcels: could not open the parcel", err);
    }
    await reload();
  };
  const add = async () => {
    let result = null;
    try {
      result = await import_plugin_host3.default.ui.openDialog({ title: t3("widget.add"), slot: "plugin-dialog", extraProps: { mode: "add" }, width: DIALOG_WIDTH });
    } catch (err) {
      import_plugin_host3.default.log.warn("parcels: could not open the add dialog", err);
    }
    await reload();
    const number = result && typeof result.added === "string" ? result.added : null;
    if (!number) return;
    try {
      const stored = await getParcel(import_plugin_host3.default.storage, number);
      if (!stored) return;
      const outcome = await getTracker2().track(stored);
      const current = await getParcel(import_plugin_host3.default.storage, number) ?? stored;
      await saveParcel(import_plugin_host3.default.storage, applyOutcome({ ...current, received: false }, outcome, Date.now()).parcel);
    } catch (err) {
      import_plugin_host3.default.log.warn("parcels: lookup failed", err);
    }
    await reload();
  };
  if (!parcels) return null;
  const shown = expanded ? parcels : parcels.slice(0, COLLAPSED);
  const labels = rowLabels(shown);
  return h3(
    import_ui3.Stack,
    { gap: 0 },
    parcels.length ? null : h3(import_ui3.SidebarEmpty, null, t3("widget.empty")),
    shown.map((p, i) => h3(Item, { key: p.number, parcel: p, label: labels[i], onOpen: openParcel(p) })),
    parcels.length > COLLAPSED ? h3(import_ui3.SidebarRow, {
      icon: "dots",
      label: expanded ? t3("widget.showLess") : t3("widget.showAll", { count: parcels.length }),
      onClick: () => setExpanded(!expanded)
    }) : null,
    h3(import_ui3.SidebarRow, { icon: "plus", label: t3("widget.add"), onClick: () => {
      void add();
    } })
  );
}

// parcels/src/ui/header-actions.js
var React4 = __toESM(require("react"), 1);
var import_plugin_host4 = __toESM(require("@plugin-host"), 1);
var h4 = React4.createElement;
var POLL_UI_MS = 15e3;
function DeliveryHeaderActions() {
  const [busy, setBusy] = React4.useState(false);
  const [lastChecked, setLastChecked] = React4.useState(0);
  const t4 = (key) => import_plugin_host4.default.i18n.t(key);
  const readLastChecked = React4.useCallback(async () => {
    try {
      const parcels = await listParcels(import_plugin_host4.default.storage);
      setLastChecked(Math.max(0, ...parcels.map((p) => p.lastPolledAt || 0)));
    } catch (err) {
      import_plugin_host4.default.log.warn("parcels: could not read latest tracking time", err);
    }
  }, []);
  React4.useEffect(() => {
    void readLastChecked();
    const timer = setInterval(() => {
      void readLastChecked();
    }, POLL_UI_MS);
    return () => clearInterval(timer);
  }, [readLastChecked]);
  const refresh = async () => {
    if (busy) return;
    setBusy(true);
    try {
      await getBackground(import_plugin_host4.default).refresh();
    } catch (err) {
      import_plugin_host4.default.log.warn("parcels: manual refresh failed", err);
    } finally {
      await readLastChecked();
      setBusy(false);
    }
  };
  const label = busy ? t4("card.refreshing") : t4("card.refresh");
  const when = !lastChecked ? "" : typeof import_plugin_host4.default.i18n.formatTime === "function" ? import_plugin_host4.default.i18n.formatTime(lastChecked) : new Date(lastChecked).toLocaleTimeString(import_plugin_host4.default.i18n.getLocale(), { hour: "numeric", minute: "2-digit" });
  return h4(
    "div",
    {
      style: { display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap", color: "inherit" }
    },
    when ? h4("span", { style: { fontSize: 11, opacity: 0.6 }, title: when }, when) : null,
    h4("button", {
      type: "button",
      title: label,
      "aria-label": label,
      "aria-busy": busy,
      disabled: busy,
      onClick: () => {
        void refresh();
      },
      style: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: 25,
        height: 24,
        padding: 3,
        background: "transparent",
        border: "none",
        color: "inherit",
        opacity: busy ? 0.5 : 0.8,
        borderRadius: 5,
        cursor: busy ? "wait" : "pointer"
      }
    }, h4(
      "svg",
      {
        width: 17,
        height: 17,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: 2,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        "aria-hidden": true
      },
      h4("path", { d: "M20 11a8 8 0 0 0-14.6-4.6L3 9" }),
      h4("path", { d: "M3 4v5h5" }),
      h4("path", { d: "M4 13a8 8 0 0 0 14.6 4.6L21 15" }),
      h4("path", { d: "M21 20v-5h-5" })
    ))
  );
}

// parcels/src/index.js
var bg = () => getBackground(import_plugin_host5.default);
function setTitle() {
  Promise.resolve().then(() => import_plugin_host5.default.ui.setSectionTitle(import_plugin_host5.default.i18n.t("widget.title"))).catch((err) => import_plugin_host5.default.log.warn("parcels: could not set the section title", err));
}
var index_default = {
  slots: {
    "email-banner": { component: ParcelCard, shouldShow: bannerShouldShow },
    "sidebar-section": { component: DeliveriesWidget, order: 60 },
    "sidebar-section-actions": { component: DeliveryHeaderActions },
    "plugin-dialog": { component: PluginDialog }
  },
  hooks: {
    // Once a minute; each parcel is asked about at most every 30 minutes.
    onInterval: () => bg().tick(),
    onNewEmailReceived: (summary) => bg().onNewEmail(summary).then(() => void 0)
  },
  activate() {
    setTitle();
    import_plugin_host5.default.i18n.onLocaleChange(setTitle);
    setTimeout(() => {
      void bg().tick();
    }, 5e3);
  }
};
