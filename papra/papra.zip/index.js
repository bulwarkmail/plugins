var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// papra/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var import_react5 = require("react");

// papra/src/lib/errors.js
var PapraError = class extends Error {
  /**
   * @param {string} key  i18n key, e.g. 'error.token'
   * @param {Record<string, string|number>} [vars]
   * @param {number} [status] HTTP status, when there was one
   */
  constructor(key, vars = {}, status = 0) {
    super(key);
    this.name = "PapraError";
    this.key = key;
    this.vars = vars;
    this.status = status;
  }
};
function oneLine(text) {
  const flat = String(text).replace(/\s+/g, " ").trim();
  return flat.length > 200 ? `${flat.slice(0, 197)}...` : flat;
}
function detailOf(body) {
  if (body == null) return "";
  if (typeof body === "string") {
    const text = body.trim();
    if (/^[{[]/.test(text)) {
      try {
        return detailOf(JSON.parse(text));
      } catch {
      }
    }
    if (/^<(!doctype|html)/i.test(text)) return "";
    return oneLine(text);
  }
  if (typeof body === "object") {
    const msg = Array.isArray(body.message) ? body.message.filter((m) => typeof m === "string").join("; ") : body.message;
    if (typeof msg === "string" && msg) return oneLine(msg);
    if (typeof body.error === "string") return oneLine(body.error);
    if (typeof body.error?.message === "string") return oneLine(body.error.message);
  }
  return "";
}
function retryAfter(headers) {
  const seconds = Number(headers?.["retry-after"]);
  return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 0;
}
function errorFromResponse(res) {
  if (res.proxyError) {
    switch (res.proxyError) {
      case "no_credential":
        return new PapraError("error.not_connected", {}, res.status);
      case "rate_limited":
        return new PapraError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, 429);
      case "timeout":
        return new PapraError("error.timeout", {}, 504);
      case "unreachable":
        return new PapraError("error.unreachable", {}, 502);
      case "blocked_address":
        return new PapraError("error.blocked", {}, 403);
      case "too_large":
        return new PapraError("error.too_large", {}, 413);
      case "wrong_origin":
        return new PapraError("error.wrong_server", {}, 403);
      default:
        return new PapraError("error.proxy", { detail: detailOf(res.body) }, res.status);
    }
  }
  const status = res.status;
  const detail = detailOf(res.body);
  if (status === 401) return new PapraError("error.token", {}, status);
  if (status === 403) return new PapraError("error.forbidden", { detail: detail || `HTTP ${status}` }, status);
  if (status === 404) return new PapraError("error.not_found", {}, status);
  if (status === 413) return new PapraError("error.too_large", {}, status);
  if (status === 429) return new PapraError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, status);
  if (status === 502 || status === 503 || status === 504) return new PapraError("error.unavailable", {}, status);
  if (status >= 500) return new PapraError("error.server", {}, status);
  if (status >= 400) return new PapraError("error.rejected", { detail: detail || `HTTP ${status}` }, status);
  return new PapraError("error.unexpected", { detail: `HTTP ${status}` }, status);
}
function toPapraError(err) {
  if (err instanceof PapraError) return err;
  const message = err && typeof err.message === "string" ? err.message : String(err);
  if (/timed out|timeout/i.test(message)) return new PapraError("error.timeout");
  if (/cancel|abort/i.test(message)) return new PapraError("error.cancelled");
  if (/larger than|exceeds/i.test(message)) return new PapraError("error.too_large");
  if (/permission|not allowed|not granted/i.test(message)) return new PapraError("error.permission");
  if (/network|failed to fetch/i.test(message)) return new PapraError("error.unreachable");
  return new PapraError("error.unexpected", { detail: oneLine(message.split(/\r?\n/)[0]) });
}
function errorText(t2, err) {
  const e = toPapraError(err);
  return t2(e.key, e.vars);
}

// papra/src/lib/multipart.js
function quote(value) {
  return String(value).replace(/[\r\n]+/g, " ").replace(/(["\\])/g, "\\$1");
}
function randomBoundary() {
  let out = "----BulwarkPapra";
  for (let i = 0; i < 24; i++) out += Math.floor(Math.random() * 36).toString(36);
  return out;
}
function toBytes(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  return new TextEncoder().encode(String(data));
}
function buildMultipart(fields, boundary = randomBoundary()) {
  const enc = new TextEncoder();
  const chunks = [];
  for (const [name, value] of fields) {
    if (value === void 0 || value === null) continue;
    let head = `--${boundary}\r
Content-Disposition: form-data; name="${quote(name)}"`;
    if (typeof value === "object" && "data" in value) {
      head += `; filename="${quote(value.filename || "file")}"\r
Content-Type: ${value.type || "application/octet-stream"}\r
\r
`;
      chunks.push(enc.encode(head), toBytes(value.data), enc.encode("\r\n"));
    } else {
      head += "\r\n\r\n";
      chunks.push(enc.encode(head), enc.encode(String(value)), enc.encode("\r\n"));
    }
  }
  chunks.push(enc.encode(`--${boundary}--\r
`));
  const size = chunks.reduce((n, c) => n + c.byteLength, 0);
  const body = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    body.set(c, offset);
    offset += c.byteLength;
  }
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

// papra/src/lib/client.js
var PAGE_SIZE = 25;
var ACCEPT = "application/json";
function normalizeBase(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  let text = value.trim();
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = `https://${text}`;
  try {
    const url = new URL(text);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    const path = url.pathname.replace(/\/+$/, "").replace(/\/api$/, "");
    return `${url.origin}${path}`;
  } catch {
    return "";
  }
}
function tagColor(value) {
  return typeof value === "string" && /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(value.trim()) ? value.trim() : "";
}
function toDocument(raw) {
  return {
    id: String(raw?.id || ""),
    name: String(raw?.name || raw?.originalName || "document"),
    type: String(raw?.mimeType || "application/octet-stream"),
    size: Number(raw?.originalSize) || 0,
    createdAt: raw?.createdAt || "",
    tags: (Array.isArray(raw?.tags) ? raw.tags : []).map((tag) => ({ id: String(tag?.id || ""), name: String(tag?.name || ""), color: tagColor(tag?.color) })).filter((tag) => tag.name)
  };
}
function filenameFromDisposition(header) {
  if (typeof header !== "string") return "";
  const star = /filename\*\s*=\s*([^']*)'[^']*'([^;]+)/i.exec(header);
  if (star) {
    try {
      return decodeURIComponent(star[2].trim());
    } catch {
    }
  }
  const plain = /filename\s*=\s*"((?:[^"\\]|\\.)*)"|filename\s*=\s*([^;]+)/i.exec(header);
  if (plain) return (plain[1] ?? plain[2] ?? "").replace(/\\(.)/g, "$1").trim();
  return "";
}
var org = (id) => `/organizations/${encodeURIComponent(id)}`;
function createClient({ proxyFetch, credentialId, base }) {
  if (!base) throw new PapraError("error.not_connected");
  async function request(path, { method = "GET", headers = {}, body, responseType = "json", signal } = {}) {
    const init = { method, headers: { Accept: ACCEPT, ...headers }, responseType };
    if (body !== void 0) init.body = body;
    if (signal) init.signal = signal;
    const res = await proxyFetch(credentialId, `${base}/api${path}`, init);
    if (!res || !res.ok) throw errorFromResponse(res || { status: 0, headers: {} });
    return res;
  }
  async function json(path, opts = {}) {
    const res = await request(path, { ...opts, responseType: "text" });
    const text = typeof res.body === "string" ? res.body : "";
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      throw new PapraError("error.not_papra", {}, res.status);
    }
  }
  return {
    base,
    credentialId,
    request,
    /** The organizations the key's user is in, by name; also checks the connection. */
    async organizations() {
      const data = await json("/organizations");
      if (!data || !Array.isArray(data.organizations)) throw new PapraError("error.not_papra");
      return data.organizations.map((o) => ({ id: String(o?.id || ""), name: String(o?.name || "") })).filter((o) => o.id).sort((a, b) => a.name.localeCompare(b.name));
    },
    /**
     * One page of an organization's documents, newest first, or those
     * matching `text` (Papra's own search over names and content).
     * @returns {Promise<{ items: ReturnType<typeof toDocument>[], count: number, hasMore: boolean }>}
     */
    async documents(organizationId, { text = "", pageIndex = 0 } = {}) {
      const q = new URLSearchParams();
      if (text.trim()) q.set("searchQuery", text.trim());
      q.set("pageIndex", String(pageIndex));
      q.set("pageSize", String(PAGE_SIZE));
      const data = await json(`${org(organizationId)}/documents?${q}`);
      const items = (Array.isArray(data?.documents) ? data.documents : []).map(toDocument).filter((d) => d.id);
      const count = Number(data?.documentsCount) || items.length;
      return { items, count, hasMore: (pageIndex + 1) * PAGE_SIZE < count };
    },
    /** The original file. Papra sends every file as octet-stream; the type comes from the document. */
    async download(organizationId, doc, signal) {
      const res = await request(`${org(organizationId)}/documents/${encodeURIComponent(doc.id)}/file`, { responseType: "arraybuffer", signal, headers: { Accept: "*/*" } });
      const header = (res.headers?.["content-type"] || "").split(";")[0].trim();
      const type = doc.type && doc.type !== "application/octet-stream" ? doc.type : header || "application/octet-stream";
      return { data: res.body, type, name: filenameFromDisposition(res.headers?.["content-disposition"]) || doc.name };
    },
    /**
     * Add a file to an organization. Resolves to the new document's { id, name }.
     * @param {{ data: Uint8Array|ArrayBuffer, name: string, type?: string }} file
     */
    async upload(organizationId, file, { signal } = {}) {
      const { body, contentType } = buildMultipart([["file", { filename: file.name, type: file.type, data: file.data }]]);
      const data = await json(`${org(organizationId)}/documents`, { method: "POST", headers: { "Content-Type": contentType }, body, signal });
      const doc = data?.document;
      if (!doc?.id) throw new PapraError("error.unexpected", { detail: "no document id" });
      return { id: String(doc.id), name: String(doc.name || file.name) };
    },
    /** The document's page in Papra's web app. */
    documentUrl(organizationId, id) {
      return `${base}${org(organizationId)}/documents/${encodeURIComponent(id)}`;
    }
  };
}

// papra/src/lib/connection.js
var PERSONAL = "personal";
var ORGANIZATION_KEY = "organization";
async function adminServer(api) {
  try {
    return normalizeBase(await api.admin.getConfig("serverUrl"));
  } catch {
    return "";
  }
}
async function resolveConnection(api) {
  const configured = await adminServer(api);
  let accounts = [];
  try {
    accounts = await api.proxy.accounts() || [];
  } catch {
    accounts = [];
  }
  const mine = accounts.find((a) => a && a.credentialId === PERSONAL && a.connected);
  if (mine) {
    const base = configured && new URL(configured).origin === mine.origin ? configured : normalizeBase(mine.origin);
    return { state: "connected", base, credentialId: PERSONAL };
  }
  return { state: "disconnected", suggestedServer: configured };
}
function clientFor(api, connection) {
  if (!connection || connection.state !== "connected") throw new PapraError("error.not_connected");
  return createClient({ proxyFetch: (...a) => api.proxy.fetch(...a), credentialId: connection.credentialId, base: connection.base });
}
async function connectPersonal(api, suggestedServer) {
  const result = await api.proxy.connect(PERSONAL, { mode: "password", ...suggestedServer ? { server: suggestedServer } : {} });
  if (!result?.connected) return { connected: false };
  const connection = await resolveConnection(api);
  if (connection.state !== "connected") return { connected: false };
  try {
    await clientFor(api, connection).organizations();
  } catch (err) {
    const e = toPapraError(err);
    if (e.key === "error.token" || e.key === "error.not_papra") await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    return { connected: false, error: e };
  }
  return { connected: true, connection };
}
function chooseOrganization(organizations, stored) {
  if (!organizations.length) return "";
  return organizations.some((o) => o.id === stored) ? stored : organizations[0].id;
}
async function storedOrganization(api) {
  try {
    const value = await api.storage.get(ORGANIZATION_KEY);
    return typeof value === "string" ? value : "";
  } catch {
    return "";
  }
}
async function rememberOrganization(api, id) {
  try {
    await api.storage.set(ORGANIZATION_KEY, id, { sync: true });
  } catch {
  }
}

// papra/src/lib/documents.js
var MAX_ATTACH_BYTES = 25 * 1024 * 1024;
async function attachDocuments(api, client, organizationId, composerId, docs, { onProgress, onAttached, signal } = {}) {
  let attached = 0;
  for (let i = 0; i < docs.length; i++) {
    const doc = docs[i];
    if (signal?.aborted) throw new PapraError("error.cancelled");
    onProgress?.(i, docs.length);
    if (doc.size > MAX_ATTACH_BYTES) throw new PapraError("error.attach_too_large", { name: doc.name });
    const file = await client.download(organizationId, doc, signal);
    const size = file.data?.byteLength ?? 0;
    if (size > MAX_ATTACH_BYTES) throw new PapraError("error.attach_too_large", { name: file.name });
    const blob = await api.jmap.uploadBlob(new Uint8Array(file.data), file.name, file.type);
    const ok = await api.composer.attach(composerId, { blobId: blob.blobId, name: file.name, type: blob.type || file.type, size: blob.size ?? size });
    if (ok === false) throw new PapraError("error.attach_refused", { name: file.name });
    attached++;
    onAttached?.(doc);
  }
  return attached;
}
function emlName(subject) {
  const base = String(subject || "").replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
  return `${base || "message"}.eml`;
}
async function readForSaving(api, { kind, emailId, blobId, name, type }) {
  if (kind === "message") {
    const [view, raw] = await Promise.all([api.email.get(emailId).catch(() => null), api.email.getRaw(emailId)]);
    return { name: emlName(view?.subject), type: "message/rfc822", data: raw };
  }
  const file = await api.email.getAttachment(emailId, blobId);
  return { name: file?.name || name || "attachment", type: file?.type || type || "application/octet-stream", data: file.data };
}

// papra/src/lib/background.js
var ACTION_ATTACH = "from-papra";
var ACTION_SAVE_ATTACHMENT = "save-attachment";
var ACTION_SAVE_MESSAGE = "save-message";
function createBackground(api) {
  const t2 = (key, vars) => api.i18n.t(key, vars);
  async function ensureConnection() {
    const connection = await resolveConnection(api);
    if (connection.state === "connected") return connection;
    const go = await api.ui.confirm({ title: t2("connect.title"), message: t2("connect.needed"), confirmLabel: t2("connect.button"), cancelLabel: t2("common.cancel") });
    if (!go) return null;
    const result = await connectPersonal(api, connection.suggestedServer);
    if (!result.connected) {
      if (result.error) throw result.error;
      return null;
    }
    return result.connection;
  }
  async function attachFromPapra(composerId) {
    const result = await api.ui.openDialog({
      title: t2("picker.title"),
      slot: "plugin-dialog",
      extraProps: { view: "picker", composerId },
      width: 820
    });
    const attached = Number(result?.attached) || 0;
    if (attached) api.toast.success(t2("picker.attached", { count: attached }));
    return attached;
  }
  async function save(item) {
    try {
      const connection = await ensureConnection();
      if (!connection) return null;
      const client = clientFor(api, connection);
      const organizations = await client.organizations();
      if (!organizations.length) throw new PapraError("error.no_organization");
      let organizationId = chooseOrganization(organizations, await storedOrganization(api));
      if (organizations.length > 1) {
        const choice = await api.ui.openDialog({
          title: t2("save.action"),
          slot: "plugin-dialog",
          extraProps: { view: "save", kind: item.kind, name: item.name || "", organizations, organizationId },
          width: 480
        });
        if (!choice || !organizations.some((o) => o.id === choice.organizationId)) return null;
        organizationId = choice.organizationId;
        await rememberOrganization(api, organizationId);
      }
      const file = await readForSaving(api, item);
      const doc = await client.upload(organizationId, file);
      api.toast.success(t2("save.done", { name: doc.name }));
      return { organizationId, ...doc };
    } catch (err) {
      api.toast.error(errorText(t2, err));
      return null;
    }
  }
  function onAction({ actionId, context } = {}) {
    const ctx = context || {};
    if (actionId === ACTION_ATTACH && typeof ctx.composerId === "string" && ctx.composerId) return attachFromPapra(ctx.composerId);
    if (actionId === ACTION_SAVE_ATTACHMENT && ctx.emailId && ctx.blobId) {
      return save({ kind: "attachment", emailId: ctx.emailId, blobId: ctx.blobId, name: ctx.name, type: ctx.type });
    }
    if (actionId === ACTION_SAVE_MESSAGE && ctx.emailId) return save({ kind: "message", emailId: ctx.emailId });
    return null;
  }
  async function registerUi() {
    const calls = [
      api.ui.setActions("composer-attach-menu", [{ id: ACTION_ATTACH, label: t2("composer.attach_menu"), icon: "folder" }]),
      api.ui.setActions("attachment-menu", [{ id: ACTION_SAVE_ATTACHMENT, label: t2("save.action"), icon: "cloud-upload" }]),
      api.ui.setActions("reader-actions", [{ id: ACTION_SAVE_MESSAGE, label: t2("save.message_action"), icon: "cloud-upload", order: 210 }])
    ];
    await Promise.all(calls.map((p) => Promise.resolve(p).catch((err) => api.log?.warn?.("setup failed", err?.message))));
  }
  return { onAction, registerUi, save, attachFromPapra };
}

// papra/src/ui/host.js
var current = null;
function setApi(api) {
  current = api;
}
function getApi() {
  if (current) return current;
  current = require("@plugin-host");
  return current;
}
function t(key, vars) {
  return getApi().i18n.t(key, vars);
}
function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return String(url || "");
  }
}
function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  try {
    return d.toLocaleDateString(getApi().i18n.getLocale(), { year: "numeric", month: "short", day: "numeric" });
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

// papra/src/ui/Picker.jsx
var import_react2 = require("react");
var import_ui2 = require("@plugin-host/ui");

// papra/src/ui/common.jsx
var import_react = require("react");
var import_ui = require("@plugin-host/ui");
var import_jsx_runtime = require("react/jsx-runtime");
function useConnection() {
  const [connection, setConnection] = (0, import_react.useState)(null);
  const [loading, setLoading] = (0, import_react.useState)(true);
  const refresh = (0, import_react.useCallback)(async () => {
    setLoading(true);
    try {
      setConnection(await resolveConnection(getApi()));
    } finally {
      setLoading(false);
    }
  }, []);
  (0, import_react.useEffect)(() => {
    void refresh();
  }, [refresh]);
  const client = (0, import_react.useMemo)(() => connection?.state === "connected" ? clientFor(getApi(), connection) : null, [connection]);
  return { connection, client, loading, refresh };
}
function ErrorAlert({ error, onRetry }) {
  if (!error) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Alert, { tone: "danger", icon: "alert-circle", action: onRetry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.LinkButton, { onClick: onRetry, children: t("common.retry") }) : null, children: errorText(t, error) });
}
function useConnect(connection, onConnected) {
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [error, setError] = (0, import_react.useState)(null);
  const connect = async () => {
    setBusy(true);
    setError(null);
    try {
      const result = await connectPersonal(getApi(), connection?.suggestedServer || "");
      if (result.connected) onConnected?.(result.connection);
      else if (result.error) setError(result.error);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  return { busy, error, connect };
}
function connectIntro(connection) {
  const intro = connection?.suggestedServer ? t("connect.intro_server", { host: hostOf(connection.suggestedServer) }) : t("connect.intro");
  return `${intro} ${t("connect.key_hint")}`;
}
function ConnectEmptyState({ connection, onConnected }) {
  const { busy, error, connect } = useConnect(connection, onConnected);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      import_ui.EmptyState,
      {
        icon: "folder",
        title: t("connect.title"),
        description: connectIntro(connection),
        actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Button, { busy, onClick: connect, children: t("connect.button") })
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorAlert, { error })
  ] });
}

// papra/src/ui/Picker.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var SEARCH_DELAY_MS = 300;
function Tags({ tags }) {
  if (!tags.length) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: { display: "inline-flex", flexWrap: "wrap", gap: 8 }, children: tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { style: { display: "inline-flex", alignItems: "center", gap: 4 }, children: [
    tag.color && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.ColorDot, { color: tag.color }),
    tag.name
  ] }, tag.id || tag.name)) });
}
function OrganizationPicker({ organizations, value, onChange }) {
  if (organizations.length < 2) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Field, { label: t("settings.organization"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Select, { value, onChange: (v) => onChange(v), options: organizations.map((o) => ({ value: o.id, label: o.name })) }) });
}
function Picker({ composerId, onClose }) {
  const { connection, client, loading, refresh } = useConnection();
  const [organizations, setOrganizations] = (0, import_react2.useState)(null);
  const [organizationId, setOrganizationId] = (0, import_react2.useState)("");
  const [text, setText] = (0, import_react2.useState)("");
  const [items, setItems] = (0, import_react2.useState)([]);
  const [count, setCount] = (0, import_react2.useState)(0);
  const [pageIndex, setPageIndex] = (0, import_react2.useState)(0);
  const [hasMore, setHasMore] = (0, import_react2.useState)(false);
  const [searching, setSearching] = (0, import_react2.useState)(false);
  const [searched, setSearched] = (0, import_react2.useState)(false);
  const [error, setError] = (0, import_react2.useState)(null);
  const [picked, setPicked] = (0, import_react2.useState)(() => /* @__PURE__ */ new Map());
  const [busy, setBusy] = (0, import_react2.useState)("");
  const attachedCount = (0, import_react2.useRef)(0);
  const abortRef = (0, import_react2.useRef)(null);
  const api = getApi();
  (0, import_react2.useEffect)(() => {
    if (!client) return;
    (async () => {
      try {
        const list = await client.organizations();
        setOrganizations(list);
        setOrganizationId(chooseOrganization(list, await storedOrganization(api)));
      } catch (err) {
        setOrganizations([]);
        setError(err);
      }
    })();
  }, [client]);
  const seq = (0, import_react2.useRef)(0);
  const run = (0, import_react2.useCallback)(async (index, q, orgId) => {
    if (!client || !orgId) return;
    const mine = ++seq.current;
    setSearching(true);
    setError(null);
    try {
      const res = await client.documents(orgId, { text: q, pageIndex: index });
      if (mine !== seq.current) return;
      setItems((prev) => index === 0 ? res.items : [...prev, ...res.items]);
      setCount(res.count);
      setHasMore(res.hasMore);
      setPageIndex(index);
      setSearched(true);
    } catch (err) {
      if (mine === seq.current) setError(err);
    } finally {
      if (mine === seq.current) setSearching(false);
    }
  }, [client]);
  const shownOrganization = (0, import_react2.useRef)("");
  (0, import_react2.useEffect)(() => {
    if (!client || !organizationId) return void 0;
    const typed = searched && shownOrganization.current === organizationId;
    shownOrganization.current = organizationId;
    const timer = setTimeout(() => {
      void run(0, text, organizationId);
    }, typed ? SEARCH_DELAY_MS : 0);
    return () => clearTimeout(timer);
  }, [client, text, organizationId]);
  const close = () => onClose?.(attachedCount.current);
  const toggle = (doc) => setPicked((prev) => {
    const next = new Map(prev);
    if (next.has(doc.id)) next.delete(doc.id);
    else next.set(doc.id, doc);
    return next;
  });
  const switchOrganization = (id) => {
    setOrganizationId(id);
    setPicked(/* @__PURE__ */ new Map());
    void rememberOrganization(api, id);
  };
  const attach = async () => {
    const docs = [...picked.values()];
    if (!docs.length) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setError(null);
    setBusy(t("picker.attaching", { current: 1, total: docs.length }));
    try {
      await attachDocuments(api, client, organizationId, composerId, docs, {
        signal: controller.signal,
        onProgress: (i, n) => setBusy(t("picker.attaching", { current: i + 1, total: n })),
        // What is in the message leaves the selection, so trying again doesn't attach it twice.
        onAttached: (doc) => {
          attachedCount.current++;
          setPicked((prev) => {
            const next = new Map(prev);
            next.delete(doc.id);
            return next;
          });
        }
      });
      close();
    } catch (err) {
      if (err?.key !== "error.cancelled") setError(err);
    } finally {
      abortRef.current = null;
      setBusy("");
    }
  };
  if (loading) return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Loading, { label: t("common.loading") });
  if (connection?.state !== "connected") return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ConnectEmptyState, { connection, onConnected: () => refresh() });
  if (!organizations) return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Loading, { label: t("common.loading") });
  if (!organizations.length && !error) return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.EmptyState, { icon: "folder", title: t("error.no_organization") });
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(OrganizationPicker, { organizations, value: organizationId, onChange: switchOrganization }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { role: "search", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.SearchInput, { value: text, onChange: setText, label: t("picker.search_label"), placeholder: t("picker.search_placeholder") }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ErrorAlert, { error }),
    busy && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Spinner, { label: busy }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { "aria-live": "polite", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { tone: "muted", size: "xs", children: searching ? t("picker.searching") : picked.size > 0 ? `${t("picker.count", { count })} · ${t("picker.selected", { count: picked.size })}` : t("picker.count", { count }) }) }),
    searched && items.length === 0 && !searching && !error && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.EmptyState, { compact: true, icon: "file-search", title: t("picker.none") }),
    items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.List, { label: t("picker.results"), children: items.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      import_ui2.ListRow,
      {
        icon: doc.name,
        title: doc.name,
        subtitle: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Tags, { tags: doc.tags }),
        meta: [formatDate(doc.createdAt)],
        checked: picked.has(doc.id),
        onCheck: () => toggle(doc),
        onClick: () => toggle(doc),
        actions: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.RowAction, { icon: "external-link", label: t("picker.open"), onClick: () => {
          void api.ui.openExternalUrl(client.documentUrl(organizationId, doc.id));
        } })
      },
      doc.id
    )) }),
    hasMore && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Row, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Button, { variant: "secondary", busy: searching, onClick: () => run(pageIndex + 1, text, organizationId), children: t("picker.more") }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      import_ui2.DialogButtons,
      {
        buttons: [
          { id: "cancel", label: t("common.cancel"), variant: "secondary" },
          { id: "attach", label: picked.size ? t("picker.attach_count", { count: picked.size }) : t("picker.attach"), variant: "primary", disabled: picked.size === 0, busy: !!busy }
        ],
        onClick: (id) => {
          if (id === "cancel") {
            if (abortRef.current) abortRef.current.abort();
            else close();
          } else if (id === "attach") void attach();
        }
      }
    )
  ] });
}

// papra/src/ui/SaveDialog.jsx
var import_react3 = require("react");
var import_ui3 = require("@plugin-host/ui");
var import_jsx_runtime3 = require("react/jsx-runtime");
function SaveDialog({ kind, name, organizations = [], organizationId, onResult }) {
  const [value, setValue] = (0, import_react3.useState)(organizationId || organizations[0]?.id || "");
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_ui3.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Text, { children: kind === "message" ? t("save.intro_message") : t("save.intro_attachment", { name }) }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(OrganizationPicker, { organizations, value, onChange: setValue }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      import_ui3.DialogButtons,
      {
        buttons: [
          { id: "cancel", label: t("common.cancel"), variant: "secondary" },
          { id: "save", label: t("save.button"), variant: "primary", disabled: !value }
        ],
        onClick: (id) => onResult?.(id === "save" ? { organizationId: value } : null)
      }
    )
  ] });
}

// papra/src/ui/Settings.jsx
var import_react4 = require("react");
var import_ui4 = require("@plugin-host/ui");
var import_jsx_runtime4 = require("react/jsx-runtime");
function Settings() {
  const { connection, client, loading, refresh } = useConnection();
  const { busy, error: connectError, connect } = useConnect(connection, () => refresh());
  const [organizations, setOrganizations] = (0, import_react4.useState)([]);
  const [organizationId, setOrganizationId] = (0, import_react4.useState)("");
  const [error, setError] = (0, import_react4.useState)(null);
  const api = getApi();
  (0, import_react4.useEffect)(() => {
    if (!client) return;
    (async () => {
      try {
        const list = await client.organizations();
        setOrganizations(list);
        setOrganizationId(chooseOrganization(list, await storedOrganization(api)));
      } catch (err) {
        setError(err);
      }
    })();
  }, [client]);
  const disconnect = async () => {
    await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    setOrganizations([]);
    setError(null);
    await refresh();
  };
  const pick = (id) => {
    setOrganizationId(id);
    void rememberOrganization(api, id);
  };
  const host = connection?.base ? hostOf(connection.base) : "";
  const intro = t("settings.intro", { attach: t("composer.attach_menu"), save: t("save.action"), message: t("save.message_action") });
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Stack, { gap: 6, children: /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_ui4.Section, { title: t("settings.title"), description: intro, children: [
    loading && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Loading, {}),
    !loading && connection?.state === "disconnected" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.SettingRow, { label: t("settings.connection"), description: connectIntro(connection), children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Button, { busy, onClick: connect, children: t("connect.button") }) }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ErrorAlert, { error: connectError })
    ] }),
    !loading && connection?.state === "connected" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.SettingRow, { label: t("settings.connection"), description: t("settings.connected", { host }), children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Button, { variant: "secondary", onClick: disconnect, children: t("settings.disconnect") }) }),
      organizations.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.SettingRow, { label: t("settings.organization"), description: t("settings.organization_hint"), children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Select, { value: organizationId, onChange: pick, options: organizations.map((o) => ({ value: o.id, label: o.name })), "aria-label": t("settings.organization") }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ErrorAlert, { error })
  ] }) });
}

// papra/src/index.js
var background = null;
async function activate(api) {
  setApi(api);
  background = createBackground(api);
  await background.registerUi();
  api.i18n.onLocaleChange(() => {
    void background.registerUi();
  });
}
var hooks = {
  onAction(event) {
    if (background) void Promise.resolve(background.onAction(event)).catch(() => {
    });
  }
};
function Dialog(props) {
  if (props.view === "save") return (0, import_react5.createElement)(SaveDialog, props);
  return (0, import_react5.createElement)(Picker, { composerId: props.composerId, onClose: (attached) => props.onResult?.({ attached }) });
}
var slots = {
  "plugin-dialog": { component: Dialog },
  "settings-section": { component: Settings }
};
