var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// calendar-agenda/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// calendar-agenda/src/lib/agenda.js
var import_ui = require("@plugin-host/ui");
var DIRTY_KEY = "agendaDirty";
var BANNER_EVENTS = 4;
var DEFAULT_COLOR = "#3b82f6";
var POSITION_TO_SLOT = {
  "Left sidebar": "sidebar-section",
  "Email reading pane": "email-detail-sidebar",
  "Top banner": "app-top-banner"
};
var DEFAULT_SLOT = "sidebar-section";
function slotForPosition(position) {
  return POSITION_TO_SLOT[position] || DEFAULT_SLOT;
}
function startOfDay(d) {
  const n = new Date(d);
  n.setHours(0, 0, 0, 0);
  return n;
}
function utcBound(date) {
  return `${date.toISOString().slice(0, 19)}Z`;
}
function durationMs(duration) {
  const m = /^P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(duration || "");
  if (!m) return 0;
  const [, w = 0, d = 0, h = 0, min = 0, s = 0] = m;
  return (((+w * 7 + +d) * 24 + +h) * 3600 + +min * 60 + +s) * 1e3;
}
function toAgendaEvent(view, untitled = "", colors = /* @__PURE__ */ new Map()) {
  const allDay = !!view.isAllDay;
  const start = !allDay && view.utcStart ? new Date(view.utcStart) : new Date(view.start);
  const end = !allDay && view.utcEnd ? new Date(view.utcEnd) : new Date(start.getTime() + durationMs(view.duration));
  return {
    id: view.id,
    title: (view.title || "").trim() || untitled,
    start: start.toISOString(),
    end: end.toISOString(),
    allDay,
    status: view.status || null,
    location: view.location || null,
    color: colors.get(view.calendarId) || DEFAULT_COLOR
  };
}
async function calendarColors(api) {
  try {
    const calendars = await api.calendar.listCalendars() || [];
    return new Map(calendars.filter((c) => c?.id && c.color).map((c) => [c.id, c.color]));
  } catch (err) {
    api.log.warn("calendar-agenda: listCalendars failed", err);
    return /* @__PURE__ */ new Map();
  }
}
async function loadAgenda(api, { days, limit, now = /* @__PURE__ */ new Date(), untitled = "" }) {
  const from = startOfDay(now);
  const to = new Date(now.getTime() + days * 864e5);
  const [views, colors] = await Promise.all([
    api.calendar.getEvents({ from: utcBound(from), to: utcBound(to) }),
    calendarColors(api)
  ]);
  return (views || []).filter((v) => typeof v?.start === "string" && !Number.isNaN(Date.parse(v.start))).map((v) => toAgendaEvent(v, untitled, colors)).filter((ev) => Date.parse(ev.end) >= now.getTime()).sort((a, b) => Date.parse(a.start) - Date.parse(b.start)).slice(0, limit);
}
function groupByDay(events, now = /* @__PURE__ */ new Date()) {
  const today = startOfDay(now).getTime();
  const groups = [];
  for (const ev of events) {
    const day = new Date(Math.max(startOfDay(new Date(ev.start)).getTime(), today));
    const last = groups[groups.length - 1];
    if (last && last.day.getTime() === day.getTime()) last.events.push(ev);
    else groups.push({ key: day.getTime(), day, events: [ev] });
  }
  return groups;
}
function makeFormat(api, now = () => /* @__PURE__ */ new Date()) {
  const t = (key, vars) => api.i18n.t(key, vars);
  const locale = () => api.i18n.dateLocale || api.i18n.locale || api.i18n.getLocale && api.i18n.getLocale() || void 0;
  function dayLabel(date) {
    const diffDays = Math.round((startOfDay(date).getTime() - startOfDay(now()).getTime()) / 864e5);
    if (diffDays === 0) return t("day.today");
    if (diffDays === 1) return t("day.tomorrow");
    if (typeof api.i18n?.formatDate === "function") {
      return api.i18n.formatDate(date, { weekday: "short", month: "short", day: "numeric" });
    }
    return date.toLocaleDateString(locale(), { weekday: "short", month: "short", day: "numeric" });
  }
  function timeLabel(ev) {
    if (ev.allDay) return t("event.all_day");
    if (typeof api.i18n?.formatTime === "function") {
      return api.i18n.formatTime(ev.start, { hour: "2-digit", minute: "2-digit" });
    }
    return new Date(ev.start).toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit" });
  }
  function when(ev) {
    const start = new Date(ev.start);
    const today = Math.round((startOfDay(start).getTime() - startOfDay(now()).getTime()) / 864e5) === 0;
    if (today) return timeLabel(ev);
    return ev.allDay ? dayLabel(start) : `${dayLabel(start)} ${timeLabel(ev)}`;
  }
  return { t, dayLabel, timeLabel, when };
}
function makeAgenda(React2, api, { slot = DEFAULT_SLOT, now } = {}) {
  const { createElement: h, useCallback, useEffect, useRef, useState } = React2;
  const fmt = makeFormat(api, now);
  const { t } = fmt;
  const titleTextOf = (ev) => ev.title || t("event.untitled");
  const titleOf = (ev) => ev.status === "cancelled" ? h("del", null, titleTextOf(ev)) : titleTextOf(ev);
  const tooltip = (ev) => [titleTextOf(ev), fmt.when(ev), ev.location].filter(Boolean).join(" · ");
  function useAgenda() {
    const [events, setEvents] = useState([]);
    const [state, setState] = useState("loading");
    const [error, setError] = useState("");
    const lastDirtyRef = useRef(null);
    const inFlightRef = useRef(false);
    const settings = api.plugin?.settings || {};
    const days = Number(settings.daysAhead) || 7;
    const limit = Number(settings.maxEvents) || 50;
    const refreshMs = Math.max(1, Number(settings.refreshMinutes) || 10) * 6e4;
    const fetchAgenda = useCallback(async () => {
      if (inFlightRef.current) return;
      inFlightRef.current = true;
      try {
        setEvents(await loadAgenda(api, { days, limit, now: now ? now() : /* @__PURE__ */ new Date() }));
        setState("ready");
      } catch (err) {
        const text = String(err && err.message || err);
        if (/no active session/.test(text)) {
          setState("unauth");
          return;
        }
        api.log.warn("calendar-agenda: fetch failed", err);
        setError(text);
        setState("error");
      } finally {
        inFlightRef.current = false;
      }
    }, [days, limit]);
    useEffect(() => {
      void fetchAgenda();
      const pollId = setInterval(() => {
        void fetchAgenda();
      }, refreshMs);
      const dirtyId = setInterval(async () => {
        try {
          const mark = await api.storage.get(DIRTY_KEY);
          if (mark && mark !== lastDirtyRef.current) {
            lastDirtyRef.current = mark;
            void fetchAgenda();
          }
        } catch {
        }
      }, 4e3);
      const onFocus = () => {
        void fetchAgenda();
      };
      window.addEventListener("focus", onFocus);
      return () => {
        clearInterval(pollId);
        clearInterval(dirtyId);
        window.removeEventListener("focus", onFocus);
      };
    }, [fetchAgenda, refreshMs]);
    let message = null;
    if (state === "loading") message = t("state.loading");
    else if (state === "unauth") message = t("state.unauth");
    else if (state === "error") message = t("state.error", { error });
    else if (events.length === 0) message = t("state.empty", { days });
    return { events, state, message };
  }
  const dot = (ev) => h("span", {
    style: { display: "inline-flex", width: "16px", justifyContent: "center", verticalAlign: "middle", marginInlineEnd: "8px", lineHeight: 0 }
  }, h(import_ui.ColorDot, { color: ev.color }));
  const chipDot = (ev) => h("span", {
    style: { display: "inline-flex", verticalAlign: "middle", marginInlineEnd: "6px", lineHeight: 0 }
  }, h(import_ui.ColorDot, { color: ev.color }));
  const dayHeading = (date, padding) => h("div", {
    role: "heading",
    "aria-level": 4,
    style: { padding, textTransform: "uppercase", letterSpacing: "0.04em" }
  }, h(import_ui.Text, { size: "xs", tone: "muted", weight: "semibold" }, fmt.dayLabel(date)));
  const groups = (events) => groupByDay(events, now ? now() : /* @__PURE__ */ new Date());
  function SidebarAgenda() {
    const { events, message } = useAgenda();
    if (message) return h(import_ui.SidebarEmpty, null, message);
    return h(React2.Fragment, null, ...groups(events).map((g) => h(
      "div",
      { key: g.key, "data-day": "" },
      dayHeading(g.day, "8px 12px 2px 32px"),
      ...g.events.map((ev) => h(import_ui.SidebarRow, {
        key: ev.id,
        label: h(React2.Fragment, null, dot(ev), titleOf(ev)),
        detail: fmt.timeLabel(ev),
        title: tooltip(ev)
      }))
    )));
  }
  function PanelAgenda() {
    const { events, state, message } = useAgenda();
    let body;
    if (state === "loading") body = h(import_ui.Loading, { label: message });
    else if (state === "error") body = h(import_ui.Alert, { tone: "danger", icon: "alert-triangle" }, message);
    else if (message) body = h(import_ui.EmptyState, { compact: true, icon: "calendar", title: message });
    else {
      body = h(import_ui.Stack, { gap: 3 }, ...groups(events).map((g) => h(
        import_ui.Stack,
        { key: g.key, gap: 1 },
        dayHeading(g.day, "0"),
        h(import_ui.List, { label: fmt.dayLabel(g.day) }, ...g.events.map((ev) => h(import_ui.ListRow, {
          key: ev.id,
          icon: h(import_ui.ColorDot, { color: ev.color }),
          title: titleOf(ev),
          subtitle: [fmt.timeLabel(ev), ev.location].filter(Boolean).join(" · ")
        })))
      )));
    }
    return h(import_ui.Page, null, h(import_ui.Stack, { gap: 3 }, h(import_ui.Heading, { level: 3 }, t("header.title")), body));
  }
  function BannerAgenda() {
    const { events, message } = useAgenda();
    return h(
      import_ui.InfoBar,
      { compact: true, tone: "primary", icon: "calendar", eyebrow: t("header.title"), title: message || void 0 },
      ...message ? [] : events.slice(0, BANNER_EVENTS).map((ev) => h(import_ui.Chip, {
        key: ev.id,
        label: h(React2.Fragment, null, chipDot(ev), titleOf(ev)),
        detail: fmt.when(ev),
        title: tooltip(ev)
      })),
      !message && events.length > BANNER_EVENTS ? h(import_ui.Text, { key: "more", size: "xs", tone: "muted" }, `+${events.length - BANNER_EVENTS}`) : null
    );
  }
  if (slot === "email-detail-sidebar") return PanelAgenda;
  if (slot === "app-top-banner") return BannerAgenda;
  return SidebarAgenda;
}

// calendar-agenda/src/index.js
var React = require("react");
var slotApi = require("@plugin-host");
var activeSlot = slotForPosition(slotApi?.plugin?.settings?.position);
var slots = {
  [activeSlot]: {
    component: makeAgenda(React, slotApi, { slot: activeSlot }),
    order: 15
  }
};
var pluginApi = null;
function markDirty() {
  if (!pluginApi) return;
  void pluginApi.storage.set(DIRTY_KEY, Date.now());
}
var hooks = {
  onAfterEventCreate() {
    markDirty();
  },
  onAfterEventUpdate() {
    markDirty();
  },
  onAfterEventDelete() {
    markDirty();
  },
  onEventsImport() {
    markDirty();
  },
  onEventRsvp() {
    markDirty();
  },
  onCalendarChange() {
    markDirty();
  },
  onICalSubscriptionChange() {
    markDirty();
  }
};
function setTitle(api) {
  if (activeSlot !== "sidebar-section") return;
  Promise.resolve(api.ui.setSectionTitle(api.i18n.t("header.title"))).catch((err) => {
    api.log.warn("calendar-agenda: setSectionTitle failed", err);
  });
}
async function activate(api) {
  pluginApi = api;
  setTitle(api);
  api.i18n.onLocaleChange?.(() => setTitle(api));
  api.log.info("Calendar Agenda plugin activated");
}
