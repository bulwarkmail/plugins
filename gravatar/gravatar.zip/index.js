// src/index.js
async function sha256hex(str) {
  const encoded = new TextEncoder().encode(str);
  const hashBuffer = await crypto.subtle.digest("SHA-256", encoded);
  return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function gravatarUrl(hash, { size, rating, defaultStyle }) {
  const params = new URLSearchParams({
    s: String(size),
    r: rating,
    d: defaultStyle
  });
  return `https://gravatar.com/avatar/${hash}?${params}`;
}
async function gravatarExists(url) {
  try {
    const checkUrl = url.includes("?") ? `${url}&d=404` : `${url}?d=404`;
    const res = await fetch(checkUrl, { method: "HEAD" });
    return res.ok;
  } catch {
    return false;
  }
}
function activate(api) {
  const settings = api.plugin.settings;
  const size = typeof settings.size === "number" ? settings.size : 160;
  const rating = settings.rating || "g";
  const defaultStyle = settings.defaultStyle || "404";
  const cache = /* @__PURE__ */ new Map();
  const avatarResolve = api.hooks.onAvatarResolve(
    async (currentUrl, context) => {
      const email = context?.email;
      if (!email) return void 0;
      const normalized = email.trim().toLowerCase();
      if (cache.has(normalized)) {
        return cache.get(normalized) ?? void 0;
      }
      const hash = await sha256hex(normalized);
      const url = gravatarUrl(hash, { size, rating, defaultStyle });
      if (defaultStyle === "404") {
        const exists = await gravatarExists(url);
        if (!exists) {
          cache.set(normalized, null);
          return void 0;
        }
      }
      cache.set(normalized, url);
      return url;
    }
  );
  api.log.info(
    `Gravatar plugin activated (size=${size}, rating=${rating}, default=${defaultStyle})`
  );
  return {
    dispose: () => {
      avatarResolve.dispose();
      cache.clear();
      api.log.info("Gravatar plugin deactivated");
    }
  };
}
export {
  activate
};
