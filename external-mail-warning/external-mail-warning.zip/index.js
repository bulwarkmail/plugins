var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// external-mail-warning/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// external-mail-warning/src/lib/banner.js
var React = __toESM(require("react"), 1);
var import_ui = require("@plugin-host/ui");
function formatSender(s) {
  if (!s) return "";
  if (s.name && s.email) return `${s.name} <${s.email}>`;
  return s.email || s.name || "";
}
function warningLabel(externals, fails) {
  const parts = [];
  if (externals.length > 0) parts.push(externals.length === 1 ? "External sender" : "External senders");
  if (fails.length > 0) parts.push(`${fails.join(", ")} failed`);
  return parts.join(" · ");
}
function SenderWarning({ externals, fails }) {
  if (externals.length === 0 && fails.length === 0) return null;
  const from = externals.map(formatSender).join(", ");
  return React.createElement(import_ui.InfoBar, {
    tone: "warning",
    icon: "alert-triangle",
    eyebrow: warningLabel(externals, fails),
    title: from || void 0
  });
}

// external-mail-warning/src/lib/handover.js
function coreConfirmsRecipients(api) {
  return api?.host?.features?.externalRecipientWarning === true;
}
function coreLabelsSenders(api) {
  return api?.host?.features?.externalSenderLabel === true;
}

// external-mail-warning/src/index.js
var { createElement: h, useEffect, useState } = require("react");
var slotApi = require("@plugin-host");
function parseDomains(input) {
  if (!input) return [];
  if (Array.isArray(input)) {
    return input.map((d) => normaliseDomain(String(d))).filter(Boolean);
  }
  return String(input).split(/[\s,;]+/).map(normaliseDomain).filter(Boolean);
}
function normaliseDomain(raw) {
  let d = String(raw).trim().toLowerCase();
  if (!d) return "";
  d = d.replace(/^\*\./, "");
  d = d.replace(/^https?:\/\//, "");
  d = d.replace(/\/.*$/, "");
  return d;
}
function addressOf(value) {
  const s = String(value || "").trim();
  const m = s.match(/<([^<>]*)>\s*$/);
  return (m ? m[1] : s).trim();
}
function domainOf(address) {
  const addr = addressOf(address);
  const at = addr.lastIndexOf("@");
  if (at < 0) return "";
  return addr.slice(at + 1).trim().toLowerCase();
}
async function loadIdentityDomains(api) {
  try {
    const identities = await api.user.getIdentities();
    const emails = (Array.isArray(identities) ? identities : []).map((i) => String(i?.email || "").trim().toLowerCase()).filter(Boolean);
    return {
      emails,
      domains: [...new Set(emails.map(domainOf).filter(Boolean))]
    };
  } catch (err) {
    api.log.warn("Could not load sending identities", err);
    return { emails: [], domains: [] };
  }
}
function isSafeDomain(domain, list) {
  if (!domain) return false;
  for (const d of list) {
    if (!d) continue;
    if (domain === d) return true;
    if (domain.endsWith("." + d)) return true;
  }
  return false;
}
function classifyRecipients(email, safeDomains, includeCcBcc) {
  const buckets = [{ field: "To", list: email.to || [] }];
  if (includeCcBcc) {
    buckets.push({ field: "Cc", list: email.cc || [] });
    buckets.push({ field: "Bcc", list: email.bcc || [] });
  }
  const externals = [];
  for (const { field, list } of buckets) {
    for (const addr of list) {
      const domain = domainOf(addr);
      if (!domain) continue;
      if (!isSafeDomain(domain, safeDomains)) {
        externals.push({ field, address: addr, domain });
      }
    }
  }
  return externals;
}
function externalSenders(email, safeDomains) {
  if (!email || !Array.isArray(email.from)) return [];
  const out = [];
  for (const sender of email.from) {
    const addr = sender?.email;
    const domain = domainOf(addr);
    if (!domain) continue;
    if (!isSafeDomain(domain, safeDomains)) {
      out.push({ name: sender.name || "", email: addr, domain });
    }
  }
  return out;
}
var SPF_BAD = /* @__PURE__ */ new Set(["fail", "softfail", "temperror", "permerror"]);
var DKIM_BAD = /* @__PURE__ */ new Set(["fail", "policy", "temperror", "permerror"]);
var IPREV_BAD = /* @__PURE__ */ new Set(["fail", "temperror", "permerror"]);
function dmarcFailed(dmarc) {
  if (!dmarc) return false;
  if (dmarc.result === "fail" || dmarc.result === "permerror" || dmarc.result === "temperror") return true;
  if (dmarc.result === "none" && (dmarc.policy === "reject" || dmarc.policy === "quarantine")) return true;
  return false;
}
function authFailures(email) {
  const auth = email?.auth;
  if (!auth) return [];
  const fails = [];
  if (auth.spf && SPF_BAD.has(auth.spf.result)) fails.push("SPF");
  if (auth.dkim && DKIM_BAD.has(auth.dkim.result)) fails.push("DKIM");
  if (dmarcFailed(auth.dmarc)) fails.push("DMARC");
  if (auth.iprev && IPREV_BAD.has(auth.iprev.result)) fails.push("rDNS");
  return fails;
}
var pluginApi = null;
var cachedAdminDomains = [];
var adminFetched = false;
var adminFetchPromise = null;
var myAddresses = /* @__PURE__ */ new Set();
var identityDomains = [];
async function refreshIdentities() {
  const { emails, domains } = await loadIdentityDomains(pluginApi);
  identityDomains = domains;
  for (const e of emails) void rememberMyAddress(e);
}
function fetchAdminDomains() {
  if (adminFetched) return Promise.resolve(cachedAdminDomains);
  if (adminFetchPromise) return adminFetchPromise;
  adminFetchPromise = (async () => {
    try {
      const value = await pluginApi.admin.getConfig("safeDomains");
      cachedAdminDomains = parseDomains(value);
    } catch (err) {
      pluginApi.log.warn("Could not load admin safe-domains list", err);
      cachedAdminDomains = [];
    } finally {
      adminFetched = true;
    }
    return cachedAdminDomains;
  })();
  return adminFetchPromise;
}
function mergeSafeDomains(adminDomains, settings, ownDomains) {
  const userDomains = parseDomains(settings?.safeDomainsCsv);
  const own = settings?.treatIdentityDomainAsSafe !== false ? ownDomains : [];
  return [
    ...new Set(
      [...adminDomains, ...userDomains, ...own].map(normaliseDomain).filter(Boolean)
    )
  ];
}
function getSafeDomainsSync() {
  return mergeSafeDomains(cachedAdminDomains, pluginApi?.plugin.settings, identityDomains);
}
async function getSafeDomainsForOutgoing(senderEmail) {
  await fetchAdminDomains();
  const merged = getSafeDomainsSync();
  if (pluginApi.plugin.settings.treatIdentityDomainAsSafe !== false) {
    const own = domainOf(senderEmail);
    if (own && !merged.includes(own)) merged.push(own);
  }
  return merged;
}
function isFromSelf(email) {
  if (!email || !Array.isArray(email.from)) return false;
  return email.from.some(
    (s) => myAddresses.has(addressOf(s?.email).toLowerCase())
  );
}
async function rememberMyAddress(addr) {
  if (!addr) return;
  const norm = addressOf(addr).toLowerCase();
  if (!norm || myAddresses.has(norm)) return;
  myAddresses.add(norm);
  await pluginApi.storage.set("myAddresses", [...myAddresses]);
}
function useSafeDomains() {
  const [safeDomains, setSafeDomains] = useState(null);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const adminRaw = await slotApi.admin.getConfig("safeDomains").catch(() => null);
        const { domains } = await loadIdentityDomains(slotApi);
        const merged = mergeSafeDomains(parseDomains(adminRaw), slotApi.plugin?.settings, domains);
        if (!cancelled) setSafeDomains(merged);
      } catch (err) {
        slotApi.log.warn("external-mail-warning: safe-domain lookup failed", err);
        if (!cancelled) setSafeDomains([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  return safeDomains;
}
function ExternalSenderBanner(props) {
  const email = props.email;
  const safeDomains = useSafeDomains();
  if (!email) return null;
  if (coreLabelsSenders(slotApi)) return null;
  const safeList = safeDomains || [];
  const externals = safeDomains && safeDomains.length === 0 ? [] : externalSenders(email, safeList);
  const fails = slotApi.plugin?.settings?.warnOnAuthFailure !== false ? authFailures(email) : [];
  if (externals.length === 0 && fails.length === 0) return null;
  return h(SenderWarning, { externals, fails });
}
function shouldShowBanner(extraProps) {
  if (!pluginApi) return false;
  if (coreLabelsSenders(pluginApi)) return false;
  if (pluginApi.plugin.settings.warnOnIncoming === false) return false;
  const email = extraProps?.email;
  if (!email) return false;
  if (isFromSelf(email)) return false;
  const safe = getSafeDomainsSync();
  const externals = safe.length > 0 ? externalSenders(email, safe) : [];
  const fails = pluginApi.plugin.settings.warnOnAuthFailure !== false ? authFailures(email) : [];
  return externals.length > 0 || fails.length > 0;
}
var slots = {
  "email-banner": {
    component: ExternalSenderBanner,
    shouldShow: shouldShowBanner,
    order: 50
  }
};
var hooks = {
  async onBeforeEmailSend(email) {
    if (!email || !pluginApi) return;
    if (coreConfirmsRecipients(pluginApi)) return;
    void rememberMyAddress(email.fromEmail);
    const safe = await getSafeDomainsForOutgoing(email.fromEmail);
    const includeCcBcc = pluginApi.plugin.settings.warnOnCcBcc !== false;
    const externals = classifyRecipients(email, safe, includeCcBcc);
    if (externals.length === 0) return;
    const list = externals.map((e) => `[${e.field}] ${e.address}`).join("\n");
    const proceed = await pluginApi.ui.confirm({
      title: "Send to external recipients?",
      message: `${externals.length} recipient(s) are outside your safe-domain list:

${list}

Continue only if you intend to send to them.`,
      confirmLabel: "Send anyway",
      cancelLabel: "Cancel",
      danger: true
    });
    if (!proceed) {
      pluginApi.toast.info("Send cancelled");
      return false;
    }
  },
  onNewEmailReceived(notif) {
    if (!pluginApi) return;
    if (coreLabelsSenders(pluginApi)) return;
    if (pluginApi.plugin.settings.notifyOnIncomingExternal !== true) return;
    if (!notif || !notif.from) return;
    const senders = Array.isArray(notif.from) ? notif.from : [notif.from];
    const email = { from: senders.map((s) => typeof s === "string" ? { email: s } : s) };
    if (isFromSelf(email)) return;
    const safe = getSafeDomainsSync();
    if (safe.length === 0) return;
    const externals = externalSenders(email, safe);
    if (externals.length === 0) return;
    pluginApi.toast.warning(`New external email from ${externals[0].domain}`);
  },
  // Keep the identity domains current when identities are added or changed.
  onIdentitiesLoaded() {
    if (pluginApi) void refreshIdentities();
  }
};
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("myAddresses") || [];
  myAddresses = new Set(
    (Array.isArray(stored) ? stored : []).map((s) => String(s).trim().toLowerCase())
  );
  fetchAdminDomains().catch(() => {
  });
  await refreshIdentities();
  api.log.info("External Mail Warning plugin activated");
}
