// src/index.js
function activate(api) {
  const disposables = [];
  disposables.push(
    api.ui.registerCalendarEventAction({
      id: "add-jitsi-meeting",
      label: "Add Jitsi Meeting",
      order: 10,
      onClick: async (eventData, { setVirtualLocation }) => {
        try {
          const response = await api.http.post("/api/jitsi", {
            eventTitle: eventData.title || "meeting"
          });
          if (!response.ok) {
            throw new Error(`Server responded with ${response.status}`);
          }
          setVirtualLocation(response.data.url);
          api.toast.success("Jitsi meeting link added");
        } catch (err) {
          api.log.error("Failed to create Jitsi meeting link", err);
          api.toast.error("Failed to create Jitsi meeting link");
        }
      }
    })
  );
  api.log.info("Jitsi Meet plugin activated");
  return {
    dispose: () => {
      disposables.forEach((d) => d.dispose());
    }
  };
}
export {
  activate
};
