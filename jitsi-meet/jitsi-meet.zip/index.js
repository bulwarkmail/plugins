var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// jitsi-meet/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// jitsi-meet/src/lib/button.js
var import_ui = require("@plugin-host/ui");

// jitsi-meet/src/lib/links.js
function withoutJwt(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return url;
  }
  if (!parsed.searchParams.has("jwt")) return url;
  parsed.searchParams.delete("jwt");
  return parsed.toString();
}
function tokenClaims(token) {
  const part = String(token || "").split(".")[1];
  if (!part) return null;
  try {
    const json = atob(part.replace(/-/g, "+").replace(/_/g, "/"));
    const claims = JSON.parse(json);
    return claims && typeof claims === "object" ? claims : null;
  } catch {
    return null;
  }
}
function stripPluginToken(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  const claims = tokenClaims(parsed.searchParams.get("jwt"));
  if (!claims || claims.iss !== "bulwark-webmail" || claims.aud !== "jitsi") return null;
  return withoutJwt(url);
}
function isHostedRoom(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return false;
  const room = parsed.pathname.split("/").pop() || "";
  return /(^|-)[0-9a-f]{8}-[0-9a-f]{16}$/.test(room);
}

// jitsi-meet/src/lib/button.js
function makeJitsiButton(React2, api) {
  const { createElement: h, useEffect, useRef, useState } = React2;
  return function JitsiAddButton(props) {
    const [busy, setBusy] = useState(false);
    const [joining, setJoining] = useState(false);
    const eventTitle = props?.eventData?.title || "meeting";
    const link = String(props?.eventData?.virtualLocation ?? "").trim();
    const setVirtualLocation = props?.setVirtualLocation;
    const cleaned = useRef("");
    useEffect(() => {
      if (!link || cleaned.current === link || typeof setVirtualLocation !== "function") return;
      const clean = stripPluginToken(link);
      if (clean === null) return;
      cleaned.current = link;
      Promise.resolve(setVirtualLocation(clean)).then(
        () => api.toast.info("Removed your Jitsi sign-in from the meeting link. Save the event so attendees get the link without it."),
        () => {
        }
      );
    }, [link, setVirtualLocation]);
    async function handleClick() {
      if (busy) return;
      setBusy(true);
      try {
        const response = await api.http.post("/api/jitsi", { eventTitle });
        if (!response || !response.ok) {
          throw new Error(response?.data?.error || `HTTP ${response?.status ?? "error"}`);
        }
        const answer = response.data?.url;
        if (!answer) throw new Error("No url in response");
        const url = withoutJwt(answer);
        if (typeof setVirtualLocation === "function") {
          await setVirtualLocation(url);
          api.toast.success("Jitsi meeting added to event");
        } else {
          await api.ui.alert({ title: "Jitsi meeting created", message: url });
        }
      } catch (err) {
        const message = err && err.message ? err.message : String(err);
        api.toast.error(`Could not create Jitsi meeting: ${message}`);
      } finally {
        setBusy(false);
      }
    }
    async function handleJoin() {
      if (joining) return;
      setJoining(true);
      try {
        const response = await api.http.post("/api/jitsi", { action: "join", url: withoutJwt(link) });
        if (!response || !response.ok) {
          throw new Error(response?.data?.error || `HTTP ${response?.status ?? "error"}`);
        }
        const url = response.data?.url;
        if (!url) throw new Error("No url in response");
        await api.ui.openExternalUrl(url);
      } catch (err) {
        const message = err && err.message ? err.message : String(err);
        api.toast.error(`Could not join as moderator: ${message}`);
      } finally {
        setJoining(false);
      }
    }
    const add = h(import_ui.Button, { variant: "secondary", size: "sm", icon: "video", busy, onClick: handleClick }, "Add Jitsi meeting");
    if (!isHostedRoom(link)) return add;
    return h(
      import_ui.Row,
      null,
      add,
      h(import_ui.Button, { variant: "secondary", size: "sm", icon: "external-link", busy: joining, onClick: handleJoin }, "Join as moderator")
    );
  };
}

// jitsi-meet/src/index.js
var React = require("react");
var slotApi = require("@plugin-host");
var slots = {
  "calendar-event-actions": {
    component: makeJitsiButton(React, slotApi),
    order: 10
  }
};
async function activate(api) {
  api.log.info("Jitsi Meet plugin activated");
}
