"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);
var pluginApi = null;
function escapeHtml(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function escapeText(s) {
  return String(s ?? "");
}
function joinAddresses(list) {
  if (!Array.isArray(list) || list.length === 0) return "";
  return list.filter((a) => a && a.email).map((a) => a.name ? `${a.name} <${a.email}>` : a.email).join(", ");
}
function shouldApply(mode) {
  const setting = pluginApi?.plugin?.settings?.applyTo ?? "both";
  if (setting === "both") return true;
  if (setting === "reply") return mode === "reply" || mode === "replyAll";
  if (setting === "forward") return mode === "forward";
  return true;
}
function formatSent(ctx) {
  if (!ctx.receivedAt) return ctx.date || "";
  const d = new Date(ctx.receivedAt);
  if (isNaN(d.getTime())) return ctx.date || "";
  try {
    return new Intl.DateTimeFormat(ctx.locale || "en", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit"
    }).format(d);
  } catch {
    return d.toISOString();
  }
}
function buildOutlookHtml(ctx, opts) {
  const fromStr = ctx.from ? ctx.from.name ? `${ctx.from.name} <${ctx.from.email}>` : ctx.from.email : "";
  const sent = formatSent(ctx);
  const toStr = joinAddresses(ctx.to);
  const ccStr = joinAddresses(ctx.cc);
  const subject = ctx.subject || "";
  const labelOpen = opts.boldLabels ? "<strong>" : "";
  const labelClose = opts.boldLabels ? "</strong>" : "";
  const row = (label, value) => value ? `<div>${labelOpen}${label}:${labelClose} ${escapeHtml(value)}</div>` : "";
  const rule = opts.thinRuleAbove ? '<hr style="border:none;border-top:1px solid #ccc;margin:12px 0">' : "";
  return rule + `<div style="font-family:inherit">` + row("From", fromStr) + row("Sent", sent) + row("To", toStr) + (ccStr ? row("Cc", ccStr) : "") + row("Subject", subject) + `</div><div><br></div>`;
}
function buildOutlookText(ctx) {
  const fromStr = ctx.from ? ctx.from.name ? `${ctx.from.name} <${ctx.from.email}>` : ctx.from.email : "";
  const sent = formatSent(ctx);
  const toStr = joinAddresses(ctx.to);
  const ccStr = joinAddresses(ctx.cc);
  const subject = ctx.subject || "";
  const lines = [];
  if (fromStr) lines.push(`From: ${escapeText(fromStr)}`);
  if (sent) lines.push(`Sent: ${escapeText(sent)}`);
  if (toStr) lines.push(`To: ${escapeText(toStr)}`);
  if (ccStr) lines.push(`Cc: ${escapeText(ccStr)}`);
  if (subject) lines.push(`Subject: ${escapeText(subject)}`);
  lines.push("");
  return lines.join("\n");
}
var hooks = {
  onBuildQuoteHeader(current, ctx) {
    if (!pluginApi || !ctx) return void 0;
    if (!shouldApply(ctx.mode)) return void 0;
    const opts = {
      boldLabels: pluginApi.plugin.settings.boldLabels !== false,
      thinRuleAbove: pluginApi.plugin.settings.thinRuleAbove !== false
    };
    return {
      html: buildOutlookHtml(ctx, opts),
      text: buildOutlookText(ctx),
      wrapInBlockquote: false
    };
  }
};
async function activate(api) {
  pluginApi = api;
  api.log.info("Outlook-style Quote Headers activated");
}
