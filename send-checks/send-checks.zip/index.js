var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// send-checks/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);

// send-checks/src/lib/iban.js
var IBAN_LENGTHS = {
  AD: 24,
  AE: 23,
  AL: 28,
  AT: 20,
  AZ: 28,
  BA: 20,
  BE: 16,
  BG: 22,
  BH: 22,
  BI: 27,
  BR: 29,
  BY: 28,
  CH: 21,
  CR: 22,
  CY: 28,
  CZ: 24,
  DE: 22,
  DJ: 27,
  DK: 18,
  DO: 28,
  EE: 20,
  EG: 29,
  ES: 24,
  FI: 18,
  FK: 18,
  FO: 18,
  FR: 27,
  GB: 22,
  GE: 22,
  GI: 23,
  GL: 18,
  GR: 27,
  GT: 28,
  HN: 28,
  HR: 21,
  HU: 28,
  IE: 22,
  IL: 23,
  IQ: 23,
  IS: 26,
  IT: 27,
  JO: 30,
  KW: 30,
  KZ: 20,
  LB: 28,
  LC: 32,
  LI: 21,
  LT: 20,
  LU: 20,
  LV: 21,
  LY: 25,
  MC: 27,
  MD: 24,
  ME: 22,
  MK: 19,
  MN: 20,
  MR: 27,
  MT: 31,
  MU: 30,
  NI: 28,
  NL: 18,
  NO: 15,
  OM: 23,
  PK: 24,
  PL: 28,
  PS: 29,
  PT: 25,
  QA: 29,
  RO: 24,
  RS: 22,
  RU: 33,
  SA: 24,
  SC: 31,
  SD: 18,
  SE: 24,
  SI: 19,
  SK: 24,
  SM: 27,
  SO: 23,
  ST: 25,
  SV: 28,
  TL: 23,
  TN: 24,
  TR: 26,
  UA: 29,
  VA: 22,
  VG: 24,
  XK: 20,
  YE: 30
};
var ALNUM = /[A-Za-z0-9]/;
function ibanChecksumOk(iban) {
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]+$/.test(iban)) return false;
  const moved = iban.slice(4) + iban.slice(0, 4);
  let rest = 0;
  for (const ch of moved) {
    const code = ch.charCodeAt(0);
    const digits = code >= 65 ? String(code - 55) : ch;
    for (const d of digits) rest = (rest * 10 + (d.charCodeAt(0) - 48)) % 97;
  }
  return rest === 1;
}
function findIbans(text2) {
  const out = [];
  if (!text2) return out;
  const start = /(?<![A-Za-z0-9])([A-Za-z]{2})(\d{2})/g;
  let m;
  while (m = start.exec(text2)) {
    const country = m[1].toUpperCase();
    const length = IBAN_LENGTHS[country];
    if (!length) continue;
    let compact = country + m[2];
    let i = m.index + 4;
    let end = i;
    while (i < text2.length && compact.length < length) {
      const ch = text2[i];
      if (ALNUM.test(ch)) {
        compact += ch.toUpperCase();
        i += 1;
        end = i;
      } else if (ch === " " && i + 1 < text2.length && ALNUM.test(text2[i + 1])) {
        i += 1;
      } else {
        break;
      }
    }
    if (compact.length !== length || end < text2.length && ALNUM.test(text2[end])) continue;
    if (!ibanChecksumOk(compact)) continue;
    out.push({ value: compact, start: m.index, end });
    start.lastIndex = end;
  }
  return out;
}
function maskIban(compact) {
  const value = String(compact ?? "");
  return `${value.slice(0, 4)} … ${value.slice(-4)}`;
}

// send-checks/src/lib/cards.js
function luhnOk(digits) {
  if (!/^\d+$/.test(digits)) return false;
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let d = digits.charCodeAt(i) - 48;
    if (double) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    double = !double;
  }
  return sum % 10 === 0;
}
function looksLikeCard(digits) {
  if (digits.length < 13 || digits.length > 19) return false;
  if (/^(\d)\1+$/.test(digits)) return false;
  const two = Number(digits.slice(0, 2));
  const four = Number(digits.slice(0, 4));
  if (digits[0] === "4") return true;
  if (two >= 51 && two <= 55) return true;
  if (four >= 2221 && four <= 2720) return true;
  if ([30, 34, 35, 36, 37, 38, 39].includes(two)) return true;
  if (digits[0] === "5" || digits[0] === "6") return true;
  return false;
}
var RUN = /(?<![\d.,-])\d(?:[ -]?\d){12,18}(?![\d]|[.,]\d)/g;
function findCards(text2, skip = []) {
  const out = [];
  if (!text2) return out;
  let m;
  RUN.lastIndex = 0;
  while (m = RUN.exec(text2)) {
    const raw = m[0];
    const start = m.index;
    const end = start + raw.length;
    if (skip.some((r) => start < r.end && end > r.start)) continue;
    const seps = raw.replace(/\d/g, "");
    if (seps && !/^( +|-+)$/.test(seps)) continue;
    const digits = raw.replace(/\D/g, "");
    if (!looksLikeCard(digits) || !luhnOk(digits)) continue;
    out.push({ digits, start, end });
  }
  return out;
}
function cardLastFour(digits) {
  return String(digits ?? "").slice(-4);
}

// send-checks/src/lib/text-rules.js
var MAX_PATTERN_LENGTH = 200;
var MAX_RULES = 50;
var CHUNK = 8 * 1024;
var OVERLAP = 256;
var PATTERN_BUDGET_MS = 250;
function lines(value) {
  return String(value ?? "").split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith("#"));
}
function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function parseKeywords(value) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const keyword of lines(value).slice(0, MAX_RULES * 4)) {
    const key = keyword.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    const wordStart = /^[\p{L}\p{N}]/u.test(keyword) ? "(?<![\\p{L}\\p{N}_])" : "";
    const wordEnd = /[\p{L}\p{N}]$/u.test(keyword) ? "(?![\\p{L}\\p{N}_])" : "";
    out.push({ keyword, re: new RegExp(`${wordStart}${escapeRegex(keyword)}${wordEnd}`, "iu") });
  }
  return out;
}
function findKeywords(text2, keywords) {
  if (!text2) return [];
  return keywords.filter((k) => k.re.test(text2)).map((k) => k.keyword);
}
function patternProblem(source) {
  if (!source) return "empty";
  if (source.length > MAX_PATTERN_LENGTH) return "too long";
  if (/\\[1-9]|\\k</.test(source)) return "back reference";
  if (/\((?:[^()\\]|\\.)*(?:[+*]|\{\d+,?\d*\})(?:[^()\\]|\\.)*\)\s*(?:[+*]|\{\d+,?\d*\})/.test(source)) return "nested quantifier";
  if (/\((?:[^()\\]|\\.)*\|(?:[^()\\]|\\.)*\)\s*(?:[+*]|\{\d+,?\d*\})/.test(source)) return "repeated alternation";
  return null;
}
function parsePatterns(value) {
  const rules = [];
  const skipped = [];
  for (const line of lines(value).slice(0, MAX_RULES)) {
    let name = "";
    let body = line;
    const named = /^([^:/]{1,60}?):\s+(.+)$/.exec(line);
    if (named) {
      name = named[1].trim();
      body = named[2].trim();
    }
    let source = body;
    let flags = "i";
    const literal = /^\/(.+)\/([a-z]*)$/.exec(body);
    if (literal) {
      source = literal[1];
      flags = [...new Set(literal[2].split(""))].filter((f) => "imsu".includes(f)).join("");
    }
    const problem = patternProblem(source);
    if (problem) {
      skipped.push({ line, reason: problem });
      continue;
    }
    try {
      rules.push({ name: name || source, re: new RegExp(source, `${flags}g`) });
    } catch (err) {
      skipped.push({ line, reason: String(err && err.message ? err.message : err) });
    }
  }
  return { rules, skipped };
}
function findPatterns(text2, rules, deadline = Date.now() + PATTERN_BUDGET_MS) {
  const found = [];
  let timedOut = false;
  if (!text2 || rules.length === 0) return { found, timedOut };
  for (const rule of rules) {
    let hit = null;
    for (let at = 0; at < text2.length && !hit; at += CHUNK) {
      if (Date.now() > deadline) {
        timedOut = true;
        return { found, timedOut };
      }
      const piece = text2.slice(at, at + CHUNK + OVERLAP);
      rule.re.lastIndex = 0;
      let m;
      while (m = rule.re.exec(piece)) {
        if (m[0]) {
          hit = m[0];
          break;
        }
        rule.re.lastIndex += 1;
      }
    }
    if (hit) found.push({ name: rule.name, match: hit });
  }
  return { found, timedOut };
}
function maskMatch(value) {
  const s = String(value ?? "").replace(/\s+/g, " ").trim();
  if (s.length <= 4) return "•".repeat(Math.max(s.length, 1));
  if (s.length <= 8) return `${s[0]}…${s[s.length - 1]}`;
  return `${s.slice(0, 2)}…${s.slice(-2)}`;
}

// send-checks/src/lib/attachments.js
var SNIFFED_BY_EXTENSION = {
  "application/x-msdownload": ["exe", "dll", "scr", "com", "cpl", "pif", "sys", "ocx", "drv", "efi"],
  "application/x-executable": ["elf", "so", "bin", "run", "out"],
  "application/x-mach-binary": ["app", "dylib", "macho"],
  "text/x-shellscript": ["sh", "bash", "zsh", "ksh", "csh", "command"],
  "application/x-rar-compressed": ["rar"],
  "application/x-7z-compressed": ["7z"],
  "application/gzip": ["gz", "tgz"],
  "application/pdf": ["pdf"],
  "application/zip": ["zip"]
};
var ZIP_CONTAINERS = /* @__PURE__ */ new Set([
  "zip",
  "docx",
  "docm",
  "xlsx",
  "xlsm",
  "pptx",
  "pptm",
  "odt",
  "ods",
  "odp",
  "odg",
  "jar",
  "apk",
  "epub",
  "xpi",
  "vsix",
  "kmz",
  "ipa",
  "nupkg",
  "whl",
  "3mf",
  "pages",
  "numbers",
  "key"
]);
var PROGRAM_TYPES = /* @__PURE__ */ new Set([
  "application/x-msdownload",
  "application/x-executable",
  "application/x-mach-binary",
  "text/x-shellscript"
]);
function parseTypeList(value) {
  const extensions = /* @__PURE__ */ new Set();
  const types = /* @__PURE__ */ new Set();
  for (const raw of String(value ?? "").split(/[\s,;]+/)) {
    const item = raw.trim().toLowerCase();
    if (!item) continue;
    if (item.includes("/")) types.add(item);
    else extensions.add(item.replace(/^\*?\./, ""));
  }
  return { extensions, types };
}
function isEmptyList(list) {
  return list.extensions.size === 0 && list.types.size === 0;
}
function extensionsOf(name) {
  const parts = String(name ?? "").toLowerCase().trim().replace(/[.\s]+$/, "").split(".");
  if (parts.length < 2) return [];
  return parts.slice(1).filter((p) => /^[a-z0-9]{1,10}$/.test(p) && !/^\d+$/.test(p));
}
function typeMatches(type, types) {
  if (!type) return false;
  const t = type.toLowerCase();
  if (types.has(t)) return true;
  const slash = t.indexOf("/");
  return slash > 0 && types.has(`${t.slice(0, slash)}/*`);
}
function sniffedTypesFor(extensions) {
  const out = /* @__PURE__ */ new Set();
  for (const [type, exts] of Object.entries(SNIFFED_BY_EXTENSION)) {
    if (exts.some((e) => extensions.has(e))) out.add(type);
  }
  return out;
}
function typeProblem(file, blocked, allowed) {
  const exts = extensionsOf(file.name);
  const last = exts[exts.length - 1] ?? "";
  const sniffed = typeof file.sniffedType === "string" ? file.sniffedType.toLowerCase() : "";
  const sniffedCounts = sniffed && !(sniffed === "application/zip" && ZIP_CONTAINERS.has(last) && last !== "zip");
  const declared = typeof file.type === "string" ? file.type.toLowerCase() : "";
  if (!isEmptyList(blocked)) {
    if (last && blocked.extensions.has(last)) return { reason: "blocked", type: last };
    if (sniffedCounts && (typeMatches(sniffed, blocked.types) || sniffedTypesFor(blocked.extensions).has(sniffed))) {
      return { reason: "blocked", type: sniffed };
    }
    if (declared && typeMatches(declared, blocked.types)) return { reason: "blocked", type: declared };
  }
  if (!isEmptyList(allowed)) {
    const byExtension = !!last && allowed.extensions.has(last);
    const byType = typeMatches(declared, allowed.types) || sniffedCounts && typeMatches(sniffed, allowed.types);
    if (!byExtension && !byType) return { reason: "not-allowed", type: last || declared || sniffed || "?" };
    if (sniffedCounts && PROGRAM_TYPES.has(sniffed) && !typeMatches(sniffed, allowed.types) && !sniffedTypesFor(allowed.extensions).has(sniffed)) {
      return { reason: "not-allowed", type: sniffed };
    }
  }
  return null;
}
function maxBytes(maxSizeMb) {
  const n = Number(maxSizeMb);
  return Number.isFinite(n) && n > 0 ? Math.round(n * 1024 * 1024) : 0;
}
function attachmentProblems(attachments, { blocked, allowed, limit }) {
  const out = [];
  for (const file of Array.isArray(attachments) ? attachments : []) {
    if (!file || typeof file !== "object") continue;
    const name = String(file.name || "attachment");
    if (!file.inline) {
      const problem = typeProblem(file, blocked, allowed);
      if (problem) out.push({ name, kind: "type", type: problem.type, reason: problem.reason });
    }
    if (limit > 0 && Number(file.size) > limit) out.push({ name, kind: "size" });
  }
  return out;
}
var TEXT_EXTENSIONS = /* @__PURE__ */ new Set(["txt", "csv", "tsv", "json", "xml", "ics", "vcf", "md", "log", "html", "htm", "yaml", "yml"]);
function isTextAttachment(file) {
  const type = String(file?.type ?? "").toLowerCase();
  if (type.startsWith("text/") || /\/(json|xml|csv)$/.test(type)) return true;
  const exts = extensionsOf(file?.name);
  return TEXT_EXTENSIONS.has(exts[exts.length - 1] ?? "");
}

// send-checks/src/lib/scan.js
function goesOutside(email) {
  if (Array.isArray(email?.externalRecipients)) return email.externalRecipients.length > 0;
  return ["to", "cc", "bcc"].some((f) => Array.isArray(email?.[f]) && email[f].some((r) => String(r ?? "").trim()));
}
function textsOf(email) {
  const own = typeof email?.authoredText === "string" ? email.authoredText : String(email?.textBody ?? "");
  const out = [
    { where: null, text: String(email?.subject ?? "") },
    { where: null, text: own }
  ];
  for (const file of Array.isArray(email?.attachments) ? email.attachments : []) {
    if (file && typeof file.textExcerpt === "string" && file.textExcerpt && isTextAttachment(file)) {
      out.push({ where: String(file.name || "attachment"), text: file.textExcerpt });
    }
    if (file && file.name) out.push({ where: null, text: String(file.name), isName: true });
  }
  return out;
}
function compileRules(config) {
  const patterns = parsePatterns(config.patterns);
  return {
    config,
    keywords: parseKeywords(config.keywords),
    patterns: patterns.rules,
    skippedPatterns: patterns.skipped,
    blocked: parseTypeList(config.blockedTypes),
    allowed: parseTypeList(config.allowedTypes),
    limit: maxBytes(config.maxSizeMb)
  };
}
function applies(actionValue, externalOnly, outside) {
  return actionValue && actionValue !== "off" && (!externalOnly || outside);
}
function evaluate(email, compiled2, { now = Date.now } = {}) {
  const { config } = compiled2;
  const outside = goesOutside(email);
  const found = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (key, finding) => {
    if (seen.has(key)) return;
    seen.add(key);
    found.push(finding);
  };
  const doIban = applies(config.ibanAction, config.ibanExternalOnly, outside);
  const doCard = applies(config.cardAction, config.cardExternalOnly, outside);
  const doKeyword = compiled2.keywords.length > 0 && applies(config.keywordAction, config.keywordExternalOnly, outside);
  const doPattern = compiled2.patterns.length > 0 && applies(config.patternAction, config.patternExternalOnly, outside);
  const deadline = now() + PATTERN_BUDGET_MS;
  let timedOut = false;
  for (const { where, text: text2, isName } of textsOf(email)) {
    if (!text2) continue;
    const ibans = doIban || doCard ? findIbans(text2) : [];
    if (doIban) {
      for (const iban of ibans) {
        push(`iban|${iban.value}`, { rule: "iban", action: config.ibanAction, externalOnly: config.ibanExternalOnly, where, masked: maskIban(iban.value) });
      }
    }
    if (doCard && !isName) {
      for (const card of findCards(text2, ibans)) {
        push(`card|${card.digits}`, { rule: "card", action: config.cardAction, externalOnly: config.cardExternalOnly, where, last4: cardLastFour(card.digits) });
      }
    }
    if (doKeyword) {
      for (const keyword of findKeywords(text2, compiled2.keywords)) {
        push(`keyword|${keyword.toLowerCase()}`, { rule: "keyword", action: config.keywordAction, externalOnly: config.keywordExternalOnly, where, keyword });
      }
    }
    if (doPattern && !timedOut) {
      const result = findPatterns(text2, compiled2.patterns, deadline);
      timedOut = result.timedOut;
      for (const hit of result.found) {
        push(`pattern|${hit.name}|${hit.match}`, { rule: "pattern", action: config.patternAction, externalOnly: config.patternExternalOnly, where, name: hit.name, masked: maskMatch(hit.match) });
      }
    }
  }
  if (applies(config.attachmentAction, config.attachmentExternalOnly, outside)) {
    for (const problem of attachmentProblems(email?.attachments, compiled2)) {
      const base = { action: config.attachmentAction, externalOnly: config.attachmentExternalOnly, where: null, name: problem.name };
      if (problem.kind === "type") push(`type|${problem.name}`, { ...base, rule: "type", type: problem.type, reason: problem.reason });
      else push(`size|${problem.name}`, { ...base, rule: "size", maxMb: config.maxSizeMb });
    }
  }
  return { found, outside, timedOut };
}
function uploadProblem(file, compiled2) {
  const { config } = compiled2;
  if (config.attachmentAction !== "block" || config.attachmentExternalOnly) return null;
  const [problem] = attachmentProblems([{ ...file, inline: !!file?.inline }], compiled2);
  return problem ?? null;
}

// send-checks/src/lib/config.js
var DEFAULTS = Object.freeze({
  ibanAction: "warn",
  ibanExternalOnly: true,
  cardAction: "warn",
  cardExternalOnly: true,
  keywords: "",
  keywordAction: "warn",
  keywordExternalOnly: false,
  patterns: "",
  patternAction: "warn",
  patternExternalOnly: false,
  blockedTypes: "",
  allowedTypes: "",
  maxSizeMb: 0,
  attachmentAction: "block",
  attachmentExternalOnly: false
});
var ACTIONS = ["off", "warn", "block"];
function action(value, fallback, allowOff = true) {
  const v = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (ACTIONS.includes(v) && (allowOff || v !== "off")) return v;
  return fallback;
}
function bool(value, fallback) {
  if (typeof value === "boolean") return value;
  if (value === "true") return true;
  if (value === "false") return false;
  return fallback;
}
function text(value, fallback) {
  if (Array.isArray(value)) return value.map(String).join("\n");
  return typeof value === "string" ? value : fallback;
}
function normaliseConfig(raw) {
  const c = raw && typeof raw === "object" ? raw : {};
  const size = Number(c.maxSizeMb);
  return {
    ibanAction: action(c.ibanAction, DEFAULTS.ibanAction),
    ibanExternalOnly: bool(c.ibanExternalOnly, DEFAULTS.ibanExternalOnly),
    cardAction: action(c.cardAction, DEFAULTS.cardAction),
    cardExternalOnly: bool(c.cardExternalOnly, DEFAULTS.cardExternalOnly),
    keywords: text(c.keywords, DEFAULTS.keywords),
    keywordAction: action(c.keywordAction, DEFAULTS.keywordAction, false),
    keywordExternalOnly: bool(c.keywordExternalOnly, DEFAULTS.keywordExternalOnly),
    patterns: text(c.patterns, DEFAULTS.patterns),
    patternAction: action(c.patternAction, DEFAULTS.patternAction, false),
    patternExternalOnly: bool(c.patternExternalOnly, DEFAULTS.patternExternalOnly),
    blockedTypes: text(c.blockedTypes, DEFAULTS.blockedTypes),
    allowedTypes: text(c.allowedTypes, DEFAULTS.allowedTypes),
    maxSizeMb: Number.isFinite(size) && size > 0 ? size : 0,
    attachmentAction: action(c.attachmentAction, DEFAULTS.attachmentAction, false),
    attachmentExternalOnly: bool(c.attachmentExternalOnly, DEFAULTS.attachmentExternalOnly)
  };
}

// send-checks/src/lib/messages.js
var FALLBACK = {
  "warn.title": "Check before sending",
  "warn.message": "Your organisation asks you to check this before the message goes out:\n\n{list}",
  "warn.confirm": "Send anyway",
  "warn.cancel": "Go back",
  "warn.cancelled": "Message not sent",
  "block.title": "This message can't be sent",
  "block.message": "Your organisation doesn't allow sending this:\n\n{list}\n\nRemove it and try again.",
  "block.alsoCheck": "Also check:\n\n{list}",
  "outside.note": "Some of these only count because the message goes outside your organisation.",
  "upload.title": "This file can't be attached",
  "upload.type": "Your organisation doesn't allow attaching {name} ({type}).",
  "upload.size": "{name} is larger than {max} MB, the most your organisation allows.",
  "item.iban": "IBAN {masked}",
  "item.card": "Card number ending {last4}",
  "item.keyword": "The word “{keyword}”",
  "item.pattern": "{name}: {masked}",
  "item.type": "{name}: file type not allowed ({type})",
  "item.size": "{name}: larger than {max} MB",
  "item.inFile": "{item} (in {file})",
  "item.more": "and {count} more"
};
var MAX_LISTED = 10;
function itemText(finding, tr2) {
  let text2;
  switch (finding.rule) {
    case "iban":
      text2 = tr2("item.iban", { masked: finding.masked });
      break;
    case "card":
      text2 = tr2("item.card", { last4: finding.last4 });
      break;
    case "keyword":
      text2 = tr2("item.keyword", { keyword: finding.keyword });
      break;
    case "pattern":
      text2 = tr2("item.pattern", { name: finding.name, masked: finding.masked });
      break;
    case "type":
      text2 = tr2("item.type", { name: finding.name, type: finding.type });
      break;
    case "size":
      text2 = tr2("item.size", { name: finding.name, max: formatMb(finding.maxMb) });
      break;
    default:
      text2 = String(finding.rule);
  }
  return finding.where ? tr2("item.inFile", { item: text2, file: finding.where }) : text2;
}
function formatMb(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return String(Math.round(n * 10) / 10);
}
function listText(findings, tr2) {
  const lines2 = findings.slice(0, MAX_LISTED).map((f) => `• ${itemText(f, tr2)}`);
  if (findings.length > MAX_LISTED) lines2.push(tr2("item.more", { count: findings.length - MAX_LISTED }));
  return lines2.join("\n");
}
function dialogFor(found, tr2) {
  const blocks = found.filter((f) => f.action === "block");
  const warns = found.filter((f) => f.action === "warn");
  const note = found.some((f) => f.externalOnly) ? `

${tr2("outside.note")}` : "";
  if (blocks.length > 0) {
    let message = tr2("block.message", { list: listText(blocks, tr2) });
    if (warns.length > 0) message += `

${tr2("block.alsoCheck", { list: listText(warns, tr2) })}`;
    return { kind: "alert", title: tr2("block.title"), message: message + note };
  }
  return {
    kind: "confirm",
    title: tr2("warn.title"),
    message: tr2("warn.message", { list: listText(warns, tr2) }) + note,
    confirmLabel: tr2("warn.confirm"),
    cancelLabel: tr2("warn.cancel"),
    danger: true
  };
}

// send-checks/src/index.js
var pluginApi = null;
var compiled = compileRules(normaliseConfig({}));
var configKey = "";
function tr(key, vars) {
  const i18n = pluginApi && pluginApi.i18n;
  if (i18n && typeof i18n.has === "function" && i18n.has(key)) return i18n.t(key, vars);
  return String(FALLBACK[key] || key).replace(/\{(\w+)\}/g, (m, k) => vars && k in vars ? String(vars[k]) : m);
}
async function currentRules() {
  try {
    const raw = await pluginApi.config.get();
    const key = JSON.stringify(raw ?? {});
    if (key !== configKey) {
      configKey = key;
      compiled = compileRules(normaliseConfig(raw));
      for (const { line, reason } of compiled.skippedPatterns) {
        pluginApi.log.warn(`Pattern skipped (${reason}): ${line}`);
      }
    }
  } catch (err) {
    pluginApi.log.warn("Could not read the admin settings; using the last ones", err);
  }
  return compiled;
}
async function activate(api) {
  pluginApi = api;
  await currentRules();
  api.log.info("Send Checks plugin activated");
}
var hooks = {
  async onBeforeEmailSend(email) {
    if (!pluginApi || !email) return void 0;
    const rules = await currentRules();
    const { found, timedOut } = evaluate(email, rules);
    if (timedOut) pluginApi.log.warn("Pattern check stopped after its time budget; some patterns were not checked");
    if (found.length === 0) return void 0;
    const dialog = dialogFor(found, tr);
    if (dialog.kind === "alert") {
      await pluginApi.ui.alert({ title: dialog.title, message: dialog.message });
      return false;
    }
    const send = await pluginApi.ui.confirm({
      title: dialog.title,
      message: dialog.message,
      confirmLabel: dialog.confirmLabel,
      cancelLabel: dialog.cancelLabel,
      danger: true
    });
    if (send) return void 0;
    pluginApi.toast.info(tr("warn.cancelled"));
    return false;
  },
  async onBeforeAttachmentUpload(info) {
    if (!pluginApi || !info) return void 0;
    const rules = await currentRules();
    const problem = uploadProblem(info, rules);
    if (!problem) return void 0;
    const message = problem.kind === "size" ? tr("upload.size", { name: problem.name, max: formatMb(rules.config.maxSizeMb) }) : tr("upload.type", { name: problem.name, type: problem.type });
    await pluginApi.ui.alert({ title: tr("upload.title"), message });
    return false;
  }
};
