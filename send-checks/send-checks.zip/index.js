var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// send-checks/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks
});
module.exports = __toCommonJS(index_exports);

// send-checks/src/lib/separators.js
var chars = (...codes) => String.fromCharCode(...codes);
var GROUP_SPACES = ` ${chars(160, 8199, 8201, 8239)}`;
var GROUP_DASHES = `\\-${chars(8208, 8209, 8210, 8211)}`;
var GROUP_SEPARATOR = new RegExp(`[${GROUP_SPACES}${GROUP_DASHES}]`, "u");

// send-checks/src/lib/iban.js
var IBAN_LENGTHS = {
  AD: 24,
  AE: 23,
  AL: 28,
  AT: 20,
  AZ: 28,
  BA: 20,
  BE: 16,
  BG: 22,
  BH: 22,
  BI: 27,
  BR: 29,
  BY: 28,
  CH: 21,
  CR: 22,
  CY: 28,
  CZ: 24,
  DE: 22,
  DJ: 27,
  DK: 18,
  DO: 28,
  EE: 20,
  EG: 29,
  ES: 24,
  FI: 18,
  FK: 18,
  FO: 18,
  FR: 27,
  GB: 22,
  GE: 22,
  GI: 23,
  GL: 18,
  GR: 27,
  GT: 28,
  HN: 28,
  HR: 21,
  HU: 28,
  IE: 22,
  IL: 23,
  IQ: 23,
  IS: 26,
  IT: 27,
  JO: 30,
  KW: 30,
  KZ: 20,
  LB: 28,
  LC: 32,
  LI: 21,
  LT: 20,
  LU: 20,
  LV: 21,
  LY: 25,
  MC: 27,
  MD: 24,
  ME: 22,
  MK: 19,
  MN: 20,
  MR: 27,
  MT: 31,
  MU: 30,
  NI: 28,
  NL: 18,
  NO: 15,
  OM: 23,
  PK: 24,
  PL: 28,
  PS: 29,
  PT: 25,
  QA: 29,
  RO: 24,
  RS: 22,
  RU: 33,
  SA: 24,
  SC: 31,
  SD: 18,
  SE: 24,
  SI: 19,
  SK: 24,
  SM: 27,
  SO: 23,
  ST: 25,
  SV: 28,
  TL: 23,
  TN: 24,
  TR: 26,
  UA: 29,
  VA: 22,
  VG: 24,
  XK: 20,
  YE: 30
};
var ALNUM = /[A-Za-z0-9]/;
function ibanChecksumOk(iban) {
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]+$/.test(iban)) return false;
  const moved = iban.slice(4) + iban.slice(0, 4);
  let rest = 0;
  for (const ch of moved) {
    const code = ch.charCodeAt(0);
    const digits = code >= 65 ? String(code - 55) : ch;
    for (const d of digits) rest = (rest * 10 + (d.charCodeAt(0) - 48)) % 97;
  }
  return rest === 1;
}
function findIbans(text2) {
  const out = [];
  if (!text2) return out;
  const start = /(?<![A-Za-z0-9])([A-Za-z]{2})(\d{2})/g;
  let m;
  while (m = start.exec(text2)) {
    const country = m[1].toUpperCase();
    const length = IBAN_LENGTHS[country];
    if (!length) continue;
    let compact = country + m[2];
    let i = m.index + 4;
    let end = i;
    while (i < text2.length && compact.length < length) {
      const ch = text2[i];
      if (ALNUM.test(ch)) {
        compact += ch.toUpperCase();
        i += 1;
        end = i;
      } else if (GROUP_SEPARATOR.test(ch) && i + 1 < text2.length && ALNUM.test(text2[i + 1])) {
        i += 1;
      } else {
        break;
      }
    }
    if (compact.length !== length || end < text2.length && ALNUM.test(text2[end])) continue;
    if (!ibanChecksumOk(compact)) continue;
    out.push({ value: compact, start: m.index, end });
    start.lastIndex = end;
  }
  return out;
}
function maskIban(compact) {
  const value = String(compact ?? "");
  return `${value.slice(0, 4)} … ${value.slice(-4)}`;
}

// send-checks/src/lib/cards.js
function luhnOk(digits) {
  if (!/^\d+$/.test(digits)) return false;
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let d = digits.charCodeAt(i) - 48;
    if (double) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    double = !double;
  }
  return sum % 10 === 0;
}
var NETWORKS = [
  { test: (d) => d[0] === "4", lengths: [13, 16, 19] },
  { test: (d) => {
    const n = Number(d.slice(0, 2));
    return n >= 51 && n <= 55;
  }, lengths: [16] },
  { test: (d) => {
    const n = Number(d.slice(0, 4));
    return n >= 2221 && n <= 2720;
  }, lengths: [16] },
  { test: (d) => /^3[47]/.test(d), lengths: [15] },
  { test: (d) => /^(?:30[0-5]|309|36|38|39)/.test(d), lengths: [14, 15, 16, 17, 18, 19] },
  { test: (d) => {
    const n = Number(d.slice(0, 4));
    return n >= 3528 && n <= 3589;
  }, lengths: [16, 17, 18, 19] },
  { test: (d) => /^(?:6011|64[4-9]|65|62)/.test(d), lengths: [16, 17, 18, 19] },
  { test: (d) => /^(?:50|5[6-8]|67)/.test(d), lengths: [13, 14, 15, 16, 17, 18, 19] }
];
function looksLikeCard(digits) {
  if (digits.length < 13 || digits.length > 19) return false;
  if (/^(\d)\1+$/.test(digits)) return false;
  return NETWORKS.some((n) => n.test(digits) && n.lengths.includes(digits.length));
}
var SEP_CLASS = `[${GROUP_SPACES}${GROUP_DASHES}]`;
var RUN = new RegExp(`(?<![0-9.,${GROUP_DASHES}])[0-9](?:${SEP_CLASS}?[0-9]){12,}(?![0-9]|[.,][0-9])`, "gu");
var SEP = new RegExp(SEP_CLASS, "u");
var SPACE = new RegExp(`[${GROUP_SPACES}]`, "u");
var DASH = new RegExp(`[${GROUP_DASHES}]`, "u");
function cardIn(raw) {
  const groups = raw.split(SEP);
  const lengths = groups.map((g) => g.length);
  const candidates = [groups.join("")];
  const startsWith = (shape) => lengths.length > shape.length && shape.every((len, i) => lengths[i] === len);
  if (startsWith([4, 4, 4, 4])) candidates.push(groups.slice(0, 4).join(""));
  if (startsWith([4, 6, 5])) candidates.push(groups.slice(0, 3).join(""));
  return candidates.find((d) => looksLikeCard(d) && luhnOk(d)) ?? null;
}
function findCards(text2, skip = []) {
  const out = [];
  if (!text2) return out;
  let m;
  RUN.lastIndex = 0;
  while (m = RUN.exec(text2)) {
    const raw = m[0];
    const start = m.index;
    const end = start + raw.length;
    if (skip.some((r) => start < r.end && end > r.start)) continue;
    const before = text2.slice(Math.max(0, start - 2), start);
    if (/\+\s?$/u.test(before) || raw.startsWith("00")) continue;
    if (SPACE.test(raw) && DASH.test(raw)) continue;
    const digits = cardIn(raw);
    if (!digits) continue;
    out.push({ digits, start, end });
  }
  return out;
}
function cardLastFour(digits) {
  return String(digits ?? "").slice(-4);
}

// send-checks/src/lib/text-rules.js
var MAX_PATTERN_LENGTH = 200;
var MAX_RULES = 50;
function listLines(value) {
  return String(value ?? "").split(/\r?\n/).map((l) => l.trim()).filter((l) => l && l !== "#" && !/^#\s/.test(l) && !l.startsWith("//"));
}
function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function parseKeywords(value) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const keyword of listLines(value).slice(0, MAX_RULES * 4)) {
    const key = keyword.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    const wordStart = /^[\p{L}\p{N}]/u.test(keyword) ? "(?<![\\p{L}\\p{N}_])" : "";
    const wordEnd = /[\p{L}\p{N}]$/u.test(keyword) ? "(?![\\p{L}\\p{N}_])" : "";
    out.push({ keyword, re: new RegExp(`${wordStart}${escapeRegex(keyword)}${wordEnd}`, "iu") });
  }
  return out;
}
function findKeywords(text2, keywords) {
  if (!text2) return [];
  return keywords.filter((k) => k.re.test(text2)).map((k) => k.keyword);
}
var SAMPLES = [
  "a",
  "A",
  "z",
  "Z",
  "e",
  "0",
  "5",
  "9",
  "_",
  " ",
  "	",
  "\n",
  "-",
  ".",
  ",",
  "@",
  "/",
  ":",
  "+",
  "#",
  String.fromCharCode(233),
  String.fromCharCode(223),
  String.fromCharCode(8364),
  String.fromCharCode(1046),
  String.fromCharCode(20013),
  String.fromCharCode(160)
];
function sampleSet(atom, flags) {
  if (atom.kind === "group" || atom.kind === "any") return null;
  try {
    const re = new RegExp(`^(?:${atom.text})$`, flags.replace(/[gy]/g, ""));
    return new Set(SAMPLES.filter((c) => re.test(c)));
  } catch {
    return null;
  }
}
function overlaps(a, b, flags) {
  const sa = sampleSet(a, flags);
  const sb = sampleSet(b, flags);
  if (!sa || !sb) return true;
  if (sa.size === 0 || sb.size === 0) return true;
  for (const c of sa) if (sb.has(c)) return true;
  return false;
}
function readQuantifier(source, i) {
  const c = source[i];
  let q = null;
  if (c === "*") q = { min: 0, max: Infinity, length: 1 };
  else if (c === "+") q = { min: 1, max: Infinity, length: 1 };
  else if (c === "?") q = { min: 0, max: 1, length: 1 };
  else if (c === "{") {
    const m = /^\{(\d+)(,(\d*))?\}/.exec(source.slice(i));
    if (m) {
      const min = Number(m[1]);
      const max = m[2] === void 0 ? min : m[3] === "" ? Infinity : Number(m[3]);
      q = { min, max, length: m[0].length };
    }
  }
  if (q && source[i + q.length] === "?") q.length += 1;
  return q;
}
function escapeLength(source, i) {
  const next = source[i + 1];
  if ((next === "p" || next === "P" || next === "u" || next === "k") && source[i + 2] === "{") {
    const close = source.indexOf("}", i + 3);
    return close > 0 ? close - i + 1 : 2;
  }
  if (next === "u" && /^[0-9a-fA-F]{4}/.test(source.slice(i + 2))) return 6;
  if (next === "x" && /^[0-9a-fA-F]{2}/.test(source.slice(i + 2))) return 4;
  if (next === "c" && /[A-Za-z]/.test(source[i + 2] ?? "")) return 3;
  return 2;
}
function chainStep(chain, atom, q, flags) {
  const unbounded = !!q && q.max === Infinity;
  if (unbounded) {
    for (let k = chain.length - 1; k >= 0; k -= 1) {
      const prev = chain[k];
      if (overlaps(prev.atom, atom, flags)) return "overlapping repeats";
      if (prev.min >= 1) break;
    }
    chain.push({ atom, min: q.min });
    return null;
  }
  if (q && q.min === 0) return null;
  chain.length = 0;
  return null;
}
function patternProblem(source, flags = "") {
  if (!source) return "empty";
  if (source.length > MAX_PATTERN_LENGTH) return "too long";
  if (/\\[1-9]|\\k</.test(source)) return "back reference";
  const frames = [{ repeat: false, alternation: false, chain: [] }];
  let i = 0;
  while (i < source.length) {
    const frame = frames[frames.length - 1];
    const c = source[i];
    let atom;
    if (c === "\\") {
      const len = escapeLength(source, i);
      const text2 = source.slice(i, i + len);
      i += len;
      if (text2 === "\\b" || text2 === "\\B") continue;
      atom = { kind: "char", text: text2 };
    } else if (c === "[") {
      let j = i + 1;
      if (source[j] === "^") j += 1;
      if (source[j] === "]") j += 1;
      while (j < source.length && source[j] !== "]") j += source[j] === "\\" ? 2 : 1;
      atom = { kind: "class", text: source.slice(i, j + 1) };
      i = j + 1;
    } else if (c === "(") {
      let j = i + 1;
      if (source[j] === "?") {
        const prefix = /^\?(?::|=|!|<=|<!|<[A-Za-z_$][\w$]*>)/.exec(source.slice(j));
        j += prefix ? prefix[0].length : 1;
      }
      frames.push({ repeat: false, alternation: false, chain: [] });
      i = j;
      continue;
    } else if (c === ")") {
      if (frames.length === 1) return "unbalanced";
      const inner = frames.pop();
      i += 1;
      const q2 = readQuantifier(source, i);
      const parent = frames[frames.length - 1];
      if (q2) {
        i += q2.length;
        if (q2.max > 1 && inner.repeat) return "nested quantifier";
        if (q2.max > 1 && inner.alternation) return "repeated alternation";
      }
      parent.repeat = parent.repeat || inner.repeat || !!q2;
      const problem2 = chainStep(parent.chain, { kind: "group", text: "" }, q2, flags);
      if (problem2) return problem2;
      continue;
    } else if (c === "|") {
      frame.alternation = true;
      frame.chain = [];
      i += 1;
      continue;
    } else if (c === "^" || c === "$") {
      frame.chain = [];
      i += 1;
      continue;
    } else if (c === ".") {
      atom = { kind: "any", text: "." };
      i += 1;
    } else {
      atom = { kind: "char", text: escapeRegex(c) };
      i += 1;
    }
    const q = readQuantifier(source, i);
    if (q) {
      i += q.length;
      frame.repeat = true;
    }
    const problem = chainStep(frame.chain, atom, q, flags);
    if (problem) return problem;
  }
  if (frames.length !== 1) return "unbalanced";
  return null;
}
function parsePatterns(value) {
  const rules = [];
  const skipped = [];
  for (const line of listLines(value).slice(0, MAX_RULES)) {
    let name = "";
    let body = line;
    const named = /^([^:/]{1,60}?):\s+(.+)$/.exec(line);
    if (named) {
      name = named[1].trim();
      body = named[2].trim();
    }
    let source = body;
    let flags = "i";
    const literal = /^\/(.+)\/([a-z]*)$/.exec(body);
    if (literal) {
      source = literal[1];
      flags = [...new Set(literal[2].split(""))].filter((f) => "imsu".includes(f)).join("");
    }
    try {
      new RegExp(source, flags);
    } catch (err) {
      skipped.push({ line, name: name || source, reason: String(err && err.message ? err.message : err) });
      continue;
    }
    const problem = patternProblem(source, flags);
    if (problem) {
      skipped.push({ line, name: name || source, reason: problem });
      continue;
    }
    rules.push({ name: name || source, source, flags: `${flags}g` });
  }
  return { rules, skipped };
}
function maskMatch(value) {
  const s = String(value ?? "").replace(/\s+/g, " ").trim();
  if (s.length <= 4) return "•".repeat(Math.max(s.length, 1));
  if (s.length <= 8) return `${s[0]}…${s[s.length - 1]}`;
  return `${s.slice(0, 2)}…${s.slice(-2)}`;
}

// send-checks/src/lib/pattern-runner.js
var PATTERN_BUDGET_MS = 250;
var WORKER_SOURCE = `
self.onmessage = function (event) {
  var data = event.data || {};
  var rules = data.rules || [];
  var texts = data.texts || [];
  var found = [];
  for (var t = 0; t < texts.length; t++) {
    var text = String(texts[t] || '');
    if (!text) continue;
    for (var r = 0; r < rules.length; r++) {
      var re;
      try { re = new RegExp(rules[r].source, rules[r].flags); } catch (e) { continue; }
      re.lastIndex = 0;
      var m;
      while ((m = re.exec(text))) {
        if (m[0]) { found.push({ text: t, name: rules[r].name, match: m[0] }); break; }
        re.lastIndex += 1;
      }
    }
  }
  self.postMessage({ found: found });
};
`;
function defaultCreateWorker() {
  try {
    if (typeof Worker !== "function" || typeof Blob !== "function" || typeof URL === "undefined" || typeof URL.createObjectURL !== "function") {
      return null;
    }
    const url = URL.createObjectURL(new Blob([WORKER_SOURCE], { type: "text/javascript" }));
    const worker = new Worker(url);
    try {
      URL.revokeObjectURL(url);
    } catch {
    }
    return worker;
  } catch {
    return null;
  }
}
function runPatterns(texts, rules, { budgetMs = PATTERN_BUDGET_MS, createWorker = defaultCreateWorker } = {}) {
  const work = texts.map((t) => String(t ?? ""));
  if (rules.length === 0 || !work.some(Boolean)) return Promise.resolve({ found: [], complete: true });
  let worker = null;
  try {
    worker = createWorker();
  } catch {
    worker = null;
  }
  if (!worker) return Promise.resolve({ found: [], complete: false, reason: "no-worker" });
  return new Promise((resolve) => {
    let done = false;
    const finish = (result) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try {
        worker.terminate();
      } catch {
      }
      resolve(result);
    };
    const timer = setTimeout(() => finish({ found: [], complete: false, reason: "timeout" }), budgetMs);
    worker.onmessage = (event) => {
      const found = Array.isArray(event?.data?.found) ? event.data.found : null;
      finish(found ? { found, complete: true } : { found: [], complete: false, reason: "error" });
    };
    worker.onerror = () => finish({ found: [], complete: false, reason: "error" });
    try {
      worker.postMessage({ rules: rules.map(({ name, source, flags }) => ({ name, source, flags })), texts: work });
    } catch {
      finish({ found: [], complete: false, reason: "error" });
    }
  });
}

// send-checks/src/lib/attachments.js
var SNIFFED_BY_EXTENSION = {
  "application/x-msdownload": ["exe", "dll", "scr", "com", "cpl", "pif", "sys", "ocx", "drv", "efi"],
  "application/x-executable": ["elf", "so", "bin", "run", "out"],
  "application/x-mach-binary": ["app", "dylib", "macho"],
  "text/x-shellscript": ["sh", "bash", "zsh", "ksh", "csh", "command"],
  "application/x-ms-shortcut": ["lnk"],
  "application/vnd.ms-cab-compressed": ["cab"],
  // Java and Android apps: ZIP files the host tells apart by their entries.
  "application/java-archive": ["jar"],
  "application/vnd.android.package-archive": ["apk"],
  // Windows Installer packages are OLE compound files, like old Office files.
  "application/x-ole-storage": ["msi", "msp", "mst"],
  "application/x-rar-compressed": ["rar"],
  "application/x-7z-compressed": ["7z"],
  "application/gzip": ["gz", "tgz"],
  "application/pdf": ["pdf"],
  "application/zip": ["zip"]
};
var ZIP_CONTAINERS = /* @__PURE__ */ new Set([
  "zip",
  "docx",
  "docm",
  "xlsx",
  "xlsm",
  "pptx",
  "pptm",
  "odt",
  "ods",
  "odp",
  "odg",
  "jar",
  "apk",
  "epub",
  "xpi",
  "vsix",
  "kmz",
  "ipa",
  "nupkg",
  "whl",
  "3mf",
  "pages",
  "numbers",
  "key"
]);
var PROGRAM_TYPES = /* @__PURE__ */ new Set([
  "application/x-msdownload",
  "application/x-executable",
  "application/x-mach-binary",
  "text/x-shellscript",
  "application/x-ms-shortcut",
  "application/vnd.ms-cab-compressed",
  "application/x-ole-storage",
  "application/java-archive",
  "application/vnd.android.package-archive"
]);
var OLE_DOCUMENTS = /* @__PURE__ */ new Set(["doc", "dot", "xls", "xlt", "ppt", "pot", "pps", "msg", "pub", "vsd", "mpp"]);
var PROGRAM_EXTENSIONS = new Set(
  Object.entries(SNIFFED_BY_EXTENSION).filter(([type]) => PROGRAM_TYPES.has(type)).flatMap(([, exts]) => exts)
);
function parseTypeList(value) {
  const extensions = /* @__PURE__ */ new Set();
  const types = /* @__PURE__ */ new Set();
  for (const raw of String(value ?? "").split(/[\s,;]+/)) {
    const item = raw.trim().toLowerCase();
    if (!item) continue;
    if (item.includes("/")) types.add(item);
    else extensions.add(item.replace(/^\*?\./, ""));
  }
  return { extensions, types };
}
function isEmptyList(list) {
  return list.extensions.size === 0 && list.types.size === 0;
}
function extensionsOf(name) {
  const parts = String(name ?? "").toLowerCase().trim().replace(/[.\s]+$/, "").split(".");
  if (parts.length < 2) return [];
  return parts.slice(1).filter((p) => /^[a-z0-9]{1,10}$/.test(p) && !/^\d+$/.test(p));
}
function typeMatches(type, types) {
  if (!type) return false;
  const t = type.toLowerCase();
  if (types.has(t)) return true;
  const slash = t.indexOf("/");
  return slash > 0 && types.has(`${t.slice(0, slash)}/*`);
}
function sniffedTypesFor(extensions) {
  const out = /* @__PURE__ */ new Set();
  for (const [type, exts] of Object.entries(SNIFFED_BY_EXTENSION)) {
    if (exts.some((e) => extensions.has(e))) out.add(type);
  }
  return out;
}
function typeProblem(file, blocked, allowed) {
  const exts = extensionsOf(file.name);
  const last = exts[exts.length - 1] ?? "";
  const sniffed = typeof file.sniffedType === "string" ? file.sniffedType.toLowerCase() : "";
  const sniffedCounts = sniffed && !(sniffed === "application/zip" && ZIP_CONTAINERS.has(last) && last !== "zip") && !(sniffed === "application/x-ole-storage" && OLE_DOCUMENTS.has(last));
  const declared = typeof file.type === "string" ? file.type.toLowerCase() : "";
  const blocksPrograms = [...blocked.extensions].some((e) => PROGRAM_EXTENSIONS.has(e));
  if (!isEmptyList(blocked)) {
    if (last && blocked.extensions.has(last)) return { reason: "blocked", type: last };
    if (sniffedCounts && (typeMatches(sniffed, blocked.types) || sniffedTypesFor(blocked.extensions).has(sniffed) || blocksPrograms && PROGRAM_TYPES.has(sniffed))) {
      return { reason: "blocked", type: sniffed };
    }
    if (declared && typeMatches(declared, blocked.types)) return { reason: "blocked", type: declared };
  }
  if (!isEmptyList(allowed)) {
    const byExtension = !!last && allowed.extensions.has(last);
    const byType = typeMatches(declared, allowed.types) || sniffedCounts && typeMatches(sniffed, allowed.types);
    if (!byExtension && !byType) return { reason: "not-allowed", type: last || declared || sniffed || "?" };
    if (sniffedCounts && PROGRAM_TYPES.has(sniffed) && !typeMatches(sniffed, allowed.types) && !sniffedTypesFor(allowed.extensions).has(sniffed)) {
      return { reason: "not-allowed", type: sniffed };
    }
  }
  return null;
}
function maxBytes(maxSizeMb) {
  const n = Number(maxSizeMb);
  return Number.isFinite(n) && n > 0 ? Math.round(n * 1024 * 1024) : 0;
}
function attachmentProblems(attachments, { blocked, allowed, limit }) {
  const out = [];
  for (const file of Array.isArray(attachments) ? attachments : []) {
    if (!file || typeof file !== "object") continue;
    const name = String(file.name || "attachment");
    if (!file.inline) {
      const problem = typeProblem(file, blocked, allowed);
      if (problem) out.push({ name, kind: "type", type: problem.type, reason: problem.reason });
    }
    if (limit > 0 && Number(file.size) > limit) out.push({ name, kind: "size" });
  }
  return out;
}
var TEXT_EXTENSIONS = /* @__PURE__ */ new Set(["txt", "csv", "tsv", "json", "xml", "ics", "vcf", "md", "log", "html", "htm", "yaml", "yml", "ini", "conf"]);
var TEXT_TYPES = /* @__PURE__ */ new Set(["application/json", "application/xml", "application/csv", "application/x-yaml", "application/yaml"]);
function isTextAttachment(file) {
  const type = String(file?.type ?? "").toLowerCase().split(";")[0].trim();
  if (type.startsWith("text/") || TEXT_TYPES.has(type) || /\+(json|xml)$/.test(type)) return true;
  const exts = extensionsOf(file?.name);
  return TEXT_EXTENSIONS.has(exts[exts.length - 1] ?? "");
}

// send-checks/src/lib/scan.js
function goesOutside(email) {
  if (Array.isArray(email?.externalRecipients)) return email.externalRecipients.length > 0;
  return ["to", "cc", "bcc"].some((f) => Array.isArray(email?.[f]) && email[f].some((r) => String(r ?? "").trim()));
}
function textsOf(email) {
  const own = typeof email?.authoredText === "string" ? email.authoredText : String(email?.textBody ?? "");
  const out = [
    { where: null, text: String(email?.subject ?? "") },
    { where: null, text: own }
  ];
  for (const file of Array.isArray(email?.attachments) ? email.attachments : []) {
    if (file && typeof file.textExcerpt === "string" && file.textExcerpt && isTextAttachment(file)) {
      out.push({ where: String(file.name || "attachment"), text: file.textExcerpt });
    }
    if (file && file.name) out.push({ where: null, text: String(file.name), isName: true });
  }
  return out;
}
function compileRules(config) {
  const patterns = parsePatterns(config.patterns);
  return {
    config,
    keywords: parseKeywords(config.keywords),
    patterns: patterns.rules,
    skippedPatterns: patterns.skipped,
    blocked: parseTypeList(config.blockedTypes),
    allowed: parseTypeList(config.allowedTypes),
    limit: maxBytes(config.maxSizeMb)
  };
}
function applies(actionValue, externalOnly, outside) {
  return !!actionValue && actionValue !== "off" && (!externalOnly || outside);
}
var stricter = (a, b) => a === "block" || b === "block" ? "block" : a || b;
async function evaluate(email, compiled2, { runner = runPatterns } = {}) {
  const { config } = compiled2;
  const outside = goesOutside(email);
  const found = [];
  const incomplete = [];
  const seen = /* @__PURE__ */ new Set();
  const push = (key, finding) => {
    if (seen.has(key)) return;
    seen.add(key);
    found.push(finding);
  };
  const doIban = applies(config.ibanAction, config.ibanExternalOnly, outside);
  const doCard = applies(config.cardAction, config.cardExternalOnly, outside);
  const doKeyword = compiled2.keywords.length > 0 && applies(config.keywordAction, config.keywordExternalOnly, outside);
  const patternLines = compiled2.patterns.length + compiled2.skippedPatterns.length;
  const doPattern = patternLines > 0 && applies(config.patternAction, config.patternExternalOnly, outside);
  const patternBase = { action: config.patternAction, externalOnly: config.patternExternalOnly };
  const texts = textsOf(email).filter((t) => t.text);
  for (const { where, text: text2, isName } of texts) {
    const ibans = doIban || doCard ? findIbans(text2) : [];
    if (doIban) {
      for (const iban of ibans) {
        push(`iban|${iban.value}`, { rule: "iban", action: config.ibanAction, externalOnly: config.ibanExternalOnly, where, masked: maskIban(iban.value) });
      }
    }
    if (doCard && !isName) {
      for (const card of findCards(text2, ibans)) {
        push(`card|${card.digits}`, { rule: "card", action: config.cardAction, externalOnly: config.cardExternalOnly, where, last4: cardLastFour(card.digits) });
      }
    }
    if (doKeyword) {
      for (const keyword of findKeywords(text2, compiled2.keywords)) {
        push(`keyword|${keyword.toLowerCase()}`, { rule: "keyword", action: config.keywordAction, externalOnly: config.keywordExternalOnly, where, keyword });
      }
    }
  }
  if (doPattern) {
    for (const skipped of compiled2.skippedPatterns) {
      incomplete.push({ kind: "invalid-pattern", name: skipped.name, ...patternBase });
    }
    if (compiled2.patterns.length > 0) {
      const result = await runner(texts.map((t) => t.text), compiled2.patterns);
      if (!result.complete) incomplete.push({ kind: "patterns", ...patternBase });
      for (const hit of result.found) {
        const where = texts[hit.text]?.where ?? null;
        push(`pattern|${hit.name}|${hit.match}`, { rule: "pattern", ...patternBase, where, name: hit.name, masked: maskMatch(hit.match) });
      }
    }
  }
  const doAttachments = applies(config.attachmentAction, config.attachmentExternalOnly, outside);
  if (doAttachments) {
    for (const problem of attachmentProblems(email?.attachments, compiled2)) {
      const base = { action: config.attachmentAction, externalOnly: config.attachmentExternalOnly, where: null, name: problem.name };
      if (problem.kind === "type") push(`type|${problem.name}`, { ...base, rule: "type", type: problem.type, reason: problem.reason });
      else push(`size|${problem.name}`, { ...base, rule: "size", maxMb: config.maxSizeMb });
    }
  }
  const typeRules = doAttachments && !(isEmptyList(compiled2.blocked) && isEmptyList(compiled2.allowed));
  for (const file of Array.isArray(email?.attachments) ? email.attachments : []) {
    if (!file || file.unreadable !== true) continue;
    let action2 = "";
    let externalOnly = true;
    const take = (a, ext) => {
      action2 = stricter(action2, a);
      externalOnly = externalOnly && ext;
    };
    if (typeRules && !file.inline) take(config.attachmentAction, config.attachmentExternalOnly);
    if (isTextAttachment(file)) {
      if (doIban) take(config.ibanAction, config.ibanExternalOnly);
      if (doCard) take(config.cardAction, config.cardExternalOnly);
      if (doKeyword) take(config.keywordAction, config.keywordExternalOnly);
      if (doPattern) take(config.patternAction, config.patternExternalOnly);
    }
    if (action2) incomplete.push({ kind: "unreadable", name: String(file.name || "attachment"), action: action2, externalOnly });
  }
  return { found, incomplete, outside };
}
function uploadProblem(file, compiled2) {
  const { config } = compiled2;
  if (config.attachmentAction !== "block" || config.attachmentExternalOnly) return null;
  const [problem] = attachmentProblems([{ ...file, inline: !!file?.inline }], compiled2);
  if (problem) return problem;
  if (file?.unreadable === true && !(isEmptyList(compiled2.blocked) && isEmptyList(compiled2.allowed))) {
    return { name: String(file.name || "attachment"), kind: "unreadable" };
  }
  return null;
}

// send-checks/src/lib/config.js
var DEFAULTS = Object.freeze({
  ibanAction: "warn",
  ibanExternalOnly: true,
  cardAction: "warn",
  cardExternalOnly: true,
  keywords: "",
  keywordAction: "warn",
  keywordExternalOnly: false,
  patterns: "",
  patternAction: "warn",
  patternExternalOnly: false,
  blockedTypes: "",
  allowedTypes: "",
  maxSizeMb: 0,
  attachmentAction: "block",
  attachmentExternalOnly: false
});
var ACTIONS = ["off", "warn", "block"];
function action(value, fallback, allowOff = true) {
  const v = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (ACTIONS.includes(v) && (allowOff || v !== "off")) return v;
  return fallback;
}
function bool(value, fallback) {
  if (typeof value === "boolean") return value;
  if (value === "true") return true;
  if (value === "false") return false;
  return fallback;
}
function text(value, fallback) {
  if (Array.isArray(value)) return value.map(String).join("\n");
  return typeof value === "string" ? value : fallback;
}
function normaliseConfig(raw) {
  const c = raw && typeof raw === "object" ? raw : {};
  const size = Number(c.maxSizeMb);
  return {
    ibanAction: action(c.ibanAction, DEFAULTS.ibanAction),
    ibanExternalOnly: bool(c.ibanExternalOnly, DEFAULTS.ibanExternalOnly),
    cardAction: action(c.cardAction, DEFAULTS.cardAction),
    cardExternalOnly: bool(c.cardExternalOnly, DEFAULTS.cardExternalOnly),
    keywords: text(c.keywords, DEFAULTS.keywords),
    keywordAction: action(c.keywordAction, DEFAULTS.keywordAction, false),
    keywordExternalOnly: bool(c.keywordExternalOnly, DEFAULTS.keywordExternalOnly),
    patterns: text(c.patterns, DEFAULTS.patterns),
    patternAction: action(c.patternAction, DEFAULTS.patternAction, false),
    patternExternalOnly: bool(c.patternExternalOnly, DEFAULTS.patternExternalOnly),
    blockedTypes: text(c.blockedTypes, DEFAULTS.blockedTypes),
    allowedTypes: text(c.allowedTypes, DEFAULTS.allowedTypes),
    maxSizeMb: Number.isFinite(size) && size > 0 ? size : 0,
    attachmentAction: action(c.attachmentAction, DEFAULTS.attachmentAction, false),
    attachmentExternalOnly: bool(c.attachmentExternalOnly, DEFAULTS.attachmentExternalOnly)
  };
}

// send-checks/src/lib/messages.js
var FALLBACK = {
  "warn.title": "Check before sending",
  "warn.message": "Your organisation asks you to check this before the message goes out:\n\n{list}",
  "warn.confirm": "Send anyway",
  "warn.cancel": "Go back",
  "warn.cancelled": "Message not sent",
  "block.title": "This message can't be sent",
  "block.message": "Your organisation doesn't allow sending this:\n\n{list}\n\nRemove it and try again.",
  "block.alsoCheck": "Also check:\n\n{list}",
  "outside.note": "Some of these only count because the message goes outside your organisation.",
  "unchecked.title": "This message couldn't be checked",
  "unchecked.message": "Your organisation's checks couldn't finish, so the message wasn't sent:\n\n{list}\n\nTry again in a moment. If this keeps happening, tell your administrator.",
  "unchecked.config": "Your organisation's send checks couldn't load their settings, so the message wasn't sent. Try again in a moment.",
  "incomplete.note": "Some checks couldn't finish:\n\n{list}",
  "incomplete.warnOnly": "Some of your organisation's checks couldn't finish:\n\n{list}\n\nSend it only if you're sure it's fine.",
  "incomplete.patterns": "Your organisation's patterns couldn't be checked in time",
  "incomplete.invalidPattern": "The pattern “{name}” is set up wrongly. Ask your administrator to fix it.",
  "incomplete.unreadable": "{name} couldn't be read",
  "upload.title": "This file can't be attached",
  "upload.type": "Your organisation doesn't allow attaching {name} ({type}).",
  "upload.size": "{name} is larger than {max} MB, the most your organisation allows.",
  "upload.unreadable": "{name} couldn't be checked, so it can't be attached. Try again in a moment.",
  "item.iban": "IBAN {masked}",
  "item.card": "Card number ending {last4}",
  "item.keyword": "The word “{keyword}”",
  "item.pattern": "{name}: {masked}",
  "item.type": "{name}: file type not allowed ({type})",
  "item.size": "{name}: larger than {max} MB",
  "item.inFile": "{item} (in {file})",
  "item.more": "and {count} more"
};
var MAX_LISTED = 10;
function itemText(finding, tr2) {
  let text2;
  switch (finding.rule ?? finding.kind) {
    case "iban":
      text2 = tr2("item.iban", { masked: finding.masked });
      break;
    case "card":
      text2 = tr2("item.card", { last4: finding.last4 });
      break;
    case "keyword":
      text2 = tr2("item.keyword", { keyword: finding.keyword });
      break;
    case "pattern":
      text2 = tr2("item.pattern", { name: finding.name, masked: finding.masked });
      break;
    case "type":
      text2 = tr2("item.type", { name: finding.name, type: finding.type });
      break;
    case "size":
      text2 = tr2("item.size", { name: finding.name, max: formatMb(finding.maxMb) });
      break;
    case "patterns":
      text2 = tr2("incomplete.patterns");
      break;
    case "invalid-pattern":
      text2 = tr2("incomplete.invalidPattern", { name: finding.name });
      break;
    case "unreadable":
      text2 = tr2("incomplete.unreadable", { name: finding.name });
      break;
    default:
      text2 = String(finding.rule ?? finding.kind);
  }
  return finding.where ? tr2("item.inFile", { item: text2, file: finding.where }) : text2;
}
function formatMb(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return String(Math.round(n * 10) / 10);
}
function listText(findings, tr2) {
  const lines = findings.slice(0, MAX_LISTED).map((f) => `• ${itemText(f, tr2)}`);
  if (findings.length > MAX_LISTED) lines.push(tr2("item.more", { count: findings.length - MAX_LISTED }));
  return lines.join("\n");
}
function dialogFor(found, tr2, incomplete = []) {
  const blocks = found.filter((f) => f.action === "block");
  const warns = found.filter((f) => f.action === "warn");
  const unBlocks = incomplete.filter((f) => f.action === "block");
  const unWarns = incomplete.filter((f) => f.action === "warn");
  if (!blocks.length && !warns.length && !unBlocks.length && !unWarns.length) return null;
  const note = [...found, ...incomplete].some((f) => f.externalOnly) ? `

${tr2("outside.note")}` : "";
  const also = warns.length > 0 ? `

${tr2("block.alsoCheck", { list: listText(warns, tr2) })}` : "";
  if (blocks.length > 0) {
    const unfinished = incomplete.length > 0 ? `

${tr2("incomplete.note", { list: listText(incomplete, tr2) })}` : "";
    return { kind: "alert", title: tr2("block.title"), message: tr2("block.message", { list: listText(blocks, tr2) }) + also + unfinished + note };
  }
  if (unBlocks.length > 0) {
    return { kind: "alert", title: tr2("unchecked.title"), message: tr2("unchecked.message", { list: listText(incomplete, tr2) }) + also + note };
  }
  const message = warns.length > 0 ? tr2("warn.message", { list: listText(warns, tr2) }) + (unWarns.length ? `

${tr2("incomplete.note", { list: listText(unWarns, tr2) })}` : "") : tr2("incomplete.warnOnly", { list: listText(unWarns, tr2) });
  return {
    kind: "confirm",
    title: tr2("warn.title"),
    message: message + note,
    confirmLabel: tr2("warn.confirm"),
    cancelLabel: tr2("warn.cancel"),
    danger: true
  };
}

// send-checks/src/index.js
var pluginApi = null;
var compiled = compileRules(normaliseConfig({}));
var configKey = "";
var configLoaded = false;
function tr(key, vars) {
  const i18n = pluginApi && pluginApi.i18n;
  if (i18n && typeof i18n.has === "function" && i18n.has(key)) return i18n.t(key, vars);
  return String(FALLBACK[key] || key).replace(/\{(\w+)\}/g, (m, k) => vars && k in vars ? String(vars[k]) : m);
}
async function currentRules() {
  try {
    const raw = await pluginApi.config.get();
    if (raw !== null && typeof raw !== "object") throw new Error("settings are not an object");
    const key = JSON.stringify(raw ?? {});
    if (key !== configKey || !configLoaded) {
      configKey = key;
      compiled = compileRules(normaliseConfig(raw));
      for (const { line, reason } of compiled.skippedPatterns) {
        pluginApi.log.warn(`Pattern line can't run (${reason}), it counts as a rule that couldn't be checked: ${line}`);
      }
    }
    configLoaded = true;
  } catch (err) {
    pluginApi.log.warn(configLoaded ? "Could not read the admin settings; using the last ones" : "Could not read the admin settings", err);
  }
  return configLoaded ? compiled : null;
}
async function activate(api) {
  pluginApi = api;
  await currentRules();
  api.log.info("Send Checks plugin activated");
}
var hooks = {
  async onBeforeEmailSend(email) {
    if (!pluginApi || !email) return void 0;
    const rules = await currentRules();
    if (!rules) {
      await pluginApi.ui.alert({ title: tr("unchecked.title"), message: tr("unchecked.config") });
      return false;
    }
    const { found, incomplete } = await evaluate(email, rules);
    for (const item of incomplete) pluginApi.log.warn(`Not checked: ${item.kind}${item.name ? ` (${item.name})` : ""}`);
    const dialog = dialogFor(found, tr, incomplete);
    if (!dialog) return void 0;
    if (dialog.kind === "alert") {
      await pluginApi.ui.alert({ title: dialog.title, message: dialog.message });
      return false;
    }
    const send = await pluginApi.ui.confirm({
      title: dialog.title,
      message: dialog.message,
      confirmLabel: dialog.confirmLabel,
      cancelLabel: dialog.cancelLabel,
      danger: true
    });
    if (send) return void 0;
    pluginApi.toast.info(tr("warn.cancelled"));
    return false;
  },
  async onBeforeAttachmentUpload(info) {
    if (!pluginApi || !info) return void 0;
    const rules = await currentRules();
    if (!rules) return void 0;
    const problem = uploadProblem(info, rules);
    if (!problem) return void 0;
    const message = problem.kind === "size" ? tr("upload.size", { name: problem.name, max: formatMb(rules.config.maxSizeMb) }) : problem.kind === "unreadable" ? tr("upload.unreadable", { name: problem.name }) : tr("upload.type", { name: problem.name, type: problem.type });
    await pluginApi.ui.alert({ title: tr("upload.title"), message });
    return false;
  }
};
